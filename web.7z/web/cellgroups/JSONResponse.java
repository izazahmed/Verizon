package com.vzw.web.cellgroups;

/**
 * Created by gundaja on 12/12/16.
 */
public class JSONResponse {
    boolean success = true;
    String messages;
    String id;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessages() {
        return messages;
    }

    public void setMessages(String messages) {
        this.messages = messages;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


}
