package com.vzw.web.cellgroups;

import db.JdbcDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by gundaja on 5/5/17.
 */

public class CRANCgaController implements org.springframework.web.servlet.mvc.Controller {

    protected final Log logger = LogFactory.getLog(CRANCgaController.class);
    private JdbcDao jdbcDao;

    public JdbcDao getJdbcDao() {
        return this.jdbcDao;
    }

    public void setJdbcDao(JdbcDao jdbcDao) {
        this.jdbcDao = jdbcDao;
    }

    @Override
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {

        Map model = new HashMap();

        return new ModelAndView("crancellgrpadmin", model);
    }


}