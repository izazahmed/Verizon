package com.vzw.web.cellgroups;

import bus.ListItem;
import bus.location.EnodeB;
import com.google.gson.*;
import com.vzw.ns.util.JWTUtility;
import com.vzw.web.services.WebTokenController;

import db.JdbcDao;
import db.cellgroups.JdbcCgaDao;
import db.location.JdbcEnodeBDao;
import db.location.JdbcEnodeBNeighborsDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.vzw.lte.model.ElementGroupModel;
import org.vzw.lte.util.CellGroupUtil;
import org.vzw.lte.util.GeneralUtility;

import web.cellgroups.CGResponse;
import web.cellgroups.JSONResponse;

import javax.servlet.http.HttpServletRequest;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by gundaja on 12/9/16.
 */
@Controller
public class CgaJsonController {
        protected final Log logger = LogFactory.getLog(getClass());
    private JdbcDao jdbcDao;

    @Autowired
    public CgaJsonController(JdbcDao jdbcDao) {
        this.jdbcDao = jdbcDao;
    }

    @RequestMapping(value = "/cg/getAllEnodeBGroups", method = RequestMethod.GET)
    public @ResponseBody
    String getAllEnodeBGroups() throws SQLException {
        Gson gson = new GsonBuilder().create();

        String json = gson.toJson(JdbcCgaDao.getAllEnodeBGroups(jdbcDao));
        return json;
    }

    /*
    * Returns the list of cell groups the user is subscribed to
     */
    @RequestMapping(value = "/cg/getMyEnodeBGroupSubs", method = RequestMethod.GET)
    public @ResponseBody
    String getMyEnodeBGroupSubs(@RequestParam String login) throws SQLException {
        Gson gson = new GsonBuilder().create();

        String json = gson.toJson(JdbcCgaDao.getMyEnodeBGroupSubs(jdbcDao, login));
        return json;
    }

    @RequestMapping(value = "/cg/getAllEnodeBByGroup", method = RequestMethod.GET)
    public @ResponseBody
    String getEnodebListItemsForCellGroup(@RequestParam String group) throws SQLException {
        Gson gson = new GsonBuilder().create();

        ArrayList<String> al = new ArrayList<String> ();
        al.add(group);

        String json = gson.toJson(JdbcCgaDao.getEnodeBsForGroups(jdbcDao, al));

        return json;
    }

    @RequestMapping(value = "/cg/getMyCellgroup", method = RequestMethod.GET)
    public @ResponseBody
    String getMyCellgroup(@RequestParam String group) throws SQLException {
        Gson gson = new GsonBuilder().create();

        ArrayList<String> al = new ArrayList<String> ();
        al.add(group);

        String json = gson.toJson(JdbcCgaDao.getEnodeBsForGroups(jdbcDao, al));

        return json;
    }

    @RequestMapping(value = "/cg/getEnodeBGroups", method = RequestMethod.GET)
    public @ResponseBody
    String getEnodeBGroups(@RequestParam String user) throws SQLException {
        Gson gson = new GsonBuilder().create();


        String json = gson.toJson(JdbcCgaDao.getEnodeBGroupsForUser(jdbcDao, user));

        return json;
    }

    @RequestMapping(value = "/cg/unsubscribeToGroup", method = RequestMethod.POST)
    public @ResponseBody
    String unsubscribeToGroup(@RequestParam String userId, String elementGroupId) throws SQLException {
        boolean retVal = JdbcCgaDao.delEnodeBGroupSubscription(jdbcDao, userId, elementGroupId);
        return String.valueOf(retVal);
    }

    @RequestMapping(value = "/cg/subscribeToGroup", method = RequestMethod.POST)
    public @ResponseBody
    String subscribeToGroup(@RequestParam String userId, String elementGroupId) throws SQLException {
        boolean retVal = JdbcCgaDao.delEnodeBGroupSubscription(jdbcDao, userId, elementGroupId);

        retVal = JdbcCgaDao.addEnodeBGroupSubscription(jdbcDao, userId, elementGroupId);
        return String.valueOf(retVal);
    }


    private HashMap<Integer,String> getEnodebsFromFile(MultipartFile file) {
        String[] enodebIds = null;
        HashMap<Integer,String> hm = new HashMap<Integer,String>();
        try {
            byte[] fileContent = file.getBytes();
            String fileContentAsString = new String(fileContent);
            enodebIds = fileContentAsString.split("\n");

            if(enodebIds != null && enodebIds.length > 0) {
                for(int i = 0; i<enodebIds.length; i++) {
                    String eNodeB = enodebIds[i];
                    if (GeneralUtility.isNonEmpty(eNodeB)) {
                        if (eNodeB.indexOf(',') >= 0) {
                            String e = eNodeB.substring(0, eNodeB.indexOf(','));
                            String v = eNodeB.substring(eNodeB.indexOf(',') + 1);
                            hm.put(Integer.parseInt(e), v);
                        } else {
                            hm.put(Integer.parseInt(eNodeB), "");
                        }

                    }
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
        return hm;
    }

    @RequestMapping(value = "/cg/uploadFile", method = RequestMethod.POST)
    public @ResponseBody
    String uploadFileHandler(@RequestParam("filename") MultipartFile file) {
        Gson gson = new GsonBuilder().create();
        HashMap<Integer, String> enodebIdList = new HashMap<Integer, String>();
        enodebIdList = getEnodebsFromFile(file);
        CGResponse results = new CGResponse();
        ArrayList<EnodeB> finalEnodeB = new ArrayList<EnodeB>();
        String enodebIds = " ";

        for(Map.Entry<Integer, String> entry : enodebIdList.entrySet()){
            ArrayList<Integer> enodebId = new ArrayList();
            Integer id = entry.getKey();
            enodebId.add(id);
            ArrayList<EnodeB> enodeb = JdbcEnodeBDao.findEnodeBsByEnodebId(jdbcDao, enodebId);
            if(enodeb == null || enodeb.size() <= 0) {
                enodebIds = enodebIds + Integer.toString(id) + ",";
            }

            for(EnodeB elem : enodeb){
                elem.setCran(true);
                elem.setHigherEutrancells(entry.getValue());
            }

            finalEnodeB.addAll(enodeb);

        }

        results.setResults(finalEnodeB);
        results.setInvalidValues(enodebIds);
        return gson.toJson(results);
    }


    @SuppressWarnings("Duplicates")
    @RequestMapping(value="/cg/saveCellGroup", method = RequestMethod.POST)
    public  @ResponseBody String  saveCellGroup(@RequestBody String json, HttpServletRequest request) {
        Gson gson = new GsonBuilder().create();
        Boolean result = false;
        JSONResponse response = new JSONResponse();
        JsonParser parser = new JsonParser();
        JsonObject obj = parser.parse(json).getAsJsonObject();

        String user = obj.get("user").getAsString();
        String groupId = obj.get("groupId").getAsString();
        String groupName = obj.get("groupName").getAsString();
        String groupNewName = obj.get("groupNewName").getAsString();

        JsonArray cells = obj.getAsJsonArray("data");
        Iterator<JsonElement> iter = cells.iterator();
        ArrayList<EnodeB> enodeBList = new ArrayList<EnodeB>();
        while (iter.hasNext()) {
            JsonObject o = (JsonObject) iter.next();

            EnodeB enodeB = new EnodeB();
            enodeB.setEnodeBId(o.get("id").getAsString());
            enodeB.setIid(o.get("id").getAsInt());
            enodeB.setEuTranCell_1(o.get("euTranCell_1").getAsBoolean());
            enodeB.setEuTranCell_2(o.get("euTranCell_2").getAsBoolean());
            enodeB.setEuTranCell_3(o.get("euTranCell_3").getAsBoolean());
            enodeB.setCran(true);
            enodeB.setHigherEutrancells(o.get("value").getAsString());

            enodeBList.add(enodeB);
        }

        try {
            // Add new cell group
            if (GeneralUtility.isNonEmpty(groupId) && groupId.equals("-1")) {
                response.setMessages("Cell group " + groupNewName + " already exists!");
                result = JdbcCgaDao.addEnodeBGroup(jdbcDao, user, groupNewName, enodeBList);

            // Update existing cell group
            } else if (GeneralUtility.isNonEmpty(groupId) && !groupId.equals("-1")) {
                if (!GeneralUtility.isNonEmpty(groupNewName)) {
                    groupNewName = groupName;
                }
                response.setMessages("Unable to update cell group!");
                result = JdbcCgaDao.updateEnodeBGroup(jdbcDao, groupId, groupNewName, enodeBList);
            }

        } catch (Exception ex) {

        } finally {
            response.setSuccess(result);
            if (result)
                response.setMessages("");
        }

        return gson.toJson(response);
    }

    @RequestMapping(value = "/cg/deleteCellGroup", method = RequestMethod.POST)
    public @ResponseBody
    String deleteCellGroup(@RequestParam String elementGroupId) throws SQLException {
        boolean retVal = JdbcCgaDao.delEnodeBGroup(jdbcDao, elementGroupId);
        return String.valueOf(retVal);
    }


    @RequestMapping(value = "/cg/getNeighbors", method = RequestMethod.GET)
    public @ResponseBody
    String getNeighborsForEnodeBs(@RequestParam String enodebs, String date, String eutrancells) throws SQLException {
        Gson gson = new GsonBuilder().create();

        ArrayList<Integer> enodeBsForNeighborsListInt = new ArrayList<Integer> ();
        String[] enodeBsForNeighborsArr = enodebs.split(",");
        for (int u=0; u<enodeBsForNeighborsArr.length; u++)
            enodeBsForNeighborsListInt.add(GeneralUtility.getIntValue(enodeBsForNeighborsArr[u]));

        ArrayList<EnodeB> alEnodeB = JdbcEnodeBNeighborsDao.getNeighborsForEnodeBs(jdbcDao, enodeBsForNeighborsListInt, date,
                CellGroupUtil.identifyEutrancellsForEnodeb(eutrancells.split(",")));

        String json = gson.toJson(alEnodeB);

        return json;
    }

    @RequestMapping(value = "/cg/getPublicEnodeBGroups", method = RequestMethod.GET)
    public @ResponseBody
    String getPublicEnodeBGroup(@RequestParam String user) throws SQLException {
        Gson gson = new GsonBuilder().create();

        String json = gson.toJson(JdbcCgaDao.getAllPublicEnodeBGroups(jdbcDao, user));
        return json;
    }

    private ArrayList<ListItem> getEnodebListItems(ArrayList<EnodeB> alEnodeBs, boolean isEutrancellInfoNeeded) {
        ArrayList<ListItem> liEnodebs = new ArrayList<ListItem> ();
        if ( alEnodeBs != null && !alEnodeBs.isEmpty()) {
            for (EnodeB enb : alEnodeBs) {
                ListItem li = new ListItem();
                li.setDescription(enb.getEnodeBName());
                li.setId(String.valueOf(enb.getIid()));
                li.setSelected(false);
                if ( isEutrancellInfoNeeded )
                   // li.setEutrancellsCommaSeparatedList(getEutrancellsForEnodeB(enb));
                liEnodebs.add(li);


            }
        }
        return liEnodebs;
    }

    @RequestMapping(value = "/cg/getOwnersForRegion", method = RequestMethod.GET)
    public @ResponseBody
    String getOwnersForRegion(@RequestParam String user, @RequestParam String region) throws SQLException {
        Gson gson = new GsonBuilder().create();

        return gson.toJson(JdbcCgaDao.getPublicEnodeBGroupsForRegion(jdbcDao, user, region));
    }

    @RequestMapping(value = "/cg/getAllOwnersForRegion", method = RequestMethod.GET)
    public @ResponseBody
    String getAllOwnersForRegion(@RequestParam String region, @RequestParam String user) throws SQLException {
        Gson gson = new GsonBuilder().create();
        return gson.toJson(JdbcCgaDao.getPublicEnodeBGroupsForRegion(jdbcDao, user, region));
    }

    @RequestMapping(value = "/cg/getAllOwners", method = RequestMethod.GET)
    public @ResponseBody
    String getAllOwners(@RequestParam String user) throws SQLException {
        Gson gson = new GsonBuilder().create();

        return gson.toJson(JdbcCgaDao.getOwners(jdbcDao, user));
    }

    @RequestMapping(value = "/cg/getOwnersForMarket", method = RequestMethod.GET)
    public @ResponseBody
    String getOwnersForMarket(@RequestParam String market, @RequestParam String user) throws SQLException {
        Gson gson = new GsonBuilder().create();

        return gson.toJson(JdbcCgaDao.getPublicEnodeBGroupsForMarket(jdbcDao, user, market));
    }

    @RequestMapping(value = "/cg/getAllOwnersForMarket", method = RequestMethod.GET)
    public @ResponseBody
    String getAllOwnersForMarket(@RequestParam String market, @RequestParam String user) throws SQLException {
        Gson gson = new GsonBuilder().create();

        return gson.toJson(JdbcCgaDao.getOwnersForMarket(jdbcDao, user, market));
    }


    @RequestMapping(value = "/cg/getEnodeBGroupsForUser", method = RequestMethod.GET)
    public @ResponseBody
    String getEnodeBGroupsForUser(@RequestParam String owner) throws SQLException {
        Gson gson = new GsonBuilder().create();

        return gson.toJson(JdbcCgaDao.getEnodeBGroupsForUser(jdbcDao, owner));
    }

//    Updating CG with Json Web Token authentication
    @SuppressWarnings("Duplicates")
    @RequestMapping(value="/cg/updateCellGroup", method = RequestMethod.POST, headers = "content-type=application/x-www-form-urlencoded" )
    public  @ResponseBody String  updateCellGroup(@RequestBody String json, HttpServletRequest request) {
        Gson gson = new GsonBuilder().create();
        Boolean result = false;
        JSONResponse response = new JSONResponse();
        JsonParser parser = new JsonParser();
        JsonObject obj = parser.parse(json).getAsJsonObject();

        String owner = obj.get("user").getAsString();
        String groupName = obj.get("groupName").getAsString();
        String groupNewName = obj.get("groupNewName").getAsString();
        String groupId = obj.get("groupId").getAsString();


        // GroupId = -1 to create new CG
        if (groupId.equals("-1")) {


        // Update existing
        } else {
            ElementGroupModel eg = JdbcCgaDao.findByGroupName(jdbcDao, groupName, owner);
            if (eg == null) {
                response.setMessages("Unable to find cell group : " + groupName);
                return gson.toJson(response);
            }
            groupId = Integer.toString(eg.getPkId());
        }


        obj.addProperty("groupId", groupId);
        JsonArray cells = obj.getAsJsonArray("data");
        Iterator<JsonElement> iter = cells.iterator();
        Map<Integer, EnodeB> enodeBMap = new HashMap<Integer, EnodeB>();
        while (iter.hasNext()) {
            JsonObject o = (JsonObject) iter.next();
            if (o.get("eNodeB") == null)
                continue;

            String _eNodeB = o.get("eNodeB").getAsString();
            String _hghrEutrancells = (o.get("eutrancells") != null) ? o.get("eutrancells").getAsString() : "";
            EnodeB enodeB = new EnodeB();
            enodeB.setEnodeBId(_eNodeB);
            enodeB.setCran(true);
            String[] sectors = _hghrEutrancells.split(",");
            String hghrEutrancells = null;
            for (int i = 0; i < sectors.length; i++) {
                if (sectors[i].equals("1")) {
                    enodeB.setEuTranCell_1(true);
                } else if (sectors[i].equals("2")) {
                    enodeB.setEuTranCell_2(true);
                } else if (sectors[i].equals("3")) {
                    enodeB.setEuTranCell_3(true);
                } else {
                    if (GeneralUtility.isEmpty(hghrEutrancells)) {
                        hghrEutrancells = sectors[i];
                    } else {
                        hghrEutrancells = hghrEutrancells + "," + sectors[i];
                    }
                }
            }

            enodeB.setHigherEutrancells(hghrEutrancells);

            enodeBMap.put(Integer.parseInt(_eNodeB), enodeB);
        }

        ArrayList<Integer> list = new ArrayList(enodeBMap.keySet());
        logger.info(list);

        ArrayList<EnodeB> enodeBList = JdbcEnodeBDao.findEnodeBsByEnodebId(jdbcDao, list);
        Iterator it = enodeBList.iterator();
        while (it.hasNext()) {
            EnodeB e = (EnodeB) it.next();
            logger.info(e.getEnodeBName());
            EnodeB x = enodeBMap.get(Integer.parseInt(e.getEnodeBId()));
            if (x != null) {
                e.setEuTranCell_1(x.isEuTranCell_1());
                e.setEuTranCell_2(x.isEuTranCell_2());
                e.setEuTranCell_3(x.isEuTranCell_3());
                e.setHigherEutrancells(x.getHigherEutrancells());
                enodeBMap.remove(Integer.parseInt(e.getEnodeBId()));
            }
        }


        try {
            // Add new cell group
            if (GeneralUtility.isNonEmpty(groupId) && groupId.equals("-1")) {
                response.setMessages("Cell group " + groupNewName + " already exists!");
                result = JdbcCgaDao.addEnodeBGroup(jdbcDao, owner, groupName, enodeBList);

                // Update existing cell group
            } else if (GeneralUtility.isNonEmpty(groupId) && !groupId.equals("-1")) {
                response.setMessages("Unable to update cell group!");
                result = JdbcCgaDao.updateEnodeBGroup(jdbcDao, groupId, GeneralUtility.isNonEmpty(groupNewName) ? groupNewName : groupName, enodeBList);
            }

        } catch (Exception ex) {

        } finally {
            response.setSuccess(result);
            if (result)
                response.setMessages("");
        }

        if (enodeBMap.keySet().size() > 0) {
            response.setMessages("Invalid eNodeB entries:  " + enodeBMap.keySet().toString());
        }


        return gson.toJson(response);
    }

    @SuppressWarnings("Duplicates")
    private EnodeB getEnodeBElement(JsonObject object) {
        String _eNodeB = object.get("id").getAsString();
        String _hghrEutrancells = (object.get("eutrancells") != null) ? object.get("eutrancells").getAsString() : "";

        EnodeB enodeB = new EnodeB();
        enodeB.setEnodeBId(_eNodeB);
        enodeB.setCran(true);
        String[] sectors = _hghrEutrancells.split(",");
        String hghrEutrancells = null;
        for (int i = 0; i < sectors.length; i++) {
            if (sectors[i].equals("1")) {
                enodeB.setEuTranCell_1(true);
            } else if (sectors[i].equals("2")) {
                enodeB.setEuTranCell_2(true);
            } else if (sectors[i].equals("3")) {
                enodeB.setEuTranCell_3(true);
            } else {
                if (GeneralUtility.isEmpty(hghrEutrancells)) {
                    hghrEutrancells = sectors[i];
                } else {
                    hghrEutrancells = hghrEutrancells + "," + sectors[i];
                }
            }
        }

        enodeB.setHigherEutrancells(hghrEutrancells);
        return enodeB;
    }

    @SuppressWarnings("Duplicates")
    @RequestMapping(value="/cg/createOrUpdateCellGroup", method = RequestMethod.POST)
    public  @ResponseBody String  createOrUpdateCellGroupUsingWebService(@RequestBody String json, @RequestParam String user, HttpServletRequest request) {
        Gson gson = new GsonBuilder().create();
        JSONResponse response = new JSONResponse();

        JsonParser parser = new JsonParser();
        JsonObject obj = parser.parse(json).getAsJsonObject();

        if (obj == null) {
            response.setMessages("Request should contain json data.");
            return gson.toJson(response);
        }

        String owner = obj.get("owner") == null ? "" : obj.get("owner").getAsString();
        String cgName = obj.get("groupName") == null ? "" : obj.get("groupName").getAsString();

        if (GeneralUtility.isEmpty(owner) || GeneralUtility.isEmpty(cgName) || obj.getAsJsonArray("data") == null) {
            response.setMessages("Elements owner, groupName and data are required");
            return gson.toJson(response);
        }

        ElementGroupModel eg = JdbcCgaDao.findByGroupName(jdbcDao, cgName, owner);
        String groupId = null;
        if (eg == null) {
            logger.info("No cell group is found! Creating one... " + cgName);
            logger.info("CG Creation via WS (" + cgName + "|" + owner + ") requested by : " + user);
        } else {
            logger.info("CG Update via WS (" + cgName + "|" + owner + ") requested by : " + user);
            groupId = Integer.toString(eg.getPkId());
        }

        try {
            String jwt = WebTokenController.resolveToken(request);
            if (StringUtils.hasText(jwt)) {
                logger.info("JWT: " + jwt);
                response.setSuccess(JWTUtility.validateJWT(jwt, user));
            }
        } catch (Exception name) {
            response.setSuccess(false);
        } finally {
            if (!response.isSuccess()) {
                response.setMessages("Failed to authenticate user: " + user);
                return gson.toJson(response);
            }
        }

        JsonArray cells = obj.getAsJsonArray("data");
        Iterator<JsonElement> iter = cells.iterator();
        Map<Integer, EnodeB> enodeBMap = new HashMap<Integer, EnodeB>();

        while (iter.hasNext()) {
            JsonObject o = (JsonObject) iter.next();
            if (o.get("id") == null)
                continue;

            EnodeB enodeB = getEnodeBElement(o);
            enodeBMap.put(Integer.parseInt(enodeB.getEnodeBId()), enodeB);
        }

        ArrayList<Integer> list = new ArrayList(enodeBMap.keySet());
        ArrayList<EnodeB> enodeBList = JdbcEnodeBDao.findEnodeBsByEnodebId(jdbcDao, list);
        Iterator it = enodeBList.iterator();
        while (it.hasNext()) {
            EnodeB e = (EnodeB) it.next();
            EnodeB _enodeB = enodeBMap.get(Integer.parseInt(e.getEnodeBId()));
            if (_enodeB != null) {
                e.setEuTranCell_1(_enodeB.isEuTranCell_1());
                e.setEuTranCell_2(_enodeB.isEuTranCell_2());
                e.setEuTranCell_3(_enodeB.isEuTranCell_3());
                e.setHigherEutrancells(_enodeB.getHigherEutrancells());
                enodeBMap.remove(Integer.parseInt(e.getEnodeBId()));
            }
        }

        Boolean result = false;
        try {
            // Add new cell group
            if (GeneralUtility.isNonEmpty(groupId)) {
                result = JdbcCgaDao.updateEnodeBGroup(jdbcDao, groupId, cgName, enodeBList);
                if (!result)
                    response.setMessages("Unable to update cell group!");
            } else {
                result = JdbcCgaDao.addEnodeBGroup(jdbcDao, owner, cgName, enodeBList);
                if (!result)
                    response.setMessages("Unable to create new cell group!");
            }

        } catch (Exception ex) {
            response.setMessages("Unable to update or create new cell group! " + ex.getMessage());
        } finally {
            response.setSuccess(result);
        }

        if (enodeBMap.keySet().size() > 0) {
            response.setMessages("Invalid eNodeB entries:  " + enodeBMap.keySet().toString());
        }

        return gson.toJson(response);
    }

}
