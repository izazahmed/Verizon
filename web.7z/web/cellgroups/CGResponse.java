package com.vzw.web.cellgroups;

import bus.location.EnodeB;

import java.util.ArrayList;

/**
 * Created by gundaja on 12/12/16.
 */
public class CGResponse {
    String invalidValues;

    ArrayList<EnodeB> results;

    public String getInvalidValues() {

        return invalidValues;
    }

    public void setInvalidValues(String invalidValues) {
        this.invalidValues = invalidValues;
    }


    public ArrayList<EnodeB> getResults() {
        return results;
    }

    public void setResults(ArrayList<EnodeB> results) {
        this.results = results;
    }
}
