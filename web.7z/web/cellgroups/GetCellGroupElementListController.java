package com.vzw.web.cellgroups;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
import org.vzw.lte.util.CellGroupUtil;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.GeneralUtility;

import bus.ListItem;
import bus.location.EnodeB;
import bus.location.Market;
import db.JdbcDao;
import db.cellgroups.JdbcCgaDao;
import db.location.JdbcEnodeBDao;
import db.location.JdbcEnodeBNeighborsDao;
import db.location.JdbcMarketDao;

public class GetCellGroupElementListController implements Controller {
	
	protected final Log logger = LogFactory.getLog(GetCellGroupElementListController.class); 
	private JdbcDao jdbcDao;
	
	public JdbcDao getJdbcDao() {
		return this.jdbcDao;
	}
	
	public void setJdbcDao(JdbcDao jdbcDao) {
		this.jdbcDao = jdbcDao;
	}

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {

		Map model = new HashMap();
		String type = request.getParameter("type");
		String strRegion = request.getParameter("cgregion");
		String strMarket = request.getParameter("cgmarket");
		String strCellGroup = request.getParameter("cggroup");
		String strEnbsForNeighbors = request.getParameter("enbfornghbrs");
		String strDateForNeighbors = request.getParameter("date");
		String strEutrancellsForNeighbors = request.getParameter("eutrancells");
		String strOwner = request.getParameter("cgowner");
		String strUserName =  (String) request.getSession().getAttribute("session.userid");
		
		if (type != null && "region".equals(type) && strRegion != null && !strRegion.isEmpty()) {
			model.put("elements", getMarketListItemsForRegion(strRegion));
			model.put("showIdDesc", "1");
		}
		else if (type != null && "market".equals(type) && strMarket != null && !strMarket.isEmpty()) {
			model.put("elements", getEnodebListItemsForMarket(strMarket));
			model.put("showIdDesc", "1");
		}
		else if (type != null && "group".equals(type) && strCellGroup != null && !strCellGroup.isEmpty()) {
			model.put("elements", getEnodebListItemsForCellGroup(strCellGroup));
			model.put("groupEnbsAndCells", "1");
			model.put("isGroupList", "1");
		}
		else if (type != null && "neighbors".equals(type) && strEnbsForNeighbors != null && !strEnbsForNeighbors.isEmpty()
				&& strDateForNeighbors != null && !strDateForNeighbors.isEmpty()
				&& strEutrancellsForNeighbors != null && !strEutrancellsForNeighbors.isEmpty()) {
			model.put("elements", getNeighboringEnodebListItems(strEnbsForNeighbors, strDateForNeighbors, strEutrancellsForNeighbors));
			model.put("groupEnbsAndCells", "1");
			model.put("isNeighborList", "1");
		}
		else if (type != null && "mktgroups".equals(type) && strMarket != null && !strMarket.isEmpty() 
				&& strUserName != null && !strUserName.isEmpty()) {
			model.put("elements", getGroupListItemsForMarket(strMarket, strUserName));
			model.put("showIdDesc", "1");
		}
		else if (type != null && "rgngroups".equals(type) && strRegion != null && !strRegion.isEmpty()
				&& strUserName != null && !strUserName.isEmpty()) {
			model.put("elements", getGroupListItemsForRegion(strRegion, strUserName));
			model.put("showIdDesc", "1");
		}
		else if (type != null && "ownergroups".equals(type) && strOwner != null && !strOwner.isEmpty()) {
			model.put("elements", getGroupListItemsForOwner(strOwner));
			model.put("showIdDesc", "1");			
		}
		else if (type != null && "allgroups".equals(type) && strUserName != null && !strUserName.isEmpty()) {
			model.put("elements", getAllPublicGroupListItems(strUserName));
			model.put("showIdDesc", "1");			
		}
		else if (type != null && "mktowners".equals(type) && strUserName != null && !strUserName.isEmpty()) {
			if (strMarket != null && !strMarket.isEmpty()) {
				model.put("elements", getOwnersForMarket(strMarket, strUserName));
				model.put("showIdDesc", "1");
			}			
		}
		else if (type != null && "allowners".equals(type) && strUserName != null && !strUserName.isEmpty()) {
			model.put("elements", getAllOwners(strUserName));
			model.put("showIdDesc", "1");
		}
		return new ModelAndView("getElementList", model);
	}
	
	private ArrayList<ListItem> getMarketListItemsForRegion(String strRegion) {
		ArrayList<ListItem> liMarket = new ArrayList<ListItem> ();
		ArrayList<Market> alMarket = JdbcMarketDao.populateMarketsByRegion(jdbcDao, strRegion);
		if ( alMarket != null && !alMarket.isEmpty()) {
			for (Market mkt : alMarket) {
				ListItem li = new ListItem();
				li.setDescription(mkt.getMarketName());
				li.setId(String.valueOf(mkt.getIid()));
				li.setSelected(false);
				liMarket.add(li);
			}
		}
		return liMarket;
	}
	
	private ArrayList<ListItem> getEnodebListItemsForMarket(String strMarket) {		
		ArrayList<ListItem> liEnodeBs = getEnodebListItems(JdbcEnodeBDao.populateEnodeBsByMarket(jdbcDao, strMarket, null), false);		
		return liEnodeBs;
	}
	
	private ArrayList<ListItem> getEnodebListItemsForCellGroup(String strCellGroup) {		
		ArrayList<String> al = new ArrayList<String> ();
		al.add(strCellGroup);
		ArrayList<ListItem> liEnodebs = getEnodebListItems((ArrayList) JdbcCgaDao.getEnodeBsForGroups(jdbcDao, al), true);		
		return liEnodebs;
	}
	
	private ArrayList<ListItem> getEnodebListItems(ArrayList<EnodeB> alEnodeBs, boolean isEutrancellInfoNeeded) {
		ArrayList<ListItem> liEnodebs = new ArrayList<ListItem> ();
		if ( alEnodeBs != null && !alEnodeBs.isEmpty()) {
			for (EnodeB enb : alEnodeBs) {
				ListItem li = new ListItem();
				li.setDescription(enb.getEnodeBName());
				li.setId(String.valueOf(enb.getIid()));
				li.setSelected(false);
				if ( isEutrancellInfoNeeded )
					li.setEutrancellsCommaSeparatedList(getEutrancellsForEnodeB(enb));
				liEnodebs.add(li);
				
					
			}
		}
		return liEnodebs;
	}

	private ArrayList<ListItem> getNeighboringEnodebListItems(String strEnbsForNeighbors, String strDateForNeighbors, String strEutrancellsForNeighbors) {
		ArrayList<Integer> enodeBsForNeighborsListInt = new ArrayList<Integer> ();
		String[] enodeBsForNeighborsArr = strEnbsForNeighbors.split(",");
		for (int u=0; u<enodeBsForNeighborsArr.length; u++)
			enodeBsForNeighborsListInt.add(GeneralUtility.getIntValue(enodeBsForNeighborsArr[u]));
		
		ArrayList<EnodeB> alEnodeB = JdbcEnodeBNeighborsDao.getNeighborsForEnodeBs(jdbcDao, enodeBsForNeighborsListInt, strDateForNeighbors, 
				CellGroupUtil.identifyEutrancellsForEnodeb(strEutrancellsForNeighbors.split(",")));
		
		ArrayList<ListItem> liEnodebs = getEnodebListItems(alEnodeB, true);
		return liEnodebs;
	}
	
	private String getEutrancellsForEnodeB(EnodeB enb) {
		StringBuffer sb = new StringBuffer();
		if ( enb != null ) {
			if ( enb.isEuTranCell_1()) sb.append("Y");
			else sb.append("N");
			
			if ( enb.isEuTranCell_2()) sb.append(",Y");
			else sb.append(",N");
			
			if ( enb.isEuTranCell_3()) sb.append(",Y");
			else sb.append(",N");
			
			String higherEucells = enb.getHigherEutrancells();
//			logger.debug("higherEucells = " + higherEucells);
			if ( higherEucells != null && higherEucells.length() >= 8) {
				//int lengthHigherCellsOnly = EnvironmentUtil.getEutrancellsArray().length - 3;
				int lengthHigherCellsOnly = 6;
				for ( int i=0; i<lengthHigherCellsOnly  ; i++ ) {
					if (higherEucells.charAt(i) == 'N') {
						sb.append(",N");
					}
					else if (higherEucells.charAt(i) == 'Y') {
						sb.append(",Y");
					}
					else {
						sb.append(",N");
					}
					//sb.append(",").append(higherEucells.charAt(i));
				}
			}
		}		
//		logger.debug("sb = " + sb.toString());
		return sb.toString();
	}

	private ArrayList<ListItem> getGroupListItemsForMarket(String strMarket, String strUser) {
		ArrayList alMktGroups = (ArrayList) JdbcCgaDao.getPublicEnodeBGroupsForMarket(jdbcDao, strUser, strMarket);
		return alMktGroups;
	}
	
	private ArrayList<ListItem> getGroupListItemsForRegion(String strRegion, String strUser) {
		ArrayList alRgnGroups = (ArrayList) JdbcCgaDao.getPublicEnodeBGroupsForRegion(jdbcDao, strUser, strRegion);
		return alRgnGroups;
	}
	
	private ArrayList<ListItem> getGroupListItemsForOwner(String strOwner) {
		ArrayList alOwnerGroups = (ArrayList) JdbcCgaDao.getEnodeBGroupsForUser(jdbcDao, strOwner);
		return alOwnerGroups;
	}
	
	private ArrayList<ListItem> getAllPublicGroupListItems(String strUser) {
		ArrayList alAllGroups = (ArrayList) JdbcCgaDao.getAllPublicEnodeBGroups(jdbcDao, strUser);
		return alAllGroups;
	}
	
	private ArrayList<ListItem> getOwnersForMarket(String strMarket, String strUser) {
		ArrayList alMktOwners = (ArrayList) JdbcCgaDao.getOwnersForMarket(jdbcDao, strUser, strMarket);
		return alMktOwners;
	}
	
	private ArrayList<ListItem> getAllOwners( String strUser) {
		ArrayList alAllOwners = (ArrayList) JdbcCgaDao.getOwners(jdbcDao, strUser);
		return alAllOwners;
	}
}
