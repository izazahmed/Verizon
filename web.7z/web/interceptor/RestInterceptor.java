package com.vzw.web.interceptor;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.vzw.ns.util.JWTUtility;
import com.vzw.web.exception.*;
import com.vzw.web.services.WebTokenController;

import web.exception.WebTokenException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RestInterceptor implements HandlerInterceptor {
    protected final Log logger = LogFactory.getLog(this.getClass());

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        Boolean rv = false;

        HandlerMethod handlerMethod = (HandlerMethod) handler;
        TokenRequired tokenRequired = handlerMethod.getMethod().getAnnotation(TokenRequired.class);
        if (tokenRequired == null) {
            return true;
        }

        // TODO: Implement authentication based off user credentials
        try {
            String jwt = WebTokenController.resolveToken(request);
            if (StringUtils.hasText(jwt)) {
                logger.info("Validating JWT: " + jwt);
                rv = JWTUtility.validateJWT(jwt, "hq");
            }
        } catch (Exception name) {
            logger.info("Error here: " + name.toString());
            throw new WebTokenException("Invalid or expired web token");
        }

        return rv;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }

}
