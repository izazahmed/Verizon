/*************************************************************************
 * SetupTreeController.java
 *
 * Change History
 * Date         Who     Description
 * -----------------------------------------------------------------------
 * 08/10/2011   rwhites Add support for reportUsage.
 * 01/18/2012   rwhites Added synchronization to SetupTree access functions.
 **********************************************************************/
package com.vzw.web.tree;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
import org.vzw.lte.util.ClearCacheUtil;

import bus.tree.SetupTree;
import db.JdbcDao;
import db.tree.JdbcSetupTreeDao;

public class SetupTreeController implements Controller  
{

    /** Logger for this class and subclasses */
    protected static final Log logger = LogFactory.getLog(SetupTreeController.class);

    private JdbcDao jdbcDao;

    public void setJdbcDao(JdbcDao jdbcDao)
    {
        this.jdbcDao = jdbcDao;
    }

    //cache these
    public static ArrayList<SetupTree> dtree = null;
    public static ArrayList<SetupTree> otree = null;
    public static ArrayList<SetupTree> ftree = null;
    public static ArrayList<SetupTree> regionTree = null;

    public ModelAndView handleRequest(HttpServletRequest request,
                                      HttpServletResponse response)
    throws ServletException, IOException     
    { 	    	
        // 5/7/2008 WWN - only load data that you need.

        List rtree = new ArrayList();
        List rftree = new ArrayList();

        String formType = request.getParameter("type");
        String formAction = request.getParameter("action");
        // System.out.println("formAction: "+formAction);
        String reportUsage = request.getParameter("reportUsage");
        String elemType = request.getParameter("elemType");

        Map model = new HashMap();

        if (formType.equals("formula")) 
        {
            if (formAction.equals("view")) 
            {
                model.put("treeRoot", "All Formulas");
                model.put("divtag", "viewDivTreeF");
                model.put("viewReport_Formula", "1");
                model.put("viewFormulaTree","1");
                model.put("viewVariable", "formula");								
                model.put("showUsers", "0");
                model.put("showOMFormulaC", "0");
                model.put("showOMFormulaE", "0");		

                buildCachedTrees();
                rftree = (ArrayList<SetupTree>)JdbcSetupTreeDao.setupTreeByType(jdbcDao, "formula");
            }
            else if (formAction.equals("create"))
            {
                model.put("treeRoot", "Formula Elements");
                model.put("divtag", "createDivTreeF");
                model.put("showOMFormulaC", "1");				
                model.put("showOMFormulaE", "0");
                model.put("viewReport_Formula", "0");
                model.put("showUsers", "0");				

                buildCachedTrees();
            }
            else if(formAction.equals("edit"))
            {
                model.put("treeRoot", "Formula Elements");
                model.put("divtag", "editDivTreeF");
                model.put("showOMFormulaE", "1");
                model.put("showOMFormulaC", "0");
                model.put("viewReport_Formula", "0");
                model.put("showUsers", "0");				

                buildCachedTrees();
            }
        }
        else if (formType.equals("report")) 
        {
            if (formAction.equals("view")) 
            {
                if ("Config".equals(elemType))
                    model.put("treeRoot", "All Configs");				
                else
                    model.put("treeRoot", "All Reports");				
                model.put("divtag", "viewDivTree");
                model.put("viewReport_Formula", "1");
                model.put("viewVariable", "report");				
                model.put("showUsers", "0");				
                model.put("showOMFormulaC", "0");
                model.put("showOMFormulaE", "0");
                model.put("reportUsage", reportUsage);

                buildCachedTrees();
                rftree = JdbcSetupTreeDao.setupTreeByType(jdbcDao, "report");
            }
            else if (formAction.equals("create")) 
            {
                if ("Config".equals(elemType))
                    model.put("treeRoot", "Config Elements");
                else
                    model.put("treeRoot", "Report Elements");
                model.put("divtag", "createDivTree");
                model.put("showOMFormulaC", "1");
                model.put("report_create_tab", "1");
                model.put("viewReport_Formula", "0");
                model.put("showUsers", "0");				
                model.put("showOMFormulaE", "0");				

                buildCachedTrees();
            }
            else if (formAction.equals("edit")) 
            {
                if ("Config".equals(elemType))
                    model.put("treeRoot", "Config Elements");
                else
                    model.put("treeRoot", "Report Elements");
                model.put("divtag", "editDivTree");
                model.put("showOMFormulaE", "1");				
                model.put("viewReport_Formula", "0");
                model.put("showUsers", "0");				

                buildCachedTrees();
            }
        }
        else 
        { // report browser
            model.put("treeRoot", "Browse Reports");				
            model.put("divtag", "reportBrowserTree");
            model.put("showUsers", "1");
            model.put("viewReport_Formula", "0");				
            model.put("showOMFormulaC", "0");
            model.put("showOMFormulaE", "0");				

            buildCachedTrees();
            rtree = JdbcSetupTreeDao.setupTreeByType(jdbcDao, "report");
        }

        model.put("regionTree", regionTree);
        model.put("dtree", dtree);
        model.put("otree", otree);
        model.put("ftree", ftree);
        model.put("rtree", rtree);
        model.put("rftree", rftree); //new common for rep builder and formula builder

        return new ModelAndView("setupTree", model);
    }

    /*
    * This method will be called from clear cache data tool
    */
    public static synchronized void clearData() {
        logger.debug("Clearing cache");
        regionTree = null;
        dtree = null;
        otree = null;
        ftree = null;
        logger.debug("Cleared cache");
    }

    /**
     * Build the cached data trees if they do not exist.
     */
    private void buildCachedTrees()
    {
        synchronized (getClass())
        {
            Date startTime;

            if (regionTree == null)
            {
                startTime = new Date();
                regionTree = (ArrayList<SetupTree>)JdbcSetupTreeDao.setupTreeByType(jdbcDao, "region");
                ClearCacheUtil.logCacheBuildTime("SetupTreeController", "regionTree",
                                                 startTime, new Date());
            }

            if (otree == null)
            {
                startTime = new Date();
                otree = (ArrayList<SetupTree>)JdbcSetupTreeDao.setupTreeByType(jdbcDao, "om");
                ClearCacheUtil.logCacheBuildTime("SetupTreeController", "otree",
                                                 startTime, new Date());
            }

            if (dtree == null)
            {
                startTime = new Date();
                dtree = (ArrayList<SetupTree>)JdbcSetupTreeDao.setupTreeByType(jdbcDao, "dataSource");
                ClearCacheUtil.logCacheBuildTime("SetupTreeController", "dtree",
                                                 startTime, new Date());
            }

            if (ftree == null)
            {
                startTime = new Date();
                ftree = (ArrayList<SetupTree>)JdbcSetupTreeDao.setupTreeByType(jdbcDao, "formula");
                ClearCacheUtil.logCacheBuildTime("SetupTreeController", "ftree",
                                                 startTime, new Date());
            }
        }
    }
}
