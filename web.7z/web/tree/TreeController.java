package com.vzw.web.tree;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import db.JdbcDao;
import db.tree.JdbcTreeDao;

/**
 * 
 * @author  not in use
 * 
 */
public class TreeController implements Controller  
{

    /** Logger for this class and subclasses */
    protected final Log logger = LogFactory.getLog(getClass());
    
    
    private JdbcDao jdbcDao;
    
    public void setJdbcDao(JdbcDao jdbcDao)
    {
        this.jdbcDao = jdbcDao;
    }
 
    public ModelAndView handleRequest(HttpServletRequest request,
                                      HttpServletResponse response)
    throws ServletException, IOException     
     
    { 	    	
        String treeType = request.getParameter("type");
        String userName = request.getParameter("userName");
        String folderId = request.getParameter("folderId");
        String includeSah = request.getParameter("includeSah");
        String includeWSReports = request.getParameter("includeWSReports");
        String reportUsage = request.getParameter("reportUsage");
        List branches = 
        	JdbcTreeDao.drawTreeByType(jdbcDao, treeType, userName, includeSah, includeWSReports, folderId, reportUsage);
            
        return new ModelAndView("tree", "branches", branches);
    }
}
