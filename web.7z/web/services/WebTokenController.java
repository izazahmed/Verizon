package com.vzw.web.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.vzw.ns.util.JWTUtility;
import com.vzw.web.cellgroups.JSONResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by gundaja on 11/7/17.
 */
@Controller
public class WebTokenController {
    protected final Log logger = LogFactory.getLog(this.getClass());


    @RequestMapping(value = "/auth/getToken", method = RequestMethod.GET)
    public @ResponseBody
    String getToken(HttpServletRequest request)  {
        Gson gson = new GsonBuilder().create();

        HttpSession session = request.getSession();
        String user = (String) session.getAttribute("session.userid");
        JSONResponse response = new JSONResponse();
        response.setSuccess(false);

        if (user == null) {
            response.setMessages("User is not yet authenticated. This is meant to be called via the front-end UI.");
        }  else {
            String jwt = JWTUtility.createJWT(user);
            response.setSuccess(true);
            response.setMessages(jwt);
        }

        return gson.toJson(response);
    }

    @RequestMapping(value = "/auth/validate", method = RequestMethod.GET)
    public @ResponseBody
    String validateToken(HttpServletRequest request, @RequestParam String user)  {
        Gson gson = new GsonBuilder().create();
        JSONResponse response = new JSONResponse();
        String jwt;

        try {
            jwt = this.resolveToken(request);
            if (StringUtils.hasText(jwt)) {
                response.setSuccess(JWTUtility.validateJWT(jwt, user));
            }
            logger.info(gson.toJson(JWTUtility.parseJWT(jwt)));
        } catch (Exception name) {
            response.setMessages("Unable to authenticate: " + name.getMessage());
            return gson.toJson(response);
        }

        return gson.toJson(JWTUtility.parseJWT(jwt));
    }

    public static String resolveToken(HttpServletRequest request) {

        String bearerToken = request.getHeader(JWTUtility.AUTHORIZATION_HEADER);

        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            System.out.println("key: " + key + " value: " + value);
        }

        if (bearerToken != null && StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            String jwt = bearerToken.substring(7, bearerToken.length());
            return jwt;
        }
        return null;
    }

    private Map<String, String> getHeadersInfo(HttpServletRequest request) {

        Map<String, String> map = new HashMap<String, String>();

        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            map.put(key, value);
        }

        return map;
    }


}
