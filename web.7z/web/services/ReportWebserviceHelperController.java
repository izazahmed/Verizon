/**
 * 
 */
package com.vzw.web.services;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
import org.vzw.lte.dao.DBLocationsDAO;
import org.vzw.lte.model.MME;
import org.vzw.lte.model.RegionMmePoolViewModel;
import org.vzw.lte.model.SGW;
import org.vzw.lte.util.ReportTypeConstants;

import bus.location.Market;
import db.JdbcDao;
import db.JdbcReportLevelDao;

/**
 * @author amit.chauhan Sep 23, 2010
 */
public class ReportWebserviceHelperController implements Controller {
	protected final Log logger = LogFactory.getLog(this.getClass());

	private JdbcDao jdbcDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.mvc.Controller#handleRequest(javax.servlet.
	 * http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		Map refMap = new HashMap();
		refMap.put("rpttypes", ReportTypeConstants.LIST_OF_ALL_REPORT_TYPES);
		refMap.put("rptlevels", JdbcReportLevelDao.getReportLevels(jdbcDao));
		LinkedHashMap<String, RegionMmePoolViewModel> mapWithRegionIidAsKey = DBLocationsDAO
				.populateRegionMmePoolView(jdbcDao);
		refMap.put("mapWithRegionIidAsKey", mapWithRegionIidAsKey);
		LinkedHashMap<String, MME> mmeMap = DBLocationsDAO.populateMMEMap(jdbcDao);
		refMap.put("mmeMap", mmeMap);
		LinkedHashMap<String, SGW> sgwMap = DBLocationsDAO.populateSGWMap(jdbcDao);
		refMap.put("sgwMap", sgwMap);
		LinkedHashMap<String, Market> marketMap = DBLocationsDAO.populateMarketMap(jdbcDao);
		refMap.put("marketMap", marketMap);
		return new ModelAndView("rptWebServiceHelp", refMap);
	}

	/**
	 * @return the jdbcDao
	 */
	public JdbcDao getJdbcDao() {
		return jdbcDao;
	}

	/**
	 * @param jdbcDao the jdbcDao to set
	 */
	public void setJdbcDao(JdbcDao jdbcDao) {
		this.jdbcDao = jdbcDao;
	}

}
