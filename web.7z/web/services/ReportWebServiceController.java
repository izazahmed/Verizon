/**
 * 
 */
package com.vzw.web.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.vzw.lte.action.ReportEngine;
import org.vzw.lte.dao.ReportInstanceDAO;
import org.vzw.lte.model.ReportEngineModel;
import org.vzw.lte.model.ReportInputParamsModel;
import org.vzw.lte.model.ReportInstanceModel;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.GeneralUtility;
import org.vzw.lte.util.GlobalConstants;

import bus.report.Report;
import db.JdbcDao;
import db.report.JdbcReportDao;
import org.vzw.lte.util.HttpRequestUtil;
import web.services.ReportWebServiceUtil;

// FA 12/23/2013
// FA 12/23/2013
/**
 * @author amit.chauhan Jul 14, 2010
 */
public class ReportWebServiceController {// implements Controller {
	protected final Log logger = LogFactory.getLog(this.getClass());

	private JdbcDao jdbcDao;

	/**
	 * @param jdbcDao the jdbcDao to set
	 */
	public void setJdbcDao(JdbcDao jdbcDao) {
		this.jdbcDao = jdbcDao;
	}

	

	public String handlePullRequest(HttpServletRequest request, HttpServletResponse response, ArrayList<String> errors)
			throws Exception {
		String reportId = ReportWebServiceUtil.fetchReportId(request);
		String reportName = ReportWebServiceUtil.fetchReportName(request);
		String userName = ReportWebServiceUtil.fetchUserName(request);
		String httpPath = null;

		BigDecimal reportIdToUse = BigDecimal.valueOf(0);

		if (!ReportWebServiceUtil.validateUserAndPermissions(jdbcDao, userName, errors))
			return null;

		if (reportId != null && GeneralUtility.isValidIntValue(reportId)) {
			reportIdToUse = new BigDecimal(reportId);
		} else {
			// try and pull report id from report table based on report name and report
			// owner.
			reportIdToUse = JdbcReportDao.pullReportIdByReportName(jdbcDao, reportName, userName);
		}

		if (reportIdToUse.compareTo(new BigDecimal(0)) <= 0) {
			// Unable to determine the report id. Return the control.
			errors.add("Invalid Parameter in Report web service URL.");
			errors.add("Unable to determine the report for ID: " + reportId + " | Name: " + reportName + " | Owner: " + userName);
			return null;
		}

		ReportInstanceModel model = ReportInstanceDAO.getLatestReportInstance(jdbcDao, String.valueOf(reportIdToUse),
				userName);
		if (model != null) {
			httpPath = model.getLocation();
		}
		return httpPath;
	}

	public String handleExecuteRequest(HttpServletRequest request, HttpServletResponse response,
			ArrayList<String> errors) throws Exception {
		String reportId = ReportWebServiceUtil.fetchReportId(request);
		String reportName = ReportWebServiceUtil.fetchReportName(request);
		String userName = ReportWebServiceUtil.fetchUserName(request);

		BigDecimal reportIdToUse = BigDecimal.valueOf(0);

		if (!ReportWebServiceUtil.validateUserAndPermissions(jdbcDao, userName, errors))
			return null;

		if (reportId != null && GeneralUtility.isValidIntValue(reportId)) {
			reportIdToUse = new BigDecimal(reportId);
		} else {
			// try and pull report id from report table based on report name and report
			// owner.
			reportIdToUse = JdbcReportDao.pullReportIdByReportName(jdbcDao, reportName, userName);
		}

		if (reportIdToUse.compareTo(new BigDecimal(0)) <= 0) {
			// Unable to determine the report id. Return the control.
			errors.add("Invalid Parameter in Report web service URL.");
			errors.add("Unable to determine the report for ID: " + reportId + " | Name: " + reportName + " | Owner: " + userName);
			return null;
		}

		ReportEngineModel reportEngineModel = null;
		ReportEngine reportEngine = new ReportEngine();
		ReportInputParamsModel reportInputParamsModel = new ReportInputParamsModel();
		reportInputParamsModel.setUserId(userName);
		reportInputParamsModel.setReportId(reportIdToUse.toString());
		reportInputParamsModel.setCreateCSVFile(false);
		reportInputParamsModel.setWebSvcReport(true);
		reportInputParamsModel.setReportWebserviceUrl(
				request.getRequestURL().append("?").append(request.getQueryString()).toString());
		// FA 12/23/2013
		reportInputParamsModel.setRptMethod(GlobalConstants.RPTMETHOD_WEBSERVICE);
		// FA 12/23/2013

		String rttPercent = ReportWebServiceUtil.fetchRttPercent(request);
		if (!GeneralUtility.isEmpty(rttPercent)) {
			reportInputParamsModel.setRttPercent(Long.parseLong(rttPercent));
		}

		// NTSCA-1503
		reportInputParamsModel.setUserSourceIp(HttpRequestUtil.getClientIP(request));

		reportEngineModel = reportEngine.populateData(this.jdbcDao, reportInputParamsModel);
		return reportEngineModel.getHttpPathForCSVFile();
	}

	public String handleExecuteLastHrRequest(HttpServletRequest request, HttpServletResponse response,
			ArrayList<String> errors) throws Exception {
		String reportId = ReportWebServiceUtil.fetchReportId(request);
		String reportName = ReportWebServiceUtil.fetchReportName(request);
		String userName = ReportWebServiceUtil.fetchUserName(request);
		String tmplUserName = ReportWebServiceUtil.fetchUserNameFromTemplateReqParam(request);

		BigDecimal reportIdToUse = BigDecimal.valueOf(0);

		if (!ReportWebServiceUtil.validateUserAndPermissions(jdbcDao, userName, errors))
			return null;

		if (reportId != null && GeneralUtility.isValidIntValue(reportId)) {
			reportIdToUse = new BigDecimal(reportId);
		} else {
			// try and pull report id from report table based on report name and report
			// owner.
			reportIdToUse = JdbcReportDao.pullReportIdByReportName(jdbcDao, reportName, userName);
		}
		if (reportIdToUse == BigDecimal.valueOf(0) && StringUtils.isNotBlank(tmplUserName) && StringUtils.isNotEmpty(tmplUserName)) {
			// try and pull report id from report table based on report name and report
			// owner.
			reportIdToUse = JdbcReportDao.pullReportIdByReportName(jdbcDao, reportName, tmplUserName);
		}

		if (reportIdToUse.compareTo(new BigDecimal(0)) <= 0) {
			// Unable to determine the report id. Return the control.
			errors.add("Invalid Parameter in Report web service URL.");
			errors.add("Unable to determine the report for ID: " + reportId + " | Name: " + reportName + " | Owner: " + tmplUserName);
			return null;
		}

		if (!StringUtils.equalsIgnoreCase(userName, "sqm")) {
			Report report = null;
			report = JdbcReportDao.selectReportById(jdbcDao, String.valueOf(reportIdToUse));

			// We will now override parameters user has sent as part of url.
			ReportWebServiceUtil.overrideObjWithNewReqParamValues(jdbcDao, report, request);

			//NTSCA-1762
			if(ReportWebServiceUtil.validateReportParameters(report, errors)){
				return null;
			}

			// create the new report
			BigDecimal newReportId = JdbcReportDao.createReport(jdbcDao, report, true);
			reportIdToUse = newReportId;
		}

		ReportEngineModel reportEngineModel = null;
		ReportEngine reportEngine = new ReportEngine();
		ReportInputParamsModel reportInputParamsModel = new ReportInputParamsModel();
		reportInputParamsModel.setUserId(userName);
		reportInputParamsModel.setReportId(reportIdToUse.toString());
		reportInputParamsModel.setCreateCSVFile(false);
		reportInputParamsModel.setWebSvcReport(true);
		reportInputParamsModel.setReportWebserviceUrl(
				request.getRequestURL().append("?").append(request.getQueryString()).toString());
		reportInputParamsModel.setDataForLastHr(true);
		// FA 12/23/2013
		reportInputParamsModel.setRptMethod(GlobalConstants.RPTMETHOD_WEBSERVICE);
		// FA 12/23/2013

		String rttPercent = ReportWebServiceUtil.fetchRttPercent(request);
		if (!GeneralUtility.isEmpty(rttPercent)) {
			reportInputParamsModel.setRttPercent(Long.parseLong(rttPercent));
		}

		// NTSCA-1503
		reportInputParamsModel.setUserSourceIp(HttpRequestUtil.getClientIP(request));

		reportEngineModel = reportEngine.populateData(this.jdbcDao, reportInputParamsModel);
		return reportEngineModel.getHttpPathForCSVFile();
	}

	public void fetchFile(String filePath, String formate, HttpServletResponse response,ArrayList<String> errors) throws IOException {
		InputStream in = null;
		ServletOutputStream outs = null;
		try {
			String nameForSavingFile = "default.csv";

			if (GeneralUtility.isNonEmpty(filePath)) {
				filePath = filePath.replace("xls", "csv");
				nameForSavingFile = filePath.substring(filePath.lastIndexOf("/") + 1);
			}

			// setting some response headers
			response.setHeader("Expires", "0");
			response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
			response.setHeader("Pragma", "public");
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nameForSavingFile + "\"");
			// setting the content type
			response.setContentType("application/csv");

			if(GeneralUtility.isEmpty(filePath) || errors.size() > 0){
				outs =  response.getOutputStream();
				outs.println("Sorry we encountered error while running your report. Please check the error message and try again.");
				outs.println("");
				outs.println("Error Details:");
				for (String msg : errors) {
					outs.println(msg);
				}
				Iterator<String> itr = this.getTextForFAQ().iterator();
				while (itr.hasNext()) {
					outs.println(itr.next());
				}
				outs.flush();
			} else {
				File file = new File(filePath);
				in = FileUtils.openInputStream(file);
				IOUtils.copy(in, response.getOutputStream());
				response.flushBuffer();
			}
		} catch (IOException e) {
			logger.error("fetchFile -> " + filePath + " -> " + formate + " Not found");
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
				if (outs != null) {
					outs.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void sendHTML(HttpServletRequest request, HttpServletResponse response, String httpPathOfFile,
			ArrayList<String> errors) {
		BufferedReader in = null;
		PrintWriter outs = null;
		try {
			// setting the content type
			response.setContentType("text/html");
			outs = response.getWriter();
			logger.debug("content type:[text/html]");

			if (GeneralUtility.isEmpty(httpPathOfFile) || errors.size() > 0) {
				outs.println("Unable to pull report.");
				for (String msg : errors) {
					outs.println(msg);
				}
				Iterator<String> itr = this.getTextForFAQ().iterator();
				while (itr.hasNext()) {
					outs.println(itr.next());
				}
			} else {
				URL url = new URL(httpPathOfFile);
				URLConnection urlConn = url.openConnection();
				in = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
				String inputLine = null;
				while ((inputLine = in.readLine()) != null) {
					if (GeneralUtility.isNonEmpty(inputLine)) {
						outs.println(inputLine);
					}
				}
			}
			outs.flush();
		} catch (Exception e2) {
			logger.error("Error in " + getClass().getName() + "\n" + e2);
			e2.printStackTrace();
		} finally {
			try {
				if (in != null) {
					// flush and close both "input" and its underlying FileReader
					in.close();
				}
				if (outs != null) {
					outs.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	private ArrayList<String> getTextForFAQ() {
		ArrayList<String> faq = new ArrayList<String>();
		faq.add("");
		faq.add("Please visit our Wiki page for more details about our service:");
		faq.add("https://oneconfluence.verizon.com/display/JHTSS/4G+xLPT+Report+Webservice");
		return faq;
	}

	public String handleExecuteTemplateRequest(HttpServletRequest request, HttpServletResponse response,
			ArrayList<String> errors) throws Exception {
		String tmplReportId = ReportWebServiceUtil.fetchReportIdFromTemplate(request);
		String tmplRptName = ReportWebServiceUtil.fetchReportNameFromTemplateReqParam(request);
		String tmplUserName = ReportWebServiceUtil.fetchUserNameFromTemplateReqParam(request);
		String userName = ReportWebServiceUtil.fetchUserName(request);

		if (!ReportWebServiceUtil.validateUserAndPermissions(jdbcDao, userName, errors))
			return null;

		//check if web service report exceeds the daily/hourly quota
		if(!JdbcReportDao.isReportCountInLimit(jdbcDao, userName)) {
			int maxAllowedReports = JdbcReportDao.getReportCountLimit(jdbcDao, userName);
			String message = "User: " + userName + " has reached Max # of web service requests/hr which is currently set to: " + maxAllowedReports;
			logger.error(message);
			errors.add(message);
			return null;
		}

		BigDecimal tmplReportIdToUse = BigDecimal.valueOf(0);

		if (tmplReportId != null && GeneralUtility.isValidIntValue(tmplReportId)) {
			tmplReportIdToUse = new BigDecimal(tmplReportId);
		} else {
			// try and pull report id from report table based on report name and report
			// owner.
			tmplReportIdToUse = JdbcReportDao.pullReportIdByReportName(jdbcDao, tmplRptName, tmplUserName);
		}

		logger.debug("Report id identified:[" + tmplReportIdToUse + "]");

		if (tmplReportIdToUse.compareTo(new BigDecimal(0)) <= 0) {
			// Unable to determine the report id. Return the control.
			errors.add("Invalid Parameter in Report web service URL.");
			errors.add("Unable to determine the report for ID: " + tmplReportId + " | Name: " + tmplRptName + " | Owner: " + tmplUserName);
			return null;
		}

		Report report = null;
		report = JdbcReportDao.selectReportById(jdbcDao, String.valueOf(tmplReportIdToUse));

		// We will now override parameters user has sent as part of url.
		ReportWebServiceUtil.overrideObjWithNewReqParamValues(jdbcDao, report, request);

		//NTSCA-1762
		if(ReportWebServiceUtil.validateReportParameters(report, errors)){
			return null;
		}

		// create the new report
		BigDecimal newReportId = JdbcReportDao.createReport(jdbcDao, report, true);

		// we have setup a new report from template above. Now lets execute the report.
		ReportEngineModel reportEngineModel = null;
		ReportEngine reportEngine = new ReportEngine();
		ReportInputParamsModel reportInputParamsModel = new ReportInputParamsModel();
		reportInputParamsModel.setUserId(report.getUserName());
		reportInputParamsModel.setReportId(newReportId.toString());
		reportInputParamsModel.setCreateCSVFile(false);
		reportInputParamsModel.setWebSvcReport(true);
		reportInputParamsModel.setReportWebserviceUrl(
				request.getRequestURL().append("?").append(request.getQueryString()).toString());
		// To Uniquely naming the report name if two requests have same user name, start
		// time and end time
		reportInputParamsModel.setFileNameExt(String.valueOf(newReportId));
		// FA 12/23/2013
		reportInputParamsModel.setRptMethod(GlobalConstants.RPTMETHOD_WEBSERVICE);
		// FA 12/23/2013
		reportInputParamsModel.setDispNullVal(report.getDispNullVal());
		reportInputParamsModel.setNumOfHrOrMin(report.getNumOfHrOrMin());

		String rttPercent = ReportWebServiceUtil.fetchRttPercent(request);
		if (!GeneralUtility.isEmpty(rttPercent)) {
			reportInputParamsModel.setRttPercent(Long.parseLong(rttPercent));
		}

		// NTSCA-1503
		reportInputParamsModel.setUserSourceIp(HttpRequestUtil.getClientIP(request));

		reportEngineModel = reportEngine.populateData(this.jdbcDao, reportInputParamsModel);
		return reportEngineModel.getHttpPathForCSVFile();
	}

}
