/**
 * 
 */
package com.vzw.web.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.vzw.lte.dao.DBLocationsDAO;
import org.vzw.lte.model.ElementListDetailsModel;
import org.vzw.lte.model.MME;
import org.vzw.lte.model.OperandModel;
import org.vzw.lte.model.PGW;
import org.vzw.lte.model.RegionMmePoolViewModel;
import org.vzw.lte.model.SGW;
import org.vzw.lte.model.ThresholdConditions;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.GeneralUtility;
import org.vzw.lte.util.GlobalConstants;

import bus.ListItem;
import bus.location.Market;
import bus.preferences.UserPreferences;
import bus.report.Report;
import db.JdbcCellGroupDao;
import db.JdbcDao;
import db.location.JdbcEnodeBDao;
import db.login.JdbcUserLTEDAO;
import db.preferences.JdbcUserPreferencesDao;
import db.report.JdbcReportDao;

/**
 * @author amit.chauhan Sep 8, 2010
 */
public class ReportWebServiceUtil {
	protected final static Log logger = LogFactory.getLog(ReportWebServiceUtil.class);

	public static final String ACTION_PULL_EXISTING_RPT = "read";
	public static final String ACTION_EXECUTE_RPT = "execute";
	public static final String ACTION_EXECUTE_LAST_HR_RPT = "execlasthr";
	public static final String ACTION_EXECUTE_TEMPLATE_RPT = "exectmpl";

	public static final String DEFAULT_REPORT_NAME_PREFIX = "rpt-webservice-";
	public static final String TMPL_RPT_DELIMITER = "@";
//	public static final String TMPL_RPT_DELIMITER = "|||";

	public static final String USER_UNKNOWN = "unknown";
	public static final String RPT_UNKNOWN = "unknown";

	public static final String REQ_PARAM_REPORT_ID = "id"; // report id
	public static final String REQ_PARAM_NAME = "name"; // report name. if duplicate random name will be assigned.
	public static final String REQ_PARAM_USER = "user"; // user name
	public static final String REQ_PARAM_ACTION = "action"; // read,execute or c [ie create using request parameters]

	public static final String REQ_PARAM_ENDDATE = "edate";// valid values are yesterday, today or date in following
															// format: 2010-09-08 [yyyy-MM-dd]
	public static final String REQ_PARAM_NUM_DAYS = "num_days"; // days to trend. Must be integer.
	public static final String REQ_PARAM_NUM_HR_MIN = "dispNoOfRows"; // hours or mins to trend. Must be integer.
	public static final String REQ_PARAM_TEMPLATE_NAME = "tmpl_rpt";// report template is identified with
																	// username|||report name
	public static final String REQ_PARAM_TEMPLATE_REPORT_ID = "tmpl_rpt_id";// user can pass either report template name
																			// or report id.
	public static final String REQ_PARAM_RAW_PEGS = "rawpegs";// Y or N
	public static final String REQ_PARAM_RTT_PERCENT = "rttPercent";// RTT Percent
	public static final String REQ_PARAM_EXCL_MAINT_HRS = "exclMaintHour";
	public static final String REQ_PARAM_EXC_WEEKEND = "excweekend";// Y or N
	public static final String REQ_PARAM_EXC_HOLIDAYS = "excholidays";// Y or N
	public static final String REQ_PARAM_THRESHOLD_VALUES = "thresholds";// Y or N
	public static final String REQ_PARAM_SHOW_FREQ = "showfreq"; // Y or N
	public static final String REQ_PARAM_DISPLAY_NULL_VAL = "dispNullVal"; // Y or N
	public static final String REQ_PARAM_HR = "hr";
	public static final String REQ_PARAM_MI = "mi";
	public static final String ALL_HOURS = "00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23";
	public static final String ALL_FIFTENN_MINS = "00,15,30,45";
	public static final String REQ_PARAM_DOW = "dayofwk";
	public static final String ALL_DOW = "1,2,3,4,5,6,7";
	// Request parameters which can be passed as part of url with report template
	// for overriding.
	public static final String REQ_PARAM_RPT_TYPE = "rpttype";
	public static final String REQ_PARAM_RPT_LEVEL = "rptlevel";

	/*
	 * fetch the user name from request parameter. Assign "Unknown" if parameter is
	 * missing.
	 */
	public static String fetchUserName(HttpServletRequest request) {
		String userName = GeneralUtility.trim(request.getParameter(REQ_PARAM_USER));
		if (GeneralUtility.isEmpty(userName)) {
			userName = USER_UNKNOWN;
		}
		return userName;
	}

	public static String fetchUserNameFromTemplateReqParam(HttpServletRequest request) {
		String tmplName = GeneralUtility.trim(request.getParameter(REQ_PARAM_TEMPLATE_NAME));
		String userName = null;
		if (GeneralUtility.isEmpty(tmplName) || tmplName.indexOf(TMPL_RPT_DELIMITER) == -1) {
			userName = USER_UNKNOWN;
		} else {
			String[] arr = tmplName.split(Pattern.quote(TMPL_RPT_DELIMITER));
			if (arr != null && arr.length >= 2) {
				userName = arr[0];
			}
		}

		return GeneralUtility.trim(userName);
	}

	public static String fetchReportId(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(ReportWebServiceUtil.REQ_PARAM_REPORT_ID));
	}

	public static String fetchReportIdFromTemplate(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(ReportWebServiceUtil.REQ_PARAM_TEMPLATE_REPORT_ID));
	}

	public static String fetchReportName(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(ReportWebServiceUtil.REQ_PARAM_NAME));
	}

	public static String fetchReportNameFromTemplateReqParam(HttpServletRequest request) {
		String tmplName = GeneralUtility.trim(request.getParameter(REQ_PARAM_TEMPLATE_NAME));
		String rptName = null;
		if (GeneralUtility.isEmpty(tmplName) || tmplName.indexOf(TMPL_RPT_DELIMITER) == -1) {
			rptName = RPT_UNKNOWN;
		} else {
			String[] arr = tmplName.split(Pattern.quote(TMPL_RPT_DELIMITER));
			if (arr != null && arr.length >= 2) {
				rptName = arr[1];
			}
		}

		return GeneralUtility.trim(rptName);
	}

	public static boolean isReportNameExists(JdbcDao jdbcDao, String reportName, String userName) {
		if (!JdbcReportDao.checkUserReportName(jdbcDao, userName, reportName)) {
			return true;
		}
		return false;
	}

	public static String fetchEndDate(HttpServletRequest request) {
		String endDate = GeneralUtility.trim(request.getParameter(REQ_PARAM_ENDDATE));
		if (GeneralUtility.isEmpty(endDate)) {
			endDate = "YESTERDAY";
		} else if (endDate.equalsIgnoreCase("YESTERDAY")) {
			endDate = "YESTERDAY";
		} else if (endDate.equalsIgnoreCase("TODAY")) {
			endDate = "TODAY";
		} else if (GeneralUtility.isValidDate(endDate, "yyyy-MM-dd")) {
			endDate = endDate + " 23:59:59";
		} else {
			endDate = "YESTERDAY";
		}
		return endDate;
	}

	public static String fetchNumDaysToTrend(HttpServletRequest request, String defaultNum) {
		String numOfDays = GeneralUtility.trim(request.getParameter(REQ_PARAM_NUM_DAYS));
		if (!GeneralUtility.isValidIntValue(numOfDays)) {
			if (GeneralUtility.isValidIntValue(defaultNum))
				numOfDays = defaultNum;
			else
				numOfDays = "1";
		}
		return numOfDays;
	}

	public static String fetchNumHoursToTrend(HttpServletRequest request, String defaultNum) {
		String numOfHrMin = GeneralUtility.trim(request.getParameter(REQ_PARAM_NUM_HR_MIN));
		if (!GeneralUtility.isValidIntValue(numOfHrMin)) {
			if (GeneralUtility.isValidIntValue(defaultNum))
				numOfHrMin = defaultNum;
			else
				numOfHrMin = "1";
		}
		return numOfHrMin;
	}

	public static String fetchDayOfWeek(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(REQ_PARAM_DOW));
	}

	public static String fetchRawPegs(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(REQ_PARAM_RAW_PEGS));
	}

	public static String fetchRttPercent(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(REQ_PARAM_RTT_PERCENT));
	}

	public static String fetchExcWeekend(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(REQ_PARAM_EXC_WEEKEND));
	}

	public static String fetchExcHolidays(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(REQ_PARAM_EXC_HOLIDAYS));
	}

	public static String fetchThresholds(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(REQ_PARAM_THRESHOLD_VALUES));
	}

	public static String generateRandomReportName(String userName) {
		Date date = new Date();
		return new StringBuffer().append(DEFAULT_REPORT_NAME_PREFIX).append(userName).append("-")
				.append(date.toString()).toString();
	}

	public static void overrideObjWithNewReqParamValues(JdbcDao jdbcDao, Report report, HttpServletRequest request) {
		String userName = ReportWebServiceUtil.fetchUserName(request);
		String reportName = ReportWebServiceUtil.fetchReportName(request);

		if (GeneralUtility.isEmpty(reportName) || !JdbcReportDao.checkUserReportName(jdbcDao, userName, reportName)) {
			reportName = ReportWebServiceUtil.generateRandomReportName(userName);
		}

		report.setReportName(reportName);
		report.setIsSAHRpt("N"); // will clone templates below
		report.setUserName(userName);

		// check the url request parameters and if user has provided the values override
		// them in the report object.

		String rptType = fetchRptType(request);
		if (!GeneralUtility.isEmpty(rptType)) {
			report.setReportType(rptType);
		}

		String rptLevel = fetchRptLevel(request);
		if (!GeneralUtility.isEmpty(rptLevel)) {
			report.setReportLevel(rptLevel);
		}

		String eDate = fetchEndDate(request);
		if (!GeneralUtility.isEmpty(eDate)) {
			report.setEndDate(eDate);
		}

		String numDays = fetchNumDaysToTrend(request, report.getDaysToTrend());
		if (!GeneralUtility.isEmpty(numDays)) {
			report.setDaysToTrend(numDays);
		}

		String rawPegs = fetchRawPegs(request);
		if (!GeneralUtility.isEmpty(rawPegs)) {
			report.setDispRawPegs(rawPegs);
		}

		String dispNullVal = fetchDispNullVal(request);
		if (!GeneralUtility.isEmpty(dispNullVal)) {
			report.setDispNullVal(dispNullVal);
		}

		String numHoursOrMin = fetchNumHoursToTrend(request, report.getNumOfHrOrMin());
		if (!GeneralUtility.isEmpty(numHoursOrMin)) {
			report.setNumOfHrOrMin(numHoursOrMin);
		}

//		setThresholdList(jdbcDao, request, report);

		setElementListDetails(jdbcDao, request, report);

		setRBSqlFilter(jdbcDao, request, report);

		setShowFreq(jdbcDao, request, report);
	}

	public static void setShowFreq(JdbcDao jdbcDao, HttpServletRequest request, Report report) {
		try {
			String strShowFreq = GeneralUtility.trim(request.getParameter(REQ_PARAM_SHOW_FREQ));
			if (strShowFreq != null && !strShowFreq.isEmpty()) {
				report.setShowCarrFreq(strShowFreq);
			}
		} catch (Exception ex) {
			logger.info("setShowFreq: " + ex.toString());
		}
	}

	public static void setDispNull(JdbcDao jdbcDao, HttpServletRequest request, Report report) {
		try {
			String strDispNull = GeneralUtility.trim(request.getParameter(REQ_PARAM_DISPLAY_NULL_VAL));
			if (strDispNull != null && !strDispNull.isEmpty()) {
				report.setDispNullVal(strDispNull);
			}
		} catch (Exception ex) {
			logger.error("setDispNull: " + ex.toString());
		}
	}

	public static String fetchRptType(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(REQ_PARAM_RPT_TYPE));
	}

	public static String fetchRptLevel(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(REQ_PARAM_RPT_LEVEL));
	}

	public static String fetchDispNullVal(HttpServletRequest request) {
		return GeneralUtility.trim(request.getParameter(REQ_PARAM_DISPLAY_NULL_VAL));
	}

	/**
	 * Get element list details and save in Report object for report builder.
	 */
	public static void setElementListDetails(JdbcDao jdbcDao, HttpServletRequest request, Report report) {
		try {
			ListItem li;
			List listElds;
			ElementListDetailsModel eld;
			listElds = new ArrayList();
			String strReportLevel = "";
			String[] astrMMEPool;
			String[] astrMME;
			String[] astrSGW;
			String[] astrPGW;
			String[] astrRegion;
			String[] astrMarket;
			String[] astrSite;
			String[] astrCellGroup;
			String item = "";
			String id = "";
			String rttPercent = "";
			boolean bMMEPools = false;
			boolean bMMEs = false;
			boolean bSGWs = false;
			boolean bPGWs = false;
			boolean bRegions = false;
			boolean bMarkets = false;
			boolean bCellGroups = false;
			boolean bSites = false;
			int i;

			strReportLevel = report.getReportLevel(); // pull report level from report object.

			astrMMEPool = request.getParameterValues("mmepoolid");
			astrMME = request.getParameterValues("mme");
			astrSGW = request.getParameterValues("sgw");
			astrPGW = request.getParameterValues("pgw");
			astrRegion = request.getParameterValues("regionid");
			astrMarket = request.getParameterValues("mktid");
			astrSite = request.getParameterValues("gnodeb");
			astrCellGroup = request.getParameterValues("cg");
			rttPercent = request.getParameter("rttPercent");

			String existingElementType = getExistingElementType(report);

			// Set flag that indicates the element level we need to report on.
			/*
			 * i = Integer.parseInt(strReportLevel); switch (i) { case 1: bMMEPools = true;
			 * break; case 2: bSGWs = true; break; case 3: bMMEs = true; break; case 4:
			 * bRegions = true; break; case 5: bMarkets = true; break; case 6: bCellGroups =
			 * true; break; case 10: bSGWs = true; break; // SGW Pool } if ( i == 7 || i ==
			 * 8 || i == 9 ) { // eNodeB, EUTranCell, EUTranCellRelation bSites = true; }
			 * 
			 */
			if (strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_MME_POOL)) {
				bMMEPools = true;
			} else if (strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_SGW)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_SGWPORT)) {
				bSGWs = true;
			} else if (strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_PGW)) {
				bPGWs = true;
			} else if (strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_MME)) {
				bMMEs = true;
			} else if (strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_REGION)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_REGION_CARRIER)) {
				bRegions = true;
			} else if (strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_MARKET)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_MARKET_CARRIER)) {
				bMarkets = true;
			} else if (strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_CELL_GROUP)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_ROLL_UP)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_CELLGROUP_CARRIER)) {
				bCellGroups = true;
			} else if (strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_ENODEB)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_EUTRANCELL)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_EUTRANCELLRELATION)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_CARRIER)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_INTRAFREQNCELLREL)
					|| strReportLevel.equalsIgnoreCase(GlobalConstants.REPORT_LEVEL_ENODEB_CARRIER)) {
				bSites = true;
			} else {
				// Set report level from the existing report if it is not over written
				if (existingElementType.equalsIgnoreCase(ElementListDetailsModel.LIST_ELEMENT_TYPE_MME_POOL)) {
					bMMEPools = true;
				} else if (existingElementType.equalsIgnoreCase(ElementListDetailsModel.LIST_ELEMENT_TYPE_SGW)) {
					bSGWs = true;
				} else if (existingElementType.equalsIgnoreCase(ElementListDetailsModel.LIST_ELEMENT_TYPE_PGW)) {
					bPGWs = true;
				} else if (existingElementType.equalsIgnoreCase(ElementListDetailsModel.LIST_ELEMENT_TYPE_MME)) {
					bMMEs = true;
				} else if (existingElementType.equalsIgnoreCase(ElementListDetailsModel.LIST_ELEMENT_TYPE_REGION)) {
					bRegions = true;
				} else if (existingElementType.equalsIgnoreCase(ElementListDetailsModel.LIST_ELEMENT_TYPE_MARKET)) {
					bMarkets = true;
				} else if (existingElementType.equalsIgnoreCase(ElementListDetailsModel.LIST_ELEMENT_TYPE_CELL_GROUP)) {
					bCellGroups = true;
				}
			}

			// Now load the element list details collection.

			// Load selected MMEPools.
			if (bMMEPools) {
				ArrayList<String> mmepoolIidList = getMmePoolIidList(jdbcDao, astrMMEPool);
				if (mmepoolIidList != null) {
					Iterator<String> itrForMmepoolIidList = mmepoolIidList.iterator();
					while (itrForMmepoolIidList.hasNext()) {
						String tmpMmepoolIid = itrForMmepoolIidList.next();
						eld = new ElementListDetailsModel();
						eld.setListElementId(GeneralUtility.getIntValue(tmpMmepoolIid));
						eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_MME_POOL);
						listElds.add(eld);
					}
				}
			}
			// Load selected MMEs.
			if (bMMEs) {
				ArrayList<String> mmeIidList = getMmeIidList(jdbcDao, astrMME);
				if (mmeIidList != null) {
					Iterator<String> itrForMmeIidList = mmeIidList.iterator();
					while (itrForMmeIidList.hasNext()) {
						String tmpMmeIid = itrForMmeIidList.next();
						eld = new ElementListDetailsModel();
						eld.setListElementId(GeneralUtility.getIntValue(tmpMmeIid));
						eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_MME);
						listElds.add(eld);
					}
				}
			}
			// Load selected SGWs.
			if (bSGWs) {
				ArrayList<String> sgwIidList = getSgwIidList(jdbcDao, astrSGW);
				if (sgwIidList != null) {
					Iterator<String> itrForSgwIidList = sgwIidList.iterator();
					while (itrForSgwIidList.hasNext()) {
						String tmpSgwIid = itrForSgwIidList.next();
						eld = new ElementListDetailsModel();
						eld.setListElementId(GeneralUtility.getIntValue(tmpSgwIid));
						eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_SGW);
						listElds.add(eld);
					}
				}
			}
			// Load selected PGWs.
			if (bPGWs) {
				ArrayList<String> pgwIidList = getPgwIidList(jdbcDao, astrPGW);
				if (pgwIidList != null) {
					Iterator<String> itrForPgwIidList = pgwIidList.iterator();
					while (itrForPgwIidList.hasNext()) {
						String tmpPgwIid = itrForPgwIidList.next();
						eld = new ElementListDetailsModel();
						eld.setListElementId(GeneralUtility.getIntValue(tmpPgwIid));
						eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_PGW);
						listElds.add(eld);
					}
				}
			}
			// Load selected Regions.
			if (bRegions) {
				if (astrRegion != null) {
					for (i = 0; i < astrRegion.length; i++) {
						eld = new ElementListDetailsModel();
						eld.setListElementId(GeneralUtility.getIntValue(astrRegion[i]));
						eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_REGION);
						listElds.add(eld);
					}
				}
			}
			// Load selected Markets.
			if (bMarkets) {
				ArrayList<String> marketIidList = getMarketIidList(jdbcDao, astrMarket);
				if (marketIidList != null) {
					Iterator<String> itrForMarketIidList = marketIidList.iterator();
					while (itrForMarketIidList.hasNext()) {
						String tmpMarketIid = itrForMarketIidList.next();
						eld = new ElementListDetailsModel();
						eld.setListElementId(GeneralUtility.getIntValue(tmpMarketIid));
						eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_MARKET);
						listElds.add(eld);
					}
				}
			}
			// Load selected Cell Groups.
			// However, if a subset of sites are also selected then load those selected
			// enodebs.
			if (bCellGroups) {
				ArrayList<String> cgIidList = getCellgroupIidList(jdbcDao, astrCellGroup);
				if (cgIidList != null) {
					Iterator<String> itrForCGIidList = cgIidList.iterator();
					while (itrForCGIidList.hasNext()) {
						String tmpCGIid = itrForCGIidList.next();
						eld = new ElementListDetailsModel();
						eld.setListElementId(GeneralUtility.getIntValue(tmpCGIid));
						eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_CELL_GROUP);
						listElds.add(eld);
					}
				}
			}
			// Load selected sites.
			// If ALL was selected then save selected MarketIID/s or CellGroupIID/s.
			// Otherwise save selected enodeb IIDs.
			if (bSites) {
				if (astrSite != null) {
					if (astrSite[0].equals("-1")) { // -1 = all.
						if (astrMarket != null) {
							for (i = 0; i < astrMarket.length; i++) {
								eld = new ElementListDetailsModel();
								eld.setListElementId(Integer.parseInt(astrMarket[i]));
								eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_MARKET);
								listElds.add(eld);
							}
						} else {
							if (astrCellGroup != null) {
								for (i = 0; i < astrCellGroup.length; i++) {
									eld = new ElementListDetailsModel();
									eld.setListElementId(Integer.parseInt(astrCellGroup[i]));
									eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_CELL_GROUP);
									listElds.add(eld);
								}
							}
						}
						// Save selected enodebs.
					} else {
						ArrayList<String> listOfEnodebIid = getEnodebIidList(jdbcDao, astrSite);
						Iterator<String> itrForListOfEnodebIid = listOfEnodebIid.iterator();
						while (itrForListOfEnodebIid.hasNext()) {
							eld = new ElementListDetailsModel();
							eld.setListElementId(GeneralUtility.getIntValue(itrForListOfEnodebIid.next()));
							eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_ENODEB);
							listElds.add(eld);
						}
					}
				} else if (astrCellGroup != null) { // The user wants to override an enodeb, eutrancell, carrier level,
													// IntraFreqNcellRel report network elements using the enodebs in
													// the cellgroup
					ArrayList<String> cgIidList = getCellgroupIidList(jdbcDao, astrCellGroup);
					if (cgIidList != null) {
						Iterator<String> itrForCGIidList = cgIidList.iterator();
						while (itrForCGIidList.hasNext()) {
							String tmpCGIid = itrForCGIidList.next();
							eld = new ElementListDetailsModel();
							eld.setListElementId(GeneralUtility.getIntValue(tmpCGIid));
							eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_CELL_GROUP);
							listElds.add(eld);
						}
					}
				} else if (astrMarket != null) { // The user wants to override an enodeb, eutrancell, carrier level,
													// IntraFreqNcellRel report network elements using the enodebs in
													// the market
					ArrayList<String> listMarketIids = getMarketIidList(jdbcDao, astrMarket);
					for (i = 0; i < listMarketIids.size(); i++) {
						eld = new ElementListDetailsModel();
						eld.setListElementId(Integer.parseInt(listMarketIids.get(i)));
						eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_MARKET);
						listElds.add(eld);
					}
				} else if (astrRegion != null) { // The user wants to override an enodeb, eutrancell, carrier level
													// report network elements using the enodebs in the region
					for (i = 0; i < astrRegion.length; i++) {
						eld = new ElementListDetailsModel();
						eld.setListElementId(GeneralUtility.getIntValue(astrRegion[i]));
						eld.setListElementType(ElementListDetailsModel.LIST_ELEMENT_TYPE_REGION);
						listElds.add(eld);
					}
				}
			}

			if (listElds != null && listElds.size() > 0) {
				// Override only if user has passed new information.
				report.setElementListDetails(listElds);
			}

		} catch (Exception ex) {
			logger.error(ex.toString());
		}

	}

	/*
	 * Users will pass Market Id as part of request parameter. We will convert it to
	 * internal iid.
	 * 
	 * @param arrMarketId three- or four-character market ID strings.
	 */
	private static ArrayList<String> getMarketIidList(JdbcDao jdbcDao, String[] arrMarketId) {
		ArrayList<String> marketIidList = new ArrayList<String>();

		try {
			if (arrMarketId != null && arrMarketId.length > 0) {
				// Pull the market map. Keys are Market.iids.
				LinkedHashMap<String, Market> marketMap = DBLocationsDAO.populateMarketMap(jdbcDao);
				Iterator<String> itrOfMarketIds = Arrays.asList(arrMarketId).iterator();
				while (itrOfMarketIds.hasNext()) {
					String marketId = itrOfMarketIds.next();
					if (marketId == null) {
						continue;
					}
					Iterator<String> itr = marketMap.keySet().iterator();
					while (itr.hasNext()) {
						String iid = itr.next();
						Market marketModel = marketMap.get(iid);
						if (marketModel == null) {
							continue;
						}
						// Use the marketDisplayId to match on. To get an LRA market,
						// user must specify a four-digit LRA market ID. To get a
						// non-LRA market, user must specify a three-digit market ID.
						if (marketId.equalsIgnoreCase(marketModel.getMarketDisplayId())) {
							marketIidList.add(iid);
							break;
						}
					}
				}
			}
		} catch (Exception excep) {

		}
		return marketIidList;
	}

	/*
	 * Users will pass MMEPool Id as part of request parameter. We will convert it
	 * to internal iid.
	 */
	private static ArrayList<String> getMmePoolIidList(JdbcDao jdbcDao, String[] arrMmePoolId) {
		ArrayList<String> mmepoolIidList = new ArrayList<String>();

		try {
			if (arrMmePoolId != null && arrMmePoolId.length > 0) {
				// Pull the MMEPool map.
				LinkedHashMap<String, RegionMmePoolViewModel> mapWithRegionIidAsKey = DBLocationsDAO
						.populateRegionMmePoolView(jdbcDao);
				Iterator<String> itrOfMmePoolIds = Arrays.asList(arrMmePoolId).iterator();
				while (itrOfMmePoolIds.hasNext()) {
					String mmePoolId = itrOfMmePoolIds.next();
					if (mmePoolId == null) {
						continue;
					}
					Iterator<String> itr = mapWithRegionIidAsKey.keySet().iterator();
					while (itr.hasNext()) {
						String iid = itr.next();
						RegionMmePoolViewModel regionMmePoolViewModel = mapWithRegionIidAsKey.get(iid);
						if (regionMmePoolViewModel == null) {
							continue;
						}
						if (mmePoolId.equalsIgnoreCase(regionMmePoolViewModel.getMmePoolId())) {
							mmepoolIidList.add(String.valueOf(regionMmePoolViewModel.getMmePoolIid()));
							break;
						}
					}
				}
			}
		} catch (Exception excep) {

		}
		return mmepoolIidList;
	}

	/*
	 * Users will pass MME Id as part of request parameter. We will convert it to
	 * internal iid.
	 */
	private static ArrayList<String> getMmeIidList(JdbcDao jdbcDao, String[] arrMme) {
		ArrayList<String> mmeIidList = new ArrayList<String>();

		try {
			if (arrMme != null && arrMme.length > 0) {
				// Pull the MME map.
				LinkedHashMap<String, MME> mmeMap = DBLocationsDAO.populateMMEMap(jdbcDao);
				Iterator<String> itrOfMmeIds = Arrays.asList(arrMme).iterator();
				while (itrOfMmeIds.hasNext()) {
					String mmeId = itrOfMmeIds.next();
					if (mmeId == null) {
						continue;
					}
					Iterator<String> itr = mmeMap.keySet().iterator();
					while (itr.hasNext()) {
						String iid = itr.next();
						MME mmeModel = mmeMap.get(iid);
						if (mmeModel == null) {
							continue;
						}
						if (mmeId.equalsIgnoreCase(mmeModel.getMmeLocation())) {
							mmeIidList.add(iid);
							break;
						}
					}
				}
			}
		} catch (Exception excep) {

		}
		return mmeIidList;
	}

	/*
	 * Users will pass SGW Id as part of request parameter. We will convert it to
	 * internal iid.
	 */
	private static ArrayList<String> getSgwIidList(JdbcDao jdbcDao, String[] arrSgw) {
		ArrayList<String> sgwIidList = new ArrayList<String>();

		try {
			if (arrSgw != null && arrSgw.length > 0) {
				// Pull the SGW map.
				LinkedHashMap<String, SGW> sgwMap = DBLocationsDAO.populateSGWMap(jdbcDao);
				Iterator<String> itrOfSgwIds = Arrays.asList(arrSgw).iterator();
				while (itrOfSgwIds.hasNext()) {
					String mmeId = itrOfSgwIds.next();
					if (mmeId == null) {
						continue;
					}
					Iterator<String> itr = sgwMap.keySet().iterator();
					while (itr.hasNext()) {
						String iid = itr.next();
						SGW sgwModel = sgwMap.get(iid);
						if (sgwModel == null) {
							continue;
						}
						if (mmeId.equalsIgnoreCase(sgwModel.getSgwLocation())) {
							sgwIidList.add(iid);
							break;
						}
					}
				}
			}
		} catch (Exception excep) {

		}
		return sgwIidList;
	}

	/*
	 * Users will pass PGW Id as part of request parameter. We will convert it to
	 * internal iid.
	 */
	private static ArrayList<String> getPgwIidList(JdbcDao jdbcDao, String[] arrPgw) {
		ArrayList<String> pgwIidList = new ArrayList<String>();

		try {
			if (arrPgw != null && arrPgw.length > 0) {
				// Pull the SGW map.
				LinkedHashMap<String, PGW> pgwMap = DBLocationsDAO.populatePGWMap(jdbcDao);
				Iterator<String> itrOfSgwIds = Arrays.asList(arrPgw).iterator();
				while (itrOfSgwIds.hasNext()) {
					String mmeId = itrOfSgwIds.next();
					if (mmeId == null) {
						continue;
					}
					Iterator<String> itr = pgwMap.keySet().iterator();
					while (itr.hasNext()) {
						String iid = itr.next();
						PGW pgwModel = pgwMap.get(iid);
						if (pgwModel == null) {
							continue;
						}
						if (mmeId.equalsIgnoreCase(pgwModel.getPgwLocation())) {
							pgwIidList.add(iid);
							break;
						}
					}
				}
			}
		} catch (Exception excep) {

		}
		return pgwIidList;
	}

	private static ArrayList<String> getCellgroupIidList(JdbcDao jdbcDao, String[] arrCg) {
		ArrayList<String> cgIidList = new ArrayList<String>();

		try {
			if (arrCg != null && arrCg.length > 0) {
				List<String> list = Arrays.asList(arrCg);
				cgIidList = JdbcCellGroupDao.getListOfCgIid(jdbcDao, list);
			}
		} catch (Exception excep) {

		}
		return cgIidList;

	}

	private static ArrayList<String> getEnodebIidList(JdbcDao jdbcDao, String[] arrSite) {
		ArrayList<String> enodebIidList = new ArrayList<String>();
		if (arrSite == null || arrSite.length == 0) {
			return enodebIidList;
		}
		enodebIidList = JdbcEnodeBDao.getListOfEnodebIidBasedOnMktIdAndEnodebId(jdbcDao, Arrays.asList(arrSite));
		return enodebIidList;
	}

	private static void setRBSqlFilter(JdbcDao jdbcDao, HttpServletRequest request, Report report) {
		try {
			String[] astrEUTranCells = null;
			String strEUTranCells = "";
			String[] astrHours;
			String[] astrRequestedHrs;
			String strRequestedHours;
			String strHours = "";
			String strHourWork = "";
			Integer count;
			List listSqlFilter;
			listSqlFilter = new ArrayList();
			String excludeWeekend = fetchExcWeekend(request);
			String excludeHolidays = fetchExcHolidays(request);
			String dow = fetchDayOfWeek(request);
			if (excludeWeekend != null && excludeWeekend.equalsIgnoreCase("Y")) {
				listSqlFilter.add("to_char(basetable.STARTDATE, 'D') in (2,3,4,5,6)");
			}

			if (dow != null) {
				String[] arrDow = dow.split(",");
				StringBuffer sbDow = new StringBuffer();
				StringBuffer sb = new StringBuffer();
				sbDow.append("to_char(").append(GlobalConstants.BASETABLE_ALIAS).append("STARTDATE, 'D') in (");
				if (dow.contains("All"))
					sb.append(ALL_DOW);
				else {
					for (String aDay : arrDow) {
						if (sb.length() > 0)
							sb.append(",");
						sb.append(String.valueOf((GeneralUtility.getIntValue(aDay.trim()) + 1)));
					}
				}
				sbDow.append(sb.toString());
				sbDow.append(")");
				listSqlFilter.add(sbDow.toString());
			}

			if (excludeHolidays != null && excludeHolidays.equalsIgnoreCase("Y")) {
				String excHol = JdbcReportDao.excludeHolidays(jdbcDao, report.getEndDate(), report.getDaysToTrend());
				if (GeneralUtility.isNonEmpty(excHol)) {
					listSqlFilter.add(excHol);
				}
			}

			// Get Sector filter if needed:
			astrEUTranCells = request.getParameterValues("eutrancell");
			int nEutrancells = EnvironmentUtil.getEutrancellsArray().length;
			if (astrEUTranCells != null && astrEUTranCells.length != nEutrancells) {
				for (int i = 0; i < astrEUTranCells.length; i++) {
					if (strEUTranCells.equals("")) {
						strEUTranCells = GlobalConstants.VIEW_ALIAS + "EUTranCell in ('"
								+ astrEUTranCells[i].toString();
					} else {
						strEUTranCells = strEUTranCells + "','" + astrEUTranCells[i].toString();
					}
				}
				strEUTranCells = strEUTranCells + "')";
				listSqlFilter.add(strEUTranCells);
			}

			// Get Carrier filter if present
			String[] astrCarrier = request.getParameterValues("carrier");
			String strCarrier = "";
			if (astrCarrier != null && astrCarrier.length != GlobalConstants.LIST_OF_CARRIERS.size()) {
				for (int i = 0; i < astrCarrier.length; i++) {
					strCarrier += strCarrier.equals("")
							? GlobalConstants.VIEW_ALIAS + "Carrier in ('" + astrCarrier[i].toString()
							: "','" + astrCarrier[i].toString();
				}

				strCarrier += "')";
				listSqlFilter.add(strCarrier);
			}

			// Get Maintenance Hours filter if needed:
			astrHours = request.getParameterValues(REQ_PARAM_EXCL_MAINT_HRS);
			if (astrHours != null && astrHours.length > 0) {
				String line = null;
				if (!astrHours[0].equalsIgnoreCase("Y")) {
					line = astrHours[0].toString();
				} else {
					line = GlobalConstants.EXCLUDE_MAINT_HRS;
				}
				String[] fields = line.split(",");
				for (count = 0; count < fields.length; count++) {
					// Single digit hours need to be 2 digits in the filter statement.
					strHourWork = fields[count].toString();
					if (strHourWork.length() == 1) {
						strHourWork = "0" + strHourWork;
					}
					if (strHours.equals("")) {
						strHours = "to_char(" + GlobalConstants.BASETABLE_ALIAS + "STARTDATE, 'HH24') in ('"
								+ strHourWork + "'";
					} else {
						strHours = strHours + ",'" + strHourWork + "'";
					}
				}
				strHours = strHours + ")";
				listSqlFilter.add(strHours);
			}

			// Get requested hours
			astrRequestedHrs = request.getParameterValues(REQ_PARAM_HR);
			if (astrRequestedHrs != null && astrRequestedHrs.length > 0) {
				String hrs = "";
				if (!astrRequestedHrs[0].equalsIgnoreCase("All")) {
					hrs = astrRequestedHrs[0].toString();
				} else {
					hrs = ALL_HOURS;
				}
				String[] hr = hrs.split(",");
				StringBuffer sb = new StringBuffer();
				StringBuffer sbHrs = new StringBuffer();
				for (int i = 0; i < hr.length; i++) {
					if (sbHrs.length() > 0)
						sbHrs.append(",");
					String thisHr = hr[i];
					if ((hr[i] != null) && (hr[i].length() < 2)) // prepend a "0"
						thisHr = "0" + thisHr;
					sbHrs.append("'").append(thisHr).append("'");
				}

				if (sbHrs.length() > 0) {
					sb.append("to_char(" + GlobalConstants.BASETABLE_ALIAS + "STARTDATE, 'HH24') in (");
					sb.append(sbHrs);
					sb.append(")");

					listSqlFilter.add(sb.toString());
				}
			}

			// Get requested minutes
			astrRequestedHrs = request.getParameterValues(REQ_PARAM_MI);
			if (astrRequestedHrs != null && astrRequestedHrs.length > 0) {
				String mins = "";
				if (!astrRequestedHrs[0].equalsIgnoreCase("All")) {
					mins = astrRequestedHrs[0].toString();
				} else {
					mins = ALL_FIFTENN_MINS;
				}
				String[] min = mins.split(",");
				StringBuffer sb = new StringBuffer();
				StringBuffer sbMins = new StringBuffer();
				for (int i = 0; i < min.length; i++) {
					if (sbMins.length() > 0)
						sbMins.append(",");
					String thisMin = min[i];
					if ((min[i] != null) && (min[i].length() < 2)) // prepend a "0"
						thisMin = "0" + thisMin;
					sbMins.append("'").append(thisMin).append("'");
				}

				if (sbMins.length() > 0) {
					sb.append("to_char(" + GlobalConstants.BASETABLE_ALIAS + "STARTDATE, 'MI') in (");
					sb.append(sbMins);
					sb.append(")");

					listSqlFilter.add(sb.toString());
				}
			}
			report.setSqlFilterCriteria(listSqlFilter);
		} catch (Exception ex) {
			logger.error(ex.toString());
		}
	}

	public static void setThresholdList(JdbcDao jdbcDao, String thresholds, Report report) {
		try {
			String thresholdsVals = thresholds;
			ArrayList<ThresholdConditions> tcList = new ArrayList();
			if (thresholdsVals == null) {
				// Remove any existing criterias
				report.setThresholdConditions(tcList);
			} else {
				thresholdsVals = thresholdsVals.replaceAll("\\(", "").replaceAll("\\)", "");
				thresholdsVals = thresholdsVals.replaceAll(">=", "^>=^").replaceAll(">", "^>^").replaceAll("<=", "^<=^")
						.replaceAll("<", "^<^").replaceAll("=", "^=^").replaceAll("!=", "^!=^");
				thresholdsVals = thresholdsVals.replaceAll("\\^\\^", "^").replaceAll(">\\^=", ">=")
						.replaceAll("<\\^=", "<=").replaceAll("\\!\\^=", "!=");
				thresholdsVals = thresholdsVals.replaceAll("OR", ",");
				String[] filterCriterias = thresholdsVals.split(",");
				for (int idx = 0; idx < filterCriterias.length; idx++) {
					String criteria = filterCriterias[idx];
					String[] tcArray = criteria.split("AND");
					if (tcArray != null && criteria.length() > 0) {
						ThresholdConditions tc = new ThresholdConditions();
						for (int tcIdx = 0; tcIdx < tcArray.length; tcIdx++) {
							String[] parts = tcArray[tcIdx].split("\\^");
							if (parts != null && parts.length == 3) {
								if (tcIdx == 0) {
									OperandModel primaryOm = new OperandModel();
									primaryOm.setLeftOperandName(parts[0]);
									primaryOm.setOperation(parts[1]);
									primaryOm.setRightOperand(parts[2]);
									tc.setPrimaryThreshold(primaryOm);
								} else {
									OperandModel auxiliaryOm = new OperandModel();
									auxiliaryOm.setLeftOperandName(parts[0]);
									auxiliaryOm.setOperation(parts[1]);
									auxiliaryOm.setRightOperand(parts[2]);
									tc.addAuxiliaryThreshold(auxiliaryOm);
								}
							}
						}
						tcList.add(tc);
					}
				}
				ThresholdConditions.PopulateFormulaIds(jdbcDao, tcList);
				// Save Thresholds list in report
				report.setThresholdConditions(tcList);
			}
		} catch (Exception ex) {
			logger.error(ex.toString());
		}
	}

	private static String getExistingElementType(Report report) {
		String existingElementType = "";

		try {
			if (report != null && report.getElementListDetails() != null) {
				Iterator<ElementListDetailsModel> itr = report.getElementListDetails().iterator();
				while (itr.hasNext()) {
					ElementListDetailsModel model = itr.next();
					if (model == null) {
						continue;
					}
					existingElementType = model.getListElementType();
					break;
				}
			}

		} catch (Exception excep) {
			logger.debug("exception:" + excep.getMessage());
		}

		if (GeneralUtility.isEmpty(existingElementType)) {
			existingElementType = "unknown";
		}

		return existingElementType;
	}

	public static boolean validateUserAndPermissions(JdbcDao jdbcDao, String userId, ArrayList<String> errors) {
		boolean bValid = false;

		if (userId != null && !userId.equals("") && JdbcUserLTEDAO.isUserPresentInDB(jdbcDao, userId)) {
			UserPreferences userPref = JdbcUserPreferencesDao.selectPreferencesByUser(jdbcDao, userId);
			if (userPref != null && (userPref.getAuthorizedForWebSvcReports() == null
					|| userPref.getAuthorizedForWebSvcReports().equalsIgnoreCase("Y"))) {
				bValid = true;
			} else
				errors.add("User " + userId
						+ " is not authorized for running webservice reports. Make sure you have saved your profile and are authorized to run webservice reports.");
		} else
			errors.add("User " + userId + " does not exist in LTE database.");
		return bValid;
	}
}
