package com.vzw.web.user;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import db.JdbcDao;
import db.user.JdbcObjectsDao;
import db.report.JdbcReportDao;
/**
 * 
 * @author  
 * 
 */
public class GetUserObjectsController 
implements Controller 
{

    private JdbcDao jdbcDao = null;

    /** Logger for this class and subclasses */
    protected final Log logger = LogFactory.getLog(getClass());   

    /** Getters and Setters. */
    public JdbcDao getJdbcDao() {
        return jdbcDao;
    }
    public void setJdbcDao(JdbcDao jdbcDao) {
        this.jdbcDao = jdbcDao;
    }

    public ModelAndView handleRequest(HttpServletRequest request,
                                      HttpServletResponse response)
    throws ServletException, IOException          
    { 	    	
        String user = request.getParameter("user");
        String type = request.getParameter("type");

        // Check whether a report needs to be deleted and make it so.
        String reportId = request.getParameter("reportId");
        if (reportId != null && !"".equals(reportId) && !"0".equals(reportId))
        {
            JdbcReportDao.deleteReport(jdbcDao, reportId);
            logger.info("Deleting report " + reportId + " per user request.");
        }
        String reportUsage = request.getParameter("reportUsage");
        List objects = JdbcObjectsDao.selectObjectsByUserAndType(jdbcDao, user, type, reportUsage);
        
        return new ModelAndView("getUserObjects", "objects", objects);
    }
}
