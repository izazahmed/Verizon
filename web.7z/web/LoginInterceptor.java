/******************************************************************************
 * LoginInterceptor.java
 *
 * Change History
 * Date         Who     Description
 * ----------------------------------------------------------------------------
 * 06/15/2010   rwhites Added handling of ELTE vs ALTE.
 *****************************************************************************/
package com.vzw.web; 

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import org.vzw.lte.util.EnvironmentUtil;

/**
 * 
 * 
 *
 */
public class LoginInterceptor extends HandlerInterceptorAdapter 
{

    /** Logger for this class and subclasses */
    protected final Log logger = LogFactory.getLog(getClass());

    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler)
    throws Exception 
    {
        String path = request.getContextPath();

        logger.info( "in preHandle path is :" + path + " pathInfo: " + request.getPathInfo()
                    + " queryString:" + request.getQueryString() 
                    + " rURI:" + request.getRequestURI()
                    + " serPath" + request.getServletPath() 
                   );
        
        HttpSession session = request.getSession();
        String sessionStatus = (String)session.getAttribute("session.status");
        String isnew =""+ request.getParameter("isnew") ;
        if( isnew != null && isnew.equals("true") && sessionStatus == null){
        	sessionStatus = ""+request.getParameter("session.status") ;
        	session.setAttribute("session.userid", ""+request.getParameter("session.userid") ); 
        	session.setAttribute("session.status",sessionStatus);
        	session.setAttribute("isnew",isnew);
        	request.setAttribute("isnew", isnew);
        }
        logger.info( " isnew => " + isnew + "sessionStatus => " + sessionStatus );
        String pagePath = request.getServletPath();
        if (pagePath != null && (  pagePath.equals("/login.htm")  || pagePath.equals("/relogin.htm") ))
        {
            return true;
        }
        else
        {   		
            if ( sessionStatus != null && sessionStatus.equals("valid"))
            {
                return true;
            }
            else
            {	
                response.sendRedirect("/" + EnvironmentUtil.AppId
                                      + "/login.htm");
                return false;
            }
        }
    }
}
