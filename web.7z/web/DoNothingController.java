package com.vzw.web;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

/**
 * 
 * @author  
 * 
 */
public class DoNothingController implements Controller 
{

    /** Logger for this class and subclasses */
    protected final Log logger = LogFactory.getLog(getClass());
    
    /** Comments : 
     * 1 .Only for views under the "WEB-INF/jsp/" folder
     * 2 .Facilitates going to a view which has no concrete functionality in the controller
     * 3 .Basically enabaling page forwards 
     */
    public ModelAndView handleRequest(HttpServletRequest request,
            HttpServletResponse response)
     throws ServletException, IOException     
     
     {
    	String pagePath = request.getServletPath();    	  	
    	pagePath = pagePath.replace("/","");
    	pagePath = pagePath.replace(".htm","");    
    	return new ModelAndView(pagePath);    	
     }
    
      

}