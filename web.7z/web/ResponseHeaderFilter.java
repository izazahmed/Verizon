package com.vzw.web;

import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;


public class ResponseHeaderFilter implements Filter{
	
	static class HeaderPair {
		String name;
		String value;
		HeaderPair(String name, String value) {
			this.name = name; this.value = value;
		}              
	}
	List<HeaderPair> additionalHeaders = new ArrayList<HeaderPair>();
    
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if (response instanceof HttpServletResponse) {
			for (HeaderPair headerPair: additionalHeaders) ((HttpServletResponse)response).addHeader(headerPair.name, headerPair.value); 
        }
        chain.doFilter(request, response);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		Enumeration<?> names = arg0.getInitParameterNames();
		String name;
		String value;
		while (names.hasMoreElements()) {
			name = (String)names.nextElement();
			value = arg0.getInitParameter(name);
			if (value != null) additionalHeaders.add(new HeaderPair(name,value));                                        
		}
	}
}
