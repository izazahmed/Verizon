package com.vzw.web.exception;

/**
 * Created by gundaja on 2/27/18.
 */
public class WebTokenException extends Exception {
    public WebTokenException(String message) {
        super(message);
    }
}
