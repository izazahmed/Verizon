package com.vzw.web.exception;

/**
 * Created by gundaja on 2/27/18.
 */
public class MissingParameterException extends Exception {
    public MissingParameterException(String message) {
        super(message);
    }
}
