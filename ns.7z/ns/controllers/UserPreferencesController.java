package com.vzw.ns.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.util.TimeZoneUtil;

import com.vzw.ns.model.MMEPool;
import com.vzw.ns.model.Market;
import com.vzw.ns.model.MrfcCluster;
import com.vzw.ns.model.VolteCore;
import com.vzw.ns.models.auth.User;
import com.vzw.ns.service.interfaces.IUserPreferencesServiceable;
import com.vzw.ns.ui.models.UserPreferencesForm;

import bus.ListItem;
import bus.location.Region;
import bus.login.model.WebserverDetailsModel;
import db.JdbcDao;
import db.connection.DBLocation;
import db.connection.JdbcDBLocationDao;
import db.location.JdbcRegionDao;
import db.login.JdbcUserLTEDAO;


@RestController
@CrossOrigin
@RequestMapping("/pt/preferences")
public class UserPreferencesController {

	@Autowired
	IUserPreferencesServiceable iUserPreferencesServiceable;
	
	@Autowired
	User iUser;
	
	@Autowired
	JdbcDao jdbcDao;
	
	
	@GetMapping(path = "/userType")
	public String getUserAccessLevel(){
		String lvl = JdbcUserLTEDAO.getUserAccessLevel(this.jdbcDao,iUser.getUserName());
		return lvl.equalsIgnoreCase("admin")?"1":"0";
	}
	
	@GetMapping("/")
	public UserPreferencesForm getUserPreferences() {
		return iUserPreferencesServiceable.getUserPreferences(iUser.getUserName());
	}
	
	@PostMapping("/")
	public ResponseEntity<UserPreferencesForm> updateUserPreferences(@Valid @RequestBody UserPreferencesForm userPreferences) {
		userPreferences.setUserName(iUser.getUserName());
		return iUserPreferencesServiceable.updateUserPreferences(userPreferences);
	}
	
	@GetMapping("/check")
	public Boolean isUserPresentInDB() {
		Boolean isUserPresentInDB = JdbcUserLTEDAO.isUserPresentInDB(this.jdbcDao, iUser.getUserName());
		if (!isUserPresentInDB) {
			JdbcUserLTEDAO.addUserToNPTUserTable(this.jdbcDao, iUser.getUserName());
		}
		return isUserPresentInDB;
	}
	
	@GetMapping("/regions")
	public List<Region> getAllRegions() {
		return JdbcRegionDao.populateRegions(this.jdbcDao);

	}
	
	
	@GetMapping("/timeZones")
	public List<String> getAllTimeZones() {
		return TimeZoneUtil.getTimeZoneList();

	}
		
	@GetMapping("/markets")
	public List<Market> getAllMarkets() {
		return iUserPreferencesServiceable.getAllMarkets();

	}
	
	
	@GetMapping("/myMarkets")
	public List<Market> getAllMyMarkets() {
		return iUserPreferencesServiceable.getAllMyMarkets(iUser.getUserName());

	}
	
	@GetMapping("/myMarkets/perfcharts")
	public List<Market> getAllMyMarketForPerfCharts() {
		return iUserPreferencesServiceable.getAllMyMarketForPerfCharts(iUser.getUserName());

	}
	
	@GetMapping("/myMmePools")
	public List<MMEPool> getAllMyMmePools() {
		return iUserPreferencesServiceable.getAllMyMmePools(iUser.getUserName());

	}
	
	@GetMapping("/users/{regionId}")
	public List<String> getUsersByRegion(@PathVariable Integer regionId) {
		return iUserPreferencesServiceable.getUsersByRegion(regionId);

	}
	
	//for clpt
	@GetMapping("/volteCores")
	public List<VolteCore> getAllVolteCores() {
		return iUserPreferencesServiceable.getAllVolteCores(jdbcDao);

	}
	
	//for clpt
	@GetMapping("/myVolteCores")
	public List<ListItem> getAllMyVolteCores() {
		return iUserPreferencesServiceable.getAllMyVolteCores(jdbcDao,iUser.getUserName());

	}
	
	//for clpt
	@GetMapping("/allMRFC")
	public List<MrfcCluster> getAllMRFCs() {
		return iUserPreferencesServiceable.getAllMRFCs(jdbcDao);

	}
	
	//for clpt
	@GetMapping("/allMyMRFC")
	public List<ListItem> getAllMyMRFCs() {
		return iUserPreferencesServiceable.getAllMyMRFCs(jdbcDao,iUser.getUserName());

	}
	
	
	@GetMapping(path = "/schemas")
	public ArrayList<DBLocation> getListOfSchemas(){
		return JdbcDBLocationDao.getListOfSchemas(this.jdbcDao);
	}
	
	@PostMapping(path = "/schemas")
	public ArrayList<DBLocation> updateListOfSchemas(@Valid @RequestBody ArrayList<String> listOfDr){
		try {
		   JdbcDBLocationDao.updateDrInfo(jdbcDao, listOfDr);
		}catch (Exception e) {
			
		}
		return JdbcDBLocationDao.getListOfSchemas(jdbcDao);
	}
	
	
	
}
