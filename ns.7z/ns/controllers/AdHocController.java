package com.vzw.ns.controllers;

import static org.mockito.Matchers.endsWith;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import db.JdbcReportLevelDao;
import db.sah.JdbcSahDao;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.action.ReportEngine;
import org.vzw.lte.model.ReportEngineModel;
import org.vzw.lte.model.ReportInputParamsModel;
import org.vzw.lte.util.ClearCacheUtil;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.GlobalConstants;

import com.vzw.ns.model.AdHocForm;
import com.vzw.ns.model.Content;
import com.vzw.ns.model.ElementGroup;
import com.vzw.ns.model.EnodeB;
import com.vzw.ns.model.Formula;
import com.vzw.ns.model.MMEPool;
import com.vzw.ns.model.Market;
import com.vzw.ns.model.MmePoolWithRegion;
import com.vzw.ns.model.Mrfp;
import com.vzw.ns.model.Region;
import com.vzw.ns.model.ReportDetailForm;
import com.vzw.ns.model.ReportLevel;
import com.vzw.ns.model.ReportType;
import com.vzw.ns.models.auth.AppInfo;
import com.vzw.ns.models.auth.User;
import com.vzw.ns.service.interfaces.IAdHocServiceable;
import com.vzw.ns.ui.models.MmePgwSgwForm;
import com.vzw.web.cellgroups.JSONResponse;

import bus.ListItem;
import bus.report.Report;
import bus.report.Template;
import bus.report.TemplateFormula;
import db.JdbcDao;
import db.JdbcMyNetElemDao;
import db.location.JdbcMMEPoolDao;
import db.report.JdbcMrfpDao;
import db.report.JdbcReportDao;
import db.report.JdbcTemplateDao;
import org.vzw.lte.util.HttpRequestUtil;

@RestController
@CrossOrigin
@RequestMapping("/pt/adhoc")
public class AdHocController {
	private final static String REGION_CACHE_KEY = "regions";
	private final static String MARKET_CACHE_KEY = "markets";
	private final static String MARKET_REGION_CACHE_KEY = "markets-key";
	private final static String REPORT_LEVELS_KEY = "report-levels";
	private final static String REPORT_CONTENT_LEVELS_KEY = "report-content-levels";
	private final static String REPORT_TYPES_KEY = "report-types";
	private final static String SAH_REPORT_LEVEL_REPORT_TYPES_KEY = "report-levels-types";

	protected static Log logger = LogFactory.getLog(AdHocController.class);

	@Value("${report.storage.path}")
	private String rootPath;

	@Value("${user.root.path}")
	private String userRootPath;

	@Autowired
	IAdHocServiceable iAdHocServiceable;

	@Autowired
	User iUser;

	@Autowired
	JdbcDao jdbcDao;

	@PostConstruct
	public void setAdHocController() {
		// TODO Auto-generated constructor stub
		// this.jdbcDao = this.iUser.getJdbcDao();
	}

	@GetMapping(path = "/reportlevels", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ReportLevel> getAllReportLevels() {
		List<ReportLevel> mList = iAdHocServiceable.getAllReportLevel();
		return mList;// new ResponseEntity<List<ReportLevel>>(mList, HttpStatus.OK);

	}

	@GetMapping(path = "/mme/regions", produces = MediaType.APPLICATION_JSON_VALUE)
	public ArrayList <MmePoolWithRegion> getAllMMeWithRegions() {
		return JdbcMMEPoolDao.populateMMEPoolsWithRegions(jdbcDao);// new ResponseEntity<List<ReportLevel>>(mList, HttpStatus.OK);

	}

	@GetMapping(path = "/mmepools", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<MMEPool>> getAllMmePools() {
		return new ResponseEntity<List<MMEPool>>(iAdHocServiceable.getAllMmePools(jdbcDao), HttpStatus.OK);
	}

	@GetMapping(path = "/mmespgws/{type}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<MmePgwSgwForm> getAllMmeSgwPgw(@PathVariable String type) {
		List<MmePgwSgwForm> mList = iAdHocServiceable.getAllMmeSgwPgw(iUser.getUserName(), type);
		return mList;// new ResponseEntity<List<MmePgwSgwForm>>(mList, HttpStatus.OK);
	}

	@GetMapping(path = "/regions", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Region>> getAllRegion() {
		return new ResponseEntity<List<Region>>(iAdHocServiceable.getAllRegion(), HttpStatus.OK);
	}

	@GetMapping(path = "/regions-adhoc", produces = MediaType.APPLICATION_JSON_VALUE)
	public ArrayList getAllRegionAdhoc() {
		return JdbcMyNetElemDao.getMyRegions(jdbcDao, iUser.getUserName());
	}

	@GetMapping(path = "/markets/{regionId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Market>> getAllMarketWithRepectToRegion(@PathVariable Integer regionId) {
		List<Market> mMarkets = iAdHocServiceable.getAllMarketWithRepectToRegion(regionId);
		return new ResponseEntity<List<Market>>(mMarkets, HttpStatus.OK);
	}

	@GetMapping(path = "/enodeBs/{marketId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EnodeB> getAllEnodeBWithRepectToMarket(@PathVariable Integer marketId) {
		List<EnodeB> mEnodeBs = iAdHocServiceable.getAllEnodeBWithRepectToMarket(marketId, "");
		return mEnodeBs;// new ResponseEntity<List<EnodeB>>(mEnodeBs, HttpStatus.OK);
	}

	@GetMapping(path = "/enodeBs/{marketId}/{venodorName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EnodeB> getAllEnodeBWithRepectToMarketVendor(@PathVariable Integer marketId, @PathVariable String venodorName) {
		List<EnodeB> mEnodeBs = iAdHocServiceable.getAllEnodeBWithRepectToMarket(marketId, venodorName);
		return mEnodeBs;// new ResponseEntity<List<EnodeB>>(mEnodeBs, HttpStatus.OK);
	}

	@GetMapping(path = "/reportTypes", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportType>> getAllReportTypes() {
		return new ResponseEntity<List<ReportType>>(iAdHocServiceable.getAllReportTypes(), HttpStatus.OK);
	}

	@GetMapping(path = "/cellGroups", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ElementGroup>> getAllCellGroup() {
		return new ResponseEntity<List<ElementGroup>>(iAdHocServiceable.getAllCellGroup(iUser.getUserName()),
				HttpStatus.OK);
	}

	@GetMapping(path = "/uacs", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ArrayList<ListItem>> getAllUAC(
			@RequestParam(value = "regionsIid", required = true) String regionsIid) {
		ArrayList<ListItem> mListUacs = null;
		ArrayList<ListItem> listAllUacs = new ArrayList<ListItem>();
		if (regionsIid != null) {
			String[] regionIids = regionsIid.split(",");
			for (String Iid : regionIids) {
				mListUacs = db.JdbcEnodeBDao.getUACsForRegion(jdbcDao, Iid);
				listAllUacs.addAll(mListUacs);
			}
			return new ResponseEntity<ArrayList<ListItem>>(listAllUacs, HttpStatus.OK);
		} else {
			return new ResponseEntity<ArrayList<ListItem>>(mListUacs, HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(path = "/uacs/enodebs", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ArrayList> getAllEnodebByUAC(@RequestParam(value = "uacs", required = true) String uacs) {
		ArrayList mListUacs = db.JdbcEnodeBDao.getEnodeBsForUACs(jdbcDao, (ArrayList) Arrays.asList(uacs.split(",")),
				"nbr");
		return new ResponseEntity<ArrayList>(mListUacs, HttpStatus.OK);
	}

	@GetMapping(path = "/contents", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Content>> getAllContent() {
		return new ResponseEntity<List<Content>>(iAdHocServiceable.getAllContent(), HttpStatus.OK);
	}

	@GetMapping(path = "/contents/levels/{reportlvl}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Content>> getAllContentByReportLevel(@PathVariable Integer reportlvl) {
		return new ResponseEntity<List<Content>>(iAdHocServiceable.getAllContentByReportLevel(reportlvl),
				HttpStatus.OK);
	}

	@GetMapping(path = "/contents/types/{reportTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Content>> getAllContentByReportType(@PathVariable Integer reportTypeId) {
		return new ResponseEntity<List<Content>>(iAdHocServiceable.getAllContentByReportType(reportTypeId),
				HttpStatus.OK);
	}
	
	@GetMapping(path = "/contents/types/{reportlvl}/{reportTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Content>> getAllContentByReportType(@PathVariable Integer reportlvl, @PathVariable Integer reportTypeId){
		List<Content> contentList=new ArrayList();
		Set<Integer> result=new HashSet();
		for(Content content : iAdHocServiceable.getAllContentByReportLevel(reportlvl)) {
			result.add(content.getcId());
		}
		for(Content content : iAdHocServiceable.getAllContentByReportType(reportTypeId)){
			if(!result.add(content.getcId())) {
				contentList.add(content);
			}
		}
		
		return new ResponseEntity<List<Content>>(contentList, HttpStatus.OK);
	}
	
	@GetMapping(path = "/thresholds/{templeteId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Formula>> getAllThresholdByContentTemplateId(@PathVariable Long templeteId) {
		return new ResponseEntity<List<Formula>>(iAdHocServiceable.getAllThresholdByContentTemplateId(templeteId),
				HttpStatus.OK);
	}

	// for clpt

//	@GetMapping(path = "/myVolteCores", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<List<ListItem>> getMyVolteCores() {
//		return new ResponseEntity<List<ListItem>>(JdbcMyNetElemDao.getMyVolteCores(jdbcDao, iUser.getUserName()),
//				HttpStatus.OK);
//	}
//
//	@GetMapping(path = "/myMrfClusters", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<List<ListItem>> getMyMrfcClusters() {
//		return new ResponseEntity<List<ListItem>>(JdbcMyNetElemDao.getMyMrfcClusters(jdbcDao, iUser.getUserName()),
//				HttpStatus.OK);
//	}

	@GetMapping(path = "/myETAS", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ListItem>> getMyETAS() {
		return new ResponseEntity<List<ListItem>>(iAdHocServiceable.getMyETAS(iUser.getUserName(), jdbcDao),
				HttpStatus.OK);
	}

	@GetMapping(path = "/myETAS/coreId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ListItem>> getETASListItemsByCoreIids(
			@RequestParam(value = "coreIids", required = true) String coreIids) {
		List<Integer> listCoreIids = Stream.of(coreIids.split(",")).map(Integer::parseInt).collect(Collectors.toList());
		return new ResponseEntity<List<ListItem>>(
				JdbcMrfpDao.getETASListItemsByCoreIids(jdbcDao, new ArrayList<>(listCoreIids)), HttpStatus.OK);
	}

	@GetMapping(path = "/myMrfps/clustersIids", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ListItem>> getMrfpsListItemsForClustersIids(
			@RequestParam(value = "mrfpIids", required = true) String mrfpIids) {
		List<Integer> ids = Stream.of(mrfpIids.split(",")).map(Integer::parseInt).collect(Collectors.toList());
		return new ResponseEntity<List<ListItem>>(
				JdbcMrfpDao.getMrfpsListItemsForClustersIids(jdbcDao, new ArrayList<>(ids)), HttpStatus.OK);
	}

	@GetMapping(path = "/mySCGSites/siteIids", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ListItem>> getSCGSitesListItemsForSiteIids(
			@RequestParam(value = "scgIids", required = true) String scgIids) {
		List<Integer> ids = Stream.of(scgIids.split(",")).map(Integer::parseInt).collect(Collectors.toList());
		return new ResponseEntity<List<ListItem>>(
				JdbcMrfpDao.getSCGSitesListItemsForSiteIids(jdbcDao, new ArrayList<>(ids)), HttpStatus.OK);
	}

	@GetMapping(path = "/myMrfps/mrfpIids", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ListItem>> getMrfpsListItemsByMrfpIids(
			@RequestParam(value = "mrfpIids", required = true) String mrfpIids) {
		List<Integer> ids = Stream.of(mrfpIids.split(",")).map(Integer::parseInt).collect(Collectors.toList());
		return new ResponseEntity<List<ListItem>>(
				JdbcMrfpDao.getMrfpsListItemsByMrfpIids(jdbcDao, new ArrayList<>(ids)), HttpStatus.OK);
	}

	@GetMapping(path = "/myMrfp", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Mrfp>> getMrfpsForAllMrfcClusters() {
		return new ResponseEntity<List<Mrfp>>(JdbcMrfpDao.getMrfpsForAllMrfcClusters(jdbcDao), HttpStatus.OK);
	}

	@PostMapping("/reports")
	public JSONResponse saveReports(@Valid @RequestBody AdHocForm adHocForm, HttpServletRequest request) {
		logger.info("in saveReports");
		adHocForm.setUserName(iUser.getUserName());
		adHocForm.setRootPath(rootPath);
		JSONResponse response = new JSONResponse();
		try {
			Report report = null;
			ReportEngineModel reportEngineModel = null;
			BigDecimal reportId = null;
			response.setSuccess(false);
			report = new ReportDetailForm().createReportModel(jdbcDao, adHocForm);
			adHocForm.getReport().setUserName(iUser.getUserName());
			report.setUserName(iUser.getUserName());
			// Bug Fix: avoid using same template for reports other than SAH
			if(report.isSahReport())
				reportId = JdbcReportDao.insertReport(jdbcDao, report);
			else
				reportId = JdbcReportDao.createReport(jdbcDao, report, true);
			ReportEngine reportEngine = new ReportEngine();
			ReportInputParamsModel reportInputParamsModel = new ReportInputParamsModel();
			reportInputParamsModel.setReportId(reportId.toString());
			reportInputParamsModel.setUserId(report.getUserName());
			reportInputParamsModel.setCreateCSVFile(false);
			reportInputParamsModel.setCreatePDFFile(false);
			reportInputParamsModel.setRptMethod(GlobalConstants.RPTMETHOD_SAH);
			reportInputParamsModel.setRootPath(rootPath);
			reportInputParamsModel.setUserRootPath(userRootPath);

			// NTSCA-1503
			reportInputParamsModel.setUserSourceIp(HttpRequestUtil.getClientIP(request));

			// Added for RTT percent
			if(!EnvironmentUtil.AppId.equalsIgnoreCase("clpt")) {
				reportInputParamsModel.setRttPercent(adHocForm.getRttPercent());
				if (adHocForm.getRegions() != null && adHocForm.getRegions().size() > 0) {
					String[] regionsSelected = adHocForm.getRegions().stream().toArray(n -> new String[n]);
					reportInputParamsModel.setRegionsSelected(regionsSelected);
				}
			}

			logger.info("going to reportEngine");
			reportEngineModel = reportEngine.populateData(jdbcDao, reportInputParamsModel);
			response.setSuccess(reportEngineModel != null ? true : false);
			response.setId(reportId + "");
			response.setMessages(reportEngineModel.getHttpPath());
		} catch (DataAccessException e) {
			response.setMessages(e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			response.setMessages(e.getMessage());
			e.printStackTrace();
		}

		return response;

	}

	// If the "Save this config as" button was clicked then call the
	// report builder to build the report and save the report id.
	// NOTE: with the exception of checking for duplicate reportNames,
	// all edits to guarantee the user submitted a valid set of
	// report parameters are done in strucadhoc.jsp.
	// Note: Duplicating behaviour from old tool
	@PostMapping("/savereports")
	public JSONResponse saveReportsAs(@Valid @RequestBody AdHocForm adHocForm) {
		logger.info("Inside saveReports ...");
		adHocForm.setUserName(iUser.getUserName());
		adHocForm.setRootPath(rootPath);
		JSONResponse response = new JSONResponse();
		try {
			String strLoginId = adHocForm.getUserName();
			String rptName = adHocForm.getReport().getReportName();
			response.setSuccess(false);
			if ( rptName != null && rptName.length() > 0 ) {
				if ( JdbcReportDao.checkUserReportName(jdbcDao, strLoginId, rptName )) {
					Report report = null;
					BigDecimal reportId = null;
					report = new ReportDetailForm().createReportModel(jdbcDao, adHocForm);
					report.setReportName(rptName);
					report.setIsSAHRpt("N");
//					reportId = JdbcReportDao.insertReport(jdbcDao, report);

					// createReport() will:
					// Assign the Report a new reportId, and
					// write it to the db.  Also create copies of the
					// report's element_list_details, filter_criteria_details,
					// and sql_filter_criteria, modify them with the new
					// reportId, update their pk_ids and parent_pk_ids as
					// required, and write them to the db also.  It
					// will create new templates and formulas that are
					// completely independent of the originals and can
					// be deleted or modified by the user in any way without
					// any effect on the originals.
					reportId = JdbcReportDao.createReport(jdbcDao, report, true);
					logger.info("Completed saveReports for : [" + reportId.toString() + "]");
					response.setMessages("Report has been created.");
					response.setSuccess(true);
				}
				else {
					response.setMessages("A report named " + rptName + " already exists."+ " This report config cannot be saved.");
					response.setSuccess(false);
				}
			}
			else {
				response.setMessages("You must provide a non-empty report name.");
				response.setSuccess(false);
			}
		} catch (DataAccessException e) {
			response.setMessages(e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			response.setMessages(e.getMessage());
			e.printStackTrace();
		}
		return response;
	}


	@GetMapping("/reports/download/{fileName}/{formate}/{userName}")
	public void download(@PathVariable String fileName, @PathVariable String formate, @PathVariable String userName,
			HttpServletResponse resp) {

		fetchFile(fileName, formate, resp, userName);
	}

	private void fetchFile(String fileName, String formate, HttpServletResponse resp, String userName) {

		rootPath = rootPath.replace(".", "");
		String user = userName == null ? iUser.getUserName() : userName;
		File file = null;
		String cApp = EnvironmentUtil.AppId;// );iUser.getCuurentApp();
		String filePath = null;
		if (cApp.equalsIgnoreCase("alte")) {
			filePath = System.getenv("ALPT_ROOT_PATH");
		} else if (cApp.equalsIgnoreCase("elte")) {
			filePath = System.getenv("ELPT_ROOT_PATH");
		} else {
			filePath = System.getenv("CLPT_ROOT_PATH");
		}
		if (formate.equals("csv")) {
			file = new File(filePath + "/" + user + "/" + fileName + ".csv");
			if (!file.exists()) {
				file = new File(filePath + "/" + fileName + ".csv");
			}
		} else {
			file = new File(filePath + "/" + user + "/" + fileName + ".xls");// xls
			if (!file.exists()) {
				file = new File(filePath + "/" + fileName + ".xls");
			}
		}

		try {
			InputStream is = FileUtils.openInputStream(file);
			IOUtils.copy(is, resp.getOutputStream());
			resp.flushBuffer();
		} catch (IOException e) {
			logger.error("fetchFile->" + fileName + "->" + formate + "Not found");
			e.printStackTrace();
		}

	}

}
