package com.vzw.ns.controllers;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.util.ClearCacheUtil;
import web.cellgroups.JSONResponse;

@RequestMapping(value = "/pt/caches")
@RestController
public class RedisAdminController {
	


	protected final Log logger = LogFactory.getLog(this.getClass());

	@Autowired
	@Qualifier("myACacheManager")
	private CacheManager cacheManager;
	
	@Autowired
	private StringRedisTemplate template;

	// Delete all the keys of all the existing cacge DB.
	@RequestMapping(value = "/flush-all", method = RequestMethod.GET)
	public JSONResponse clearAllCache() {
		JSONResponse response = new JSONResponse();
		ClearCacheUtil.clearAllCache();

		RedisConnection myConnection = template.getConnectionFactory().getConnection();
		myConnection.flushAll();
		myConnection.close(); // must close after use so it connection pool replenished.
		evictAllCaches();

		response.setMessages("Cache has been cleared!");
		response.setSuccess(true);
		return response;
	}
	


	public void evictAllCaches() {
	    cacheManager.getCacheNames().stream()
	      .forEach(cacheName ->{
	    	  System.out.println("cleared cache->"+cacheName);
	    	  cacheManager.getCache(cacheName).clear();
	      });
	}

	@Scheduled(fixedRate = 3600)
	public void evictAllcachesAtIntervals() {
	    evictAllCaches();
	}
	
	

}
