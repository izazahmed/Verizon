package com.vzw.ns.controllers;

import bus.ListItem;
import bus.formula.Formula;
import bus.location.EnodeB;
import bus.location.Market;
import com.sun.org.apache.xpath.internal.operations.Bool;
import db.JdbcCellGroupDao;
import db.JdbcDao;
import db.JdbcReportLevelDao;
import db.cellgroups.JdbcCgaDao;
import db.location.JdbcEnodeBDao;
import db.location.JdbcMarketDao;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.dao.DBLocationsDAO;
import org.vzw.lte.dao.ReportInstanceDAO;
import org.vzw.lte.model.*;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.GeneralUtility;
import org.vzw.lte.util.ReportTypeConstants;
import web.services.LteWebserviceUtil;
import web.services.ReportWebServiceUtil;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.*;

/**
 * This webservice will be used by users to request data like user enodeb groups, etc.
 *
 * @author amit.chauhan
 *         Nov 17, 2010
 */
@RestController
@RequestMapping(value = "/api", method = RequestMethod.GET)
public class LteWebserviceController {
    private static final Logger logger = LoggerFactory.getLogger(LteWebserviceController.class);

    @Autowired
    private JdbcDao jdbcDao;

    /*
     * (non-Javadoc)
     *
     * @see org.springframework.web.servlet.mvc.Controller#handleRequest(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @RequestMapping(value = "/getDataWebService.htm", method = RequestMethod.GET)
    @ResponseBody
    public void runDataWebService(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String action = GeneralUtility.trim(request.getParameter(ReportWebServiceUtil.REQ_PARAM_ACTION));
        ArrayList<ArrayList<String>> data = null;

        if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORTTYPES_WS)) {
            data = handleGetReportTypes(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORTLEVELS_WS)) {
            data = handleGetReportLevels(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_MMEPOOLS_REGIONS_WS)) {
            data = handleGetMMEPoolsAndRegions(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_MMES_WS)) {
            data = handleGetMMEs(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_SGWs_WS)) {
            data = handleGetSGWs(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_MARKETS)) {
            data = handleGetMarketList(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_MARKETS_WS)) {
            data = handleGetMarkets(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_ENODEB_GROUPS)) {
            data = handleGetEnodebGroupList(request);
        }  else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_ENODEB_GROUPS_AND_SUBS)) {
            data = handleGetEnodebGroupsAndSubsList(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_ENODEBS)) {
            data = handleGetEnodebList(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORTS)) {
            data = handleGetReportsList(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_PGWs_WS)) {
            data = handleGetPGWs(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORTSINFO_FOR_UPLOADING)) {
            data = handleGetReportInfoForUploading(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORT_KPIS)) {
            data = handleGetReportKPIsList(request);
        } else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_CONTENT_KPIS)) {
            data = handleGetSahKPIsList(request);
        }

        sendFile(request, response, data);
    }

    public ArrayList<ArrayList<String>> handleGetMarkets(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

        String marketShortName = request.getParameter(LteWebserviceUtil.REQ_PARAM_MARKET_SHORTNAME);

        LinkedHashMap<String, Market> mapOfMarkets = DBLocationsDAO.populateMarketMap(jdbcDao);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("MARKET_ID");
        headerRow.add("MARKET_NAME");
        if (StringUtils.isNotEmpty(marketShortName) && StringUtils.isNotBlank(marketShortName) && StringUtils.equalsIgnoreCase(marketShortName, "y")) {
            headerRow.add("MARKET_SHORT_NAME");
        }
        data.add(headerRow);

        if (mapOfMarkets != null) {
            Collection<Market> collection = mapOfMarkets.values();
            Iterator<Market> itr = collection.iterator();
            while (itr.hasNext()) {
                Market market = itr.next();
                if (market == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(market.getMarketDisplayId());
                dataRow.add(market.getMarketName());
                if (StringUtils.isNotEmpty(marketShortName) && StringUtils.isNotBlank(marketShortName) && StringUtils.equalsIgnoreCase(marketShortName, "y")) {
                    dataRow.add(market.getMarketShortname());
                }
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetMMEs(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

        LinkedHashMap<String, MME> mmeMap = DBLocationsDAO.populateMMEMap(jdbcDao);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("MME");
        data.add(headerRow);

        if (mmeMap != null) {
            Collection<MME> collection = mmeMap.values();
            Iterator<MME> itr = collection.iterator();
            while (itr.hasNext()) {
                MME mme = itr.next();
                if (mme == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(mme.getMmeLocation());
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetSGWs(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

        LinkedHashMap<String, SGW> sgwMap = DBLocationsDAO.populateSGWMap(jdbcDao);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("SGW");
        data.add(headerRow);

        if (sgwMap != null) {
            Collection<SGW> collection = sgwMap.values();
            Iterator<SGW> itr = collection.iterator();
            while (itr.hasNext()) {
                SGW sgw = itr.next();
                if (sgw == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(sgw.getSgwLocation());
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetPGWs(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

        LinkedHashMap<String, PGW> pgwMap = DBLocationsDAO.populatePGWMap(jdbcDao);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("PGW");
        data.add(headerRow);

        if (pgwMap != null) {
            Collection<PGW> collection = pgwMap.values();
            Iterator<PGW> itr = collection.iterator();
            while (itr.hasNext()) {
                PGW pgw = itr.next();
                if (pgw == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(pgw.getPgwLocation());
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetReportTypes(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

        List<String> reportTypes = ReportTypeConstants.LIST_OF_ALL_REPORT_TYPES;
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("REPORT_TYPE");
        data.add(headerRow);

        if (reportTypes != null) {
            Iterator<String> itr = reportTypes.iterator();
            while (itr.hasNext()) {
                String reportType = itr.next();
                if (reportType == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(reportType);
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetReportLevels(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

        List<ListItem> reportLevels = (ArrayList<ListItem>) JdbcReportLevelDao.getReportLevels(jdbcDao);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("REPORT_LEVEL");
        data.add(headerRow);

        if (reportLevels != null) {
            Iterator<ListItem> itr = reportLevels.iterator();
            while (itr.hasNext()) {
                ListItem li = itr.next();
                if (li == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(li.getReportEngineValue());
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetMMEPoolsAndRegions(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

        LinkedHashMap<String, RegionMmePoolViewModel> mapWithRegionIidAsKey = DBLocationsDAO.populateRegionMmePoolView(jdbcDao);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("MMEPOOL_ID");
        headerRow.add("MMEPOOL_NAME");
        headerRow.add("REGION_IID");
        headerRow.add("REGION_NAME");
        data.add(headerRow);

        if (mapWithRegionIidAsKey != null) {
            Collection<RegionMmePoolViewModel> collection = mapWithRegionIidAsKey.values();
            Iterator<RegionMmePoolViewModel> itr = collection.iterator();
            while (itr.hasNext()) {
                RegionMmePoolViewModel regionMmePoolViewModel = itr.next();
                if (regionMmePoolViewModel == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(regionMmePoolViewModel.getMmePoolId());
                dataRow.add(regionMmePoolViewModel.getMmePoolName());
                dataRow.add(String.valueOf(regionMmePoolViewModel.getRegionIid()));
                dataRow.add(regionMmePoolViewModel.getRegionName());
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetMarketList(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
        String regionName = request.getParameter(LteWebserviceUtil.REQ_PARAM_REGION);
        if (GeneralUtility.isEmpty(regionName)) {
            regionName = "";
        }
        ArrayList<Market> listOfMarkets = JdbcMarketDao.populateMarketsByRegionName(jdbcDao, regionName);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("MARKET_NAME");
        headerRow.add("MARKET_IID");
        headerRow.add("MARKET_ID");
        headerRow.add("REGION_IID");
        headerRow.add("REGION_NAME");
        data.add(headerRow);

        if (listOfMarkets != null) {
            Iterator<Market> itr = listOfMarkets.iterator();
            while (itr.hasNext()) {
                Market market = itr.next();
                if (market == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(market.getMarketName());
                dataRow.add(String.valueOf(market.getIid()));
                dataRow.add(market.getMarketDisplayId());
                dataRow.add(String.valueOf(market.getRegion_iid()));
                dataRow.add(market.getRegionName());
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetEnodebGroupList(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
        String user = request.getParameter(LteWebserviceUtil.REQ_PARAM_USER);
        List listOfEnodebGroups = JdbcCgaDao.getEnodeBGroupsForUser(jdbcDao, user);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("GROUP_NAME");
        headerRow.add("IID");
        headerRow.add("OWNER");
        data.add(headerRow);

        if (listOfEnodebGroups != null) {
            Iterator itr = listOfEnodebGroups.iterator();
            while (itr.hasNext()) {
                ListItem li = (ListItem)itr.next();
                if (li == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(li.getName());
                dataRow.add(li.getId());
                dataRow.add(li.getOtherMisc());
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetEnodebGroupsAndSubsList(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
        String user = request.getParameter(LteWebserviceUtil.REQ_PARAM_USER);
        List listOfEnodebGroups = JdbcCellGroupDao.getMyCellGroupsAndSubs(jdbcDao, user);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("GROUP_NAME");
        headerRow.add("IID");
        headerRow.add("OWNER");
        data.add(headerRow);

        if (listOfEnodebGroups != null) {
            Iterator itr = listOfEnodebGroups.iterator();
            while (itr.hasNext()) {
                ListItem li = (ListItem)itr.next();
                if (li == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(li.getName());
                dataRow.add(li.getId());
                dataRow.add(li.getOtherMisc());
                data.add(dataRow);
            }
        }
        return data;
    }


    public ArrayList<ArrayList<String>> handleGetEnodebList(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
        ArrayList<EnodeB> listOfEnodeb = null;

        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();


        if(request.getParameter(LteWebserviceUtil.REQ_PARAM_MARKET) != null){
            // Let us pull data based on market name
            String marketName = request.getParameter(LteWebserviceUtil.REQ_PARAM_MARKET);
            listOfEnodeb = JdbcEnodeBDao.populateEnodeBsByMarketName(jdbcDao, marketName);
            headerRow.add("SITE_NAME");
            headerRow.add("ENODEB_IID");
            headerRow.add("ENODEB_ID");
            headerRow.add("MARKET_NAME");
            headerRow.add("MARKET_IID");
            headerRow.add("MARKET_ID");
            data.add(headerRow);
            if (listOfEnodeb != null) {
                Iterator<EnodeB> itr = listOfEnodeb.iterator();
                while (itr.hasNext()) {
                    EnodeB model = itr.next();
                    if (model == null) {
                        continue;
                    }
                    ArrayList<String> dataRow = new ArrayList<String>();
                    dataRow.add(model.getSiteName());
                    dataRow.add(String.valueOf(model.getIid()));
                    dataRow.add(model.getEnodeBId());
                    dataRow.add(model.getMarketName());
                    dataRow.add(String.valueOf(model.getMarketIid()));
                    dataRow.add(model.getMarketDisplayId());
                    data.add(dataRow);
                }
            }

        }
        else if(request.getParameter(LteWebserviceUtil.REQ_PARAM_ENODEB_GROUP) != null){
            // if user is requesting data based on enode b group
            String userPlusEnodebGroupName = request.getParameter(LteWebserviceUtil.REQ_PARAM_ENODEB_GROUP);
            listOfEnodeb = JdbcEnodeBDao.populateEnodeBsByEnodebGroup(jdbcDao, userPlusEnodebGroupName);
            headerRow.add("SITE_NAME");
            headerRow.add("ENODEB_IID");
            headerRow.add("ENODEB_ID");
            headerRow.add("GROUP_NAME");
            headerRow.add("ENODEB_GROUP_IID");
            headerRow.add("MARKET_IID");
            headerRow.add("MARKET_ID");
            data.add(headerRow);
            if (listOfEnodeb != null) {
                Iterator<EnodeB> itr = listOfEnodeb.iterator();
                while (itr.hasNext()) {
                    EnodeB model = itr.next();
                    if (model == null) {
                        continue;
                    }
                    ArrayList<String> dataRow = new ArrayList<String>();
                    dataRow.add(model.getSiteName());
                    dataRow.add(String.valueOf(model.getIid()));
                    dataRow.add(model.getEnodeBId());
                    dataRow.add(model.getEnodebGroupName());
                    dataRow.add(String.valueOf(model.getEnodebGroupIid()));
                    dataRow.add(String.valueOf(model.getMarketIid()));
                    dataRow.add(model.getMarketId());
                    data.add(dataRow);
                }
            }
        }

        return data;
    }


    public ArrayList<ArrayList<String>> handleGetReportsList(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
        String user = request.getParameter(LteWebserviceUtil.REQ_PARAM_USER);
        String excludeSAH = request.getParameter(LteWebserviceUtil.REQ_PARAM_EXCLUDE_SAH);
        String excludeWS = request.getParameter(LteWebserviceUtil.REQ_PARAM_EXCLUDE_WS);
        List<List<String>> listOfReports= JdbcCgaDao.getReportsForUser(jdbcDao, user, excludeSAH, excludeWS);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("USER_NAME");
        headerRow.add("REPORT_ID");
        headerRow.add("REPORT_LEVEL");
        headerRow.add("REPORT_NAME");
        headerRow.add("DATE_CREATED");
        headerRow.add("END_DATE");
        headerRow.add("IS_SAH_RPT");
        data.add(headerRow);

        if (listOfReports != null) {
            Iterator itr = listOfReports.iterator();
            while (itr.hasNext()) {
                ArrayList<String> dataRow = (ArrayList<String>)itr.next();
                if (dataRow == null) {
                    continue;
                }
                data.add(dataRow);
            }
        }
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetReportInfoForUploading(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

        String appType = request.getParameter("appType");
        String numDays = request.getParameter("numDays");
        String rptType = request.getParameter("rptType");
        if (appType == null || appType.equals("")) {
            // Log error
            ArrayList<String> error = new ArrayList<String>();
            error.add("Error - No application type specified.");
            data.add(error);
            return data;
        }

        String rptUploadStatus = EnvironmentUtil.getValueForKeyFromLTEConfigDbTable(jdbcDao, "lte.report.uploading");
        if (rptUploadStatus == null || rptUploadStatus.equalsIgnoreCase("OFF")) {
            ArrayList<String> error = new ArrayList<String>();
            error.add("Warning - Uploading of reports for " + appType + " has been turned off.");
            data.add(error);
            return data;
        }

        // Default number of days is 1
        int nDays = 1;
        if ( numDays != null && !numDays.equals("")) {
            nDays = Integer.valueOf(numDays);
        }

        if (rptType == null || rptType.equals(""))
            rptType = "SCHED";

        List listOfReportsInstance = ReportInstanceDAO.getReportsInfoForUploading(jdbcDao, nDays, rptType);
        Iterator<ReportInstanceModel> itrReports = listOfReportsInstance.iterator();
        while (itrReports.hasNext()) {
            ReportInstanceModel model = itrReports.next();
            ArrayList<String> row = new ArrayList<String>();
            row.add(model.getLocation());

            data.add(row);
        }
        if ( data.size() == 0 ) {
            ArrayList<String> nodata = new ArrayList<String>();
            nodata.add("No data returned by query for " + appType.toUpperCase() + " report type=" + rptType + " for the last " + String.valueOf(nDays) + " day(s)" );
            data.add(nodata);
        }

        return data;
    }

    /**
     * @param jdbcDao
     *            the jdbcDao to set
     */
    public void setJdbcDao(JdbcDao jdbcDao) {
        this.jdbcDao = jdbcDao;
    }

    public void sendFile(HttpServletRequest request, HttpServletResponse response, ArrayList<ArrayList<String>> data) {
        BufferedReader in = null;
        ServletOutputStream outs = null;
        try {
            // take the message from the URL or create default message
            String nameForSavingFile = "data.csv";

            // setting some response headers
            response.setHeader("Expires", "0");
            response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
            response.setHeader("Pragma", "public");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + nameForSavingFile + "\"");
            // setting the content type
            response.setContentType("application/csv");
            outs = response.getOutputStream();

            if (data == null || data.isEmpty()) {
                outs.println("Unable to pull data");
            }
            else {
                Iterator<ArrayList<String>> itrForRows = data.iterator();
                while (itrForRows.hasNext()) {
                    ArrayList<String> listOfCols = itrForRows.next();

                    StringBuffer sbRow = new StringBuffer();
                    if (listOfCols != null) {
                        Iterator<String> itrCols = listOfCols.iterator();
                        while (itrCols.hasNext()) {
                            String colVal = itrCols.next();
                            sbRow.append(colVal);
                            if (itrCols.hasNext()) {
                                sbRow.append(",");
                            }
                        }
                    }
                    String formattedLine = sbRow.toString();
                    if (GeneralUtility.isNonEmpty(formattedLine)) {
                        outs.println(formattedLine);
                    }
                }
            }
            outs.flush();
        }
        catch (Exception e2) {
            logger.error("Error in " + getClass().getName() + "\n" + e2);
        }
        finally {
            try {
                if (in != null) {
                    // flush and close both "input" and its underlying FileReader
                    in.close();
                }
                if (outs != null) {
                    outs.close();
                }
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    public ArrayList<ArrayList<String>> handleGetReportKPIsList(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
        String exampleUrl = "http://txsl5gptpw4:8181/api/getDataWebService.htm?action=get_report_kpis&user=shreas1&report_name=test";
        String user = preprocessInputs(request, LteWebserviceUtil.REQ_PARAM_USER, exampleUrl, false);
        String report_name = preprocessInputs(request, LteWebserviceUtil.REQ_PARAM_REPORT_NAME, exampleUrl, false);

        //check if correct parameters are passed
        if(user.contains("ERROR") || report_name.contains("ERROR") ){
            ArrayList<String> error = new ArrayList<>();
            error.add("user: " + user);
            error.add("report_name: " + report_name);
            data.add(error);
            return data;
        }

        logger.debug("Getting KPIs for report: " + report_name + " Owner: " + user);

        List<Formula> listOfReports = JdbcCgaDao.getReportKPIs(jdbcDao, user, report_name);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("KPI");
        headerRow.add("FORMULA");
        headerRow.add("OWNER");
        data.add(headerRow);

        if (listOfReports != null) {
            Iterator itr = listOfReports.iterator();
            while (itr.hasNext()) {
                Formula li = (Formula)itr.next();
                if (li == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(li.getFormulaName());
                dataRow.add(li.getFormulaText());
                dataRow.add(li.getUserName());
                data.add(dataRow);
            }
        }

        logger.debug("Completed! Getting KPIs for report: " + report_name + " Owner: " + user);
        return data;
    }

    public ArrayList<ArrayList<String>> handleGetSahKPIsList(HttpServletRequest request) {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
        String exampleUrl = "http://txsl5gptpw4:8181/api/getDataWebService.htm?action=get_content_kpis&content=HQ%20LTE%20KPIs&show_kpi=yes";
        String contentName = preprocessInputs(request, LteWebserviceUtil.REQ_PARAM_CONTENT_NAME, exampleUrl, false);
        String showContentDetail = preprocessInputs(request, LteWebserviceUtil.REQ_PARAM_CONTENT_DETAIL, exampleUrl, true);
        ArrayList<String> error = new ArrayList<>();
        // check if contentName is valid
        if(contentName.contains("ERROR")){
            error.add("contentName: " + contentName);
            data.add(error);
            return data;
        }
        logger.debug("Getting SAH content for => " + contentName + " || Show detail? => " + showContentDetail);

        ArrayList<String> listOfSAH = JdbcCgaDao.getSahContent (jdbcDao, contentName);
        if(listOfSAH!=null && listOfSAH.size()<=0) {
            error.add("Error! Not able to find report for SAH Content => " + contentName);
            data.add(error);
            return data;
        }

        ArrayList<String> header = new ArrayList<String>();
        header.add("SAH CONTENT");
        header.add("USER NAME");
        header.add("REPORT NAME");
        data.add(header);
        data.add(listOfSAH);

        // check if KPI needs to be displayed.
        if(showContentDetail==null || showContentDetail.trim().length()<=0 || !(showContentDetail.equalsIgnoreCase("YES") || showContentDetail.equalsIgnoreCase("Y"))){
            return data;
        }

        String user = listOfSAH.get(1);
        String report_name = listOfSAH.get(2);
        List<Formula> listOfReports = JdbcCgaDao.getReportKPIs(jdbcDao, user, report_name);
        // add header row.
        ArrayList<String> headerRow = new ArrayList<String>();
        headerRow.add("KPI");
        headerRow.add("FORMULA");
        headerRow.add("OWNER");
        data.add(headerRow);

        if (listOfReports != null) {
            Iterator itr = listOfReports.iterator();
            while (itr.hasNext()) {
                Formula li = (Formula)itr.next();
                if (li == null) {
                    continue;
                }
                ArrayList<String> dataRow = new ArrayList<String>();
                dataRow.add(li.getFormulaName());
                dataRow.add(li.getFormulaText());
                dataRow.add(li.getUserName());
                data.add(dataRow);
            }
        }

        return data;
    }

    public String preprocessInputs(HttpServletRequest request, String param, String url, Boolean isOptional){
        String paramValue = null;
        try {
            paramValue = request.getParameter(param).trim();
        } catch(Exception e){
            if(!isOptional) {
                paramValue = "ERROR! Malformed URL. Parameter missing for => " + param + " \n";
                paramValue += "Example: " + url + "\n";
            }
            return paramValue;
        }

        if(paramValue.startsWith("\"") || paramValue.startsWith("\'")){
            paramValue = paramValue.substring(1);
        }
        if(paramValue.endsWith("\"") || paramValue.endsWith("\'")){
            paramValue = paramValue.substring(0,paramValue.length()-1);
        }

        return paramValue;
    }
}
