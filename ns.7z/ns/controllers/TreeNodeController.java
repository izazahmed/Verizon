package com.vzw.ns.controllers;

import bus.tree.Tree;
import com.vzw.ns.model.FormulaNode;
import com.vzw.web.cellgroups.JSONResponse;

import db.JdbcDao;
import db.tree.JdbcSetupTreeDao;
import db.tree.JdbcTreeDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by gundaja on 12/9/16.
 */
@RestController
@RequestMapping(value = "/pt/treenodes")
public class TreeNodeController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	public static final String TREE_NODE_CACHE_KEY = "tree-nodes";
	public static final String REPORT = "report";
	public static final String FOLDERS = "folders";
	public static final String FORMULA = "formula";

	@Autowired
	private JdbcDao jdbcDao;

	@Cacheable(value = TREE_NODE_CACHE_KEY,keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
	@RequestMapping(value = "/nodes/{type}", method = RequestMethod.GET)
	@ResponseBody
	public List<FormulaNode> getOmList(@PathVariable String type) throws SQLException {
		return JdbcSetupTreeDao.setupNodeTreeByType(jdbcDao, type);
	}

	@CacheEvict(value = { TreeNodeController.TREE_NODE_CACHE_KEY,
			TreeNodeController.TREE_NODE_CACHE_KEY }, allEntries = true)
	@RequestMapping(value = "/nodes/{type}/{userName}", method = RequestMethod.GET)
	@ResponseBody
	public List<Tree> buildTree(@PathVariable String type, @PathVariable String userName,
			@RequestParam(value = "includeSah", required = true) String includeSah,
			@RequestParam(value = "includeWSReports", required = true) String includeWSReports
			) throws SQLException {
		TreeNodeController.clearUserReportTree(userName);
		return JdbcTreeDao.drawTreeByType(jdbcDao, type, userName, includeSah, includeWSReports, "", "Standard");
	}
	
	@Cacheable(value = TREE_NODE_CACHE_KEY, keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
	@RequestMapping(value = "/nodes/path/{userName}", method = RequestMethod.GET)
	@ResponseBody
	public List<Tree> searchPath(@PathVariable String userName) throws SQLException {
		return JdbcTreeDao.searchPath(jdbcDao, userName);
	}

	@Cacheable(value = TREE_NODE_CACHE_KEY,  keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
	@RequestMapping(value = "/nodes/wc/{type}/{userName}", method = RequestMethod.GET)
	@ResponseBody
	public List<Tree> buildTreeWc(@PathVariable String type, @PathVariable String userName) throws SQLException {
		return JdbcTreeDao.drawTreeByType(jdbcDao, type, userName, "false", "true", "", "Standard");
	}

	
	@Cacheable(value = TREE_NODE_CACHE_KEY, keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
	@RequestMapping(value = "/nodes/sah/{type}/{userName}", method = RequestMethod.GET)
	@ResponseBody
	public List<Tree> buildTreeSah(@PathVariable String type, @PathVariable String userName) throws SQLException {
		return JdbcTreeDao.drawTreeByType(jdbcDao, type, userName, "true", "false", "", "Standard");
	}

	
	
	@Cacheable(value = TREE_NODE_CACHE_KEY, keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
	@RequestMapping(value = "/nodes/{type}/{userId}/{folderId}", method = RequestMethod.GET)
	@ResponseBody
	public List<Tree> buildSubTreeFormula(@PathVariable String type, @PathVariable String userId, @PathVariable String folderId,
			@RequestParam(value = "includeSah", required = true) String includeSah,
			@RequestParam(value = "includeWSReports", required = true) String includeWSReports
			) throws SQLException {
		return JdbcTreeDao.drawTreeByType(jdbcDao, type, userId, includeSah, includeWSReports, folderId, "Standard");
	}

	@CacheEvict(value = TreeNodeController.TREE_NODE_CACHE_KEY, allEntries = true)
	@RequestMapping(value = "/nodes/{id}/flush-all", method = RequestMethod.GET)
	public JSONResponse clearAllTreeNodes(@PathVariable String id) {
		JSONResponse response = new JSONResponse();
		response.setSuccess(true);
		response.setMessages("Cache has been cleared!.");
		return response;
	}

	@CacheEvict(value = TreeNodeController.TREE_NODE_CACHE_KEY, allEntries = true)
	public static JSONResponse clearAllFormulaTree(@PathVariable String id) {
		JSONResponse response = new JSONResponse();
		response.setSuccess(true);
		response.setMessages("Cache has been cleared!.");
		return response;
	}
	
	@CacheEvict(value = TreeNodeController.TREE_NODE_CACHE_KEY, allEntries = true)
	public static JSONResponse clearUserReportTree(String id) {
		JSONResponse response = new JSONResponse();
		response.setSuccess(true);
		response.setMessages("Cache has been cleared!.");
		return response;
	}
}
