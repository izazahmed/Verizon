package com.vzw.ns.controllers;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.vzw.ns.model.SahTemplateOwner;
import db.cellgroups.JdbcCgaDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.dao.DataAccessException;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.action.ReportEngine;
import org.vzw.lte.model.ReportEngineModel;
import org.vzw.lte.model.ReportInputParamsModel;
import org.vzw.lte.util.GlobalConstants;

import com.vzw.ns.model.ReportDetailForm;
import com.vzw.web.cellgroups.JSONResponse;
import com.vzw.web.exception.MissingParameterException;

import bus.formula.Formula;
import bus.report.Report;
import db.JdbcDao;
import db.report.JdbcReportDao;
import db.report.JdbcTemplateDao;
import org.vzw.lte.util.HttpRequestUtil;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by gundaja on 2/7/18.
 */
@RequestMapping(value = "/pt/templates")
@RestController
public class TemplateController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private static final String KEY = "template";
	private static final String DETAIL_KEY = "template-details";
	private static final String TEMPLATE_OWNER_KEY = "template-owner";

	@Autowired
	private JdbcDao jdbcDao;

//    @Cacheable(value = KEY, keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
	@RequestMapping(value = "templates/{templateId}", method = RequestMethod.GET)
	public @ResponseBody List<Formula> getTemplateDetails(@PathVariable String templateId) throws SQLException {
    	logger.debug("Inside templates/template_id");
		return JdbcTemplateDao.getFormulasInfoByTemplateId(jdbcDao, templateId, false);
	}

	@Cacheable(value = DETAIL_KEY, keyGenerator = "customAKeyGenerator" ,cacheManager = "myACacheManager")
	@RequestMapping(value = "templates/{templateId}/show", method = RequestMethod.GET)
	public @ResponseBody List<Formula> getTemplateDetailsWithDetails(@PathVariable String templateId)
			throws SQLException {
		return JdbcTemplateDao.getFormulasInfoByTemplateId(jdbcDao, templateId, true);
	}

	//TMVF-105
	@Cacheable(value = TEMPLATE_OWNER_KEY, keyGenerator = "customAKeyGenerator" ,cacheManager = "myACacheManager")
	@RequestMapping(value = "templates/{templateId}/owner", method = RequestMethod.GET)
	public @ResponseBody List<SahTemplateOwner> getTemplateDetailsOwner(@PathVariable String templateId)
			throws SQLException {
		return JdbcCgaDao.getSahContentOwner(jdbcDao, templateId);
	}

	@CacheEvict(value = DETAIL_KEY, key = "#templateId", beforeInvocation = true)
	@Cacheable(value = DETAIL_KEY, key = "#templateId")
	@RequestMapping(value = "templates/{templateId}/refresh", method = RequestMethod.GET)
	public @ResponseBody List<Formula> getTemplateById(@PathVariable String templateId) throws SQLException {
		return getTemplateDetailsWithDetails(templateId);
	}

	@Caching(evict = { @CacheEvict(value = KEY, allEntries = true),
			@CacheEvict(value = DETAIL_KEY, allEntries = true) })

	@RequestMapping(value = "templates/flush-all", method = RequestMethod.GET)
	public static Boolean clearAllTemplates() {
		return true;
	}

	@RequestMapping(value = "runTemplate", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody JSONResponse processReport(@RequestBody ReportDetailForm form, HttpServletRequest request) {
		Report report = null;
		ReportEngineModel reportEngineModel = null;
		BigDecimal reportId = null;
		JSONResponse response = new JSONResponse();
		response.setSuccess(false);
		try {
			report = form.createReportModel(jdbcDao,"");

			reportId = JdbcReportDao.insertReport(jdbcDao, report);
			ReportEngine reportEngine = new ReportEngine();
			ReportInputParamsModel reportInputParamsModel = new ReportInputParamsModel();
			reportInputParamsModel.setReportId(reportId.toString());
			reportInputParamsModel.setUserId(report.getUserName());
			reportInputParamsModel.setCreateCSVFile(false);
			reportInputParamsModel.setCreatePDFFile(false);
			reportInputParamsModel.setRptMethod(GlobalConstants.RPTMETHOD_SAH);

			// NTSCA-1503
			reportInputParamsModel.setUserSourceIp(HttpRequestUtil.getClientIP(request));

			reportEngineModel = reportEngine.populateData(jdbcDao, reportInputParamsModel);
			response.setSuccess(true);
			response.setMessages(reportEngineModel.getHttpPath());
		} catch (DataAccessException e) {
			response.setMessages(e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			response.setMessages(e.getMessage());
			e.printStackTrace();
		}

		return response;
	}
}
