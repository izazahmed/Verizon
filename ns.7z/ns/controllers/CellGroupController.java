package com.vzw.ns.controllers;

import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.vzw.lte.util.GeneralUtility;

import com.vzw.ns.report.domain.CellGroup;
import com.vzw.web.cellgroups.JSONResponse;

import bus.ListItem;
import bus.location.EnodeB;
import db.JdbcCellGroupDao;
import db.JdbcDao;
import db.JdbcEnodeBDao;
import db.cellgroups.JdbcCgaDao;

@RequestMapping(value = "/pt/cellgroups")
@RestController
public class CellGroupController {

    protected final Log logger = LogFactory.getLog(this.getClass());
    @Autowired
    private JdbcDao jdbcDao;

    @RequestMapping(value = "/clusters/subscriptions/{userid}", method = RequestMethod.GET)
    public @ResponseBody
    List getMyCellGroupsAndSubs(@PathVariable String userid) {

        return JdbcCellGroupDao.getMyCellGroupsAndSubs(jdbcDao, userid);
    }

    @RequestMapping(value = "/clusters/users/{userName}", method = RequestMethod.GET)
    @ResponseBody
    public List<ListItem> getClusters(@PathVariable String userName) {
        List<ListItem> retValue = new ArrayList<>();
        if (GeneralUtility.isNonEmpty(userName)) {
            if (userName.equals("all"))
                retValue = JdbcCgaDao.getAllEnodeBGroups(jdbcDao);
            else
                retValue = JdbcCgaDao.getEnodeBGroupsForUser(jdbcDao, userName);
        }
        return retValue;
    }

    //TMVF-92/TMVF-93
    @RequestMapping(value = "/clusters/{clusterId}", method = RequestMethod.GET)
    @ResponseBody
    public List getClusterGroups(@PathVariable String clusterId) {
        return getEnodebsByCellGroupVendor(clusterId, "");
    }

    @RequestMapping(value = "/clusters/{clusterId}/detail", method = RequestMethod.GET)
    @ResponseBody
    public List getClusterGroup(@PathVariable String clusterId) {
        return JdbcCgaDao.getEnodeBsForGroups(jdbcDao, Arrays.asList(clusterId));
    }

    //TMVF-92/TMVF-93
    @RequestMapping(value = "/clusters/{clusterId}/{vendorName}", method = RequestMethod.GET)
    @ResponseBody
    public List getClusterGroup(@PathVariable String clusterId, @PathVariable String vendorName) {
        return getEnodebsByCellGroupVendor(clusterId, vendorName);
    }

    //TMVF-92/TMVF-93
    public List getEnodebsByCellGroupVendor(String clusterId, String vendorName){
        if(vendorName.equalsIgnoreCase("ALL"))
            vendorName = "";

        ArrayList<String> cellGroups = new ArrayList();
        if (clusterId.contains(",")) {
            cellGroups.addAll(Arrays.asList(clusterId.split(",")));
            return JdbcCgaDao.getEnodeBsForGroups(jdbcDao, Arrays.asList(clusterId), vendorName);
        } else {
            cellGroups.add(clusterId);
            return JdbcCgaDao.getEnodeBsForGroups(jdbcDao, Arrays.asList(clusterId), vendorName);
        }
    }

    @RequestMapping(value = "/clusters/{clusterId}/delete", method = RequestMethod.GET)
    public @ResponseBody
    JSONResponse deleteCluster(@PathVariable String clusterId) {
        JSONResponse response = new JSONResponse();
        response.setMessages("Cell group has been successfully deleted.");
        response.setSuccess(JdbcCgaDao.delEnodeBGroup(jdbcDao, clusterId));
        return response;
    }

    @RequestMapping(value = "/subscriptions/{userid}/markets/{marketId}", method = RequestMethod.GET)
    public @ResponseBody
    List getOwnersForMarket(@PathVariable String userid, @PathVariable String marketId) throws SQLException {
        return JdbcCgaDao.getPublicEnodeBGroupsForMarket(jdbcDao, userid, marketId);
    }

    @RequestMapping(value = "/subscriptions/{userid}/{clusterId}", method = RequestMethod.POST)
    public @ResponseBody
    JSONResponse subscribeToGroup(@PathVariable String userid, @PathVariable String clusterId) throws SQLException {
        JSONResponse response = new JSONResponse();
        boolean retVal = JdbcCgaDao.delEnodeBGroupSubscription(jdbcDao, userid, clusterId);
        response.setSuccess(JdbcCgaDao.addEnodeBGroupSubscription(jdbcDao, userid, clusterId));
        return response;
    }

    @RequestMapping(value = "/subscriptions/{userid}/{clusterId}/delete", method = RequestMethod.POST)
    public @ResponseBody
    JSONResponse unsubscribeToGroup(@PathVariable String userid, @PathVariable String clusterId) throws SQLException {
        JSONResponse response = new JSONResponse();
        response.setMessages("Successfully unsubscribed to group!");
        for (String cluster: clusterId.split(",")) {
            response.setSuccess(JdbcCgaDao.delEnodeBGroupSubscription(jdbcDao, userid, cluster));
        }
        return response;
    }


    @RequestMapping(value = "/subscriptions/{subid}", method = RequestMethod.GET)
    public @ResponseBody
    List getSubscriptionByUser(@PathVariable String subid) {

        return JdbcCgaDao.getMyEnodeBGroupSubs(jdbcDao, subid);
    }

    @RequestMapping(value = "/subscriptions/{userid}/public", method = RequestMethod.GET)
    public @ResponseBody
    List getAllPublicSubscriptions(@PathVariable String userid) {

        return JdbcCgaDao.getAllPublicEnodeBGroups(jdbcDao, userid);
    }

    @RequestMapping(value = "/clusters/save", method = RequestMethod.POST)
    public @ResponseBody
    JSONResponse saveCellGroup(@RequestBody CellGroup form) {
        logger.info("form" + form.toString());
        JSONResponse response = new JSONResponse();
        boolean createMode = GeneralUtility.isNonEmpty(form.getGroupId()) && form.getGroupId().equals("-1");
        boolean result = false;

        if (createMode && GeneralUtility.isEmpty(form.getGroupNewName())) {
            response.setMessages("Group name can't be empty");
            response.setSuccess(false);
        }

        if(form!=null && form.geteNodeBList()==null || form.geteNodeBList().size()==0) {
        	return response;
        }
        try {
            // Add new cell group
            if (createMode) {
                response.setMessages("Cell group " + form.getGroupNewName() + " already exists!");
                result = JdbcCgaDao.addEnodeBGroup(jdbcDao, form.getUserName(), form.getGroupNewName(), form.geteNodeBList());

                // Update existing cell group
            } else {
                response.setMessages("Unable to update cell group!");
                result = JdbcCgaDao.updateEnodeBGroup(jdbcDao, form.getGroupId(), form.getGroupNewName(), form.geteNodeBList());
            }

        } catch (Exception ex) {
            response.setMessages(ex.getMessage());
        } finally {
            response.setSuccess(result);
            response.setId(form.getGroupId());
            if (result)
                response.setMessages("Successfully " + (createMode ? "added" : "updated") + " cell group!");
        }

        return response;
    }


    @RequestMapping(value = "/uploadFile", method = {RequestMethod.POST})
    public @ResponseBody
    ArrayList<EnodeB> upload(@RequestParam("filename") MultipartFile file) {
        HashMap<String, String> hm = new HashMap<>();
        ArrayList<Integer> gnodeIds = new ArrayList<>(); //NTSCA-1609
        ArrayList<EnodeB> finalEnodeB = new ArrayList<EnodeB>();

        try {
            CSVParser records = CSVFormat.RFC4180.withDelimiter(',').parse(new InputStreamReader(file.getInputStream()));
            for (CSVRecord record : records) {
                if(GeneralUtility.isValidIntValue(record.get(0))){
                    StringBuffer sb = new StringBuffer();
                    if (record.size() > 1) {
                        for (int i = 1; i < record.size(); i++) {
                            sb.append(record.get(i) + ",");
                        }
                    }
                    hm.put(record.get(0), sb.toString());
                    gnodeIds.add(GeneralUtility.getIntValue(record.get(0)));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayList<EnodeB> gNodeBs = db.location.JdbcEnodeBDao.findEnodeBsByEnodebId(jdbcDao, gnodeIds);
        for(EnodeB gnodeb : gNodeBs){
            if(hm.get(gnodeb.getEnodeBId()).length()>0){
                gnodeb.setHigherEutrancells(hm.get(gnodeb.getEnodeBId()));
            }

            finalEnodeB.add(gnodeb);
        }
        return finalEnodeB;
    }
}
