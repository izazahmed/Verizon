package com.vzw.ns.controllers;

import java.util.ArrayList;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.vzw.ns.models.auth.User;
import com.vzw.ns.security.LoginResponse;
import com.vzw.ns.security.LoginValidate;
import com.vzw.ns.util.JWTUtility;

import bus.login.model.WebserverDetailsModel;
import db.JdbcDao;
import db.login.JdbcUserLTEDAO;
import db.login.JdbcWebServerDetailsDAO;
import org.vzw.lte.util.EnvironmentUtil;

@RestController
@CrossOrigin
public class LoginController {

	public static Logger logger = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	JdbcDao jdbcDao;
	
	
	@CrossOrigin
	@PostMapping("/login")
	public String authenticateUser(@Valid @RequestBody User user) {
		JsonObject userObject = new JsonObject();
		// jj added passing the jdbcDao object as 3rd arg so can use better LDAP pattern in that method.
		LoginResponse loginResponse = LoginValidate.authenticate(user.getUserName(), user.getPassword(), this.jdbcDao);

		userObject.addProperty("user", user.getUserName());
		if (loginResponse.loginSucceeded()) {
			String jwt = JWTUtility.createJWT(user.getUserName());
			userObject.addProperty("token", jwt);
			userObject.addProperty("success", true);
			logger.info("Login succeeded for {} ", user.getUserName());
			logger.info("Login message: {} ",loginResponse.getMessage()); // want to put in the log how they logged in - LDAP or POWER user.
			String type =JdbcUserLTEDAO.getUserAccessLevel(this.jdbcDao,user.getUserName());
			if(type !=null) {
				type = type.equalsIgnoreCase("admin")?"1":"0";
			}
			userObject.addProperty("userType", type);
			return userObject.toString();
		} else {
			logger.info("Login failed for {} ", user.getUserName());
			logger.info("Login message: {} ",loginResponse.getMessage()); // want to put in the log how they logged in - LDAP or POWER user.
			userObject.addProperty("token", "");
			userObject.addProperty("success", false);
		}
		return userObject.toString();
	}
	
	@GetMapping(path = "/list/webservers", produces = MediaType.APPLICATION_JSON_VALUE)
	public  ArrayList<WebserverDetailsModel> getListOfWebServerDetailModels(){
		ArrayList<WebserverDetailsModel> list = new ArrayList<WebserverDetailsModel>();
		list = JdbcWebServerDetailsDAO.getListOfWebServerDetailModels(this.jdbcDao);

		//call method to initialize variables to display banner message
		EnvironmentUtil.displayBanner(this.jdbcDao);

		return list;
	}
}
