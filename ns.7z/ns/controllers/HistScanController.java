package com.vzw.ns.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.GeneralUtility;
import org.vzw.lte.util.GlobalConstants;

import com.vzw.ns.config.RedisALPTRepository;
import com.vzw.ns.models.auth.User;
import com.vzw.ns.ui.models.HistScanEnodBForm;
import com.vzw.ns.ui.models.HistScanForm;

import bus.ListItem;
import bus.location.EnodeB;
import bus.scan.HistScanAlteEnodebPerfModel;
import bus.scan.HistScanAlteRssiDeltaModel;
import bus.scan.HistScanAlteULNoiseModel;
import bus.scan.HistScanRadioIntfModel;
import bus.scan.HistScanThruModel;
import bus.scan.HistScanTrendDataModel;
import db.JdbcDao;
import db.location.JdbcEnodeBDao;
import db.scan.JdbcScanDAO;
import util.scan.ScanConstants;

@RestController
@RequestMapping("/pt/histscan")
public class HistScanController {

	protected static Log logger = LogFactory.getLog(HistScanController.class);

	@Autowired
	User iUser;

	@Autowired
	JdbcDao jdbcDao;

	@Autowired
	private RedisALPTRepository iRedisALPTRepository;// user later

	private static final String CHART_TYPE_ENODEBPERF = "enodebperf_charts";
	private static final String CHART_TYPE_ALTE_HEATMAP_UL_NOISE = "alte_ul_noise_heatmap_charts";
	private static final String CHART_TYPE_ALTE_RSSI_DELTA = "alte_rssi_delta_charts";
	private static final String CHART_TYPE_THRU = "thru_charts";
	private static final String CHART_TYPE_ELTE_RADIO_INTERFERENCE = "radio_charts";
	private static final String CHART_TYPE_ELTE_HEATMAP_RADIO_INT = "radio_heatmap_charts";
	private List<String> iListofEnodeBIds = new ArrayList<>();
	private ArrayList<HistScanAlteEnodebPerfModel> iListOfHistScanTrendModelsForSwitch = null;
	private ArrayList<HistScanAlteULNoiseModel> iListOfHistScanRadioIntfModels = null;
	private ArrayList<HistScanAlteRssiDeltaModel> iListOfHistScanAlteRssiDeltaModels = null;
	private ArrayList<HistScanTrendDataModel> ilistOfHistScanTrendModelsForSwitch;
	private ArrayList<HistScanThruModel> ilistOfHistScanThruModels;
	private ArrayList<HistScanRadioIntfModel> ilistOfHistScanRadioIntfModels;
	private ArrayList<HistScanRadioIntfModel> ilistOfHistScanRadioIntfHetMapModels;
	private ArrayList iListOfMarketsAndEnodeBGroups = null;
	// private ArrayList<HistScanAlteEnodebPerfModel>
	// iGetListOfHistScanAlteEnodebPerfModels = null;
	private List<EnodeB> iListEnobs = null;
	private ArrayList<String> iListOfHistScanAlteRssiDeltaAlarmsALPT = null;

	@GetMapping(path = "/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<HistScanForm> getHistScans() {

		HistScanEnodBForm mHistScanEnodBForm = new HistScanEnodBForm();
		List<HistScanEnodBForm> mHistScanEnodBFormList = new ArrayList<>();
		List<ListItem> mList = getMarketsAndEnodeBGroupsForUser(iUser.getUserName());
		for (int i = 0; i < mList.size(); i++) {
			ListItem mListItems = mList.get(i);
			mHistScanEnodBForm = new HistScanEnodBForm();
			mHistScanEnodBForm.setType(mListItems.getType());
			mHistScanEnodBForm.setName(mListItems.getName());
			mHistScanEnodBForm.setIid(mListItems.getId());
			mHistScanEnodBFormList.add(mHistScanEnodBForm);
		}

		HistScanForm mHistScanForm = new HistScanForm();
		mHistScanForm.setScanList(mHistScanEnodBFormList);

		mHistScanForm = createCellAlarm(mHistScanForm);
		mHistScanForm = createTypes(mHistScanForm);

		return new ResponseEntity<HistScanForm>(mHistScanForm, HttpStatus.OK);

	}

	@Cacheable(value = "getMarketsAndEnodeBGroupsForUser", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private List getMarketsAndEnodeBGroupsForUser(String userName) {
		return JdbcScanDAO.getMarketsAndEnodeBGroupsForUser(jdbcDao, userName);
	}

	private HistScanForm createTypes(HistScanForm mHistScanForm) {
		// TODO Auto-generated method stub
		Map<String, String> mMap = new HashMap<>();
		mMap.put("scan_eNodeB_zscore_2_4", "Z-Score>=2");
		mMap.put("scan_eNodeB_zscore_0_2", "Z-Score>1 and <2");
		mMap.put("all", "All");
		mHistScanForm.setTypes(mMap);
		return mHistScanForm;
	}

	private HistScanForm createCellAlarm(HistScanForm mHistScanForm) {
		// TODO Auto-generated method stub
		Map<String, String> mMap = new HashMap<>();
		mMap.put("enodebperf_charts", "EnodeB Perf");
		mMap.put("alte_ul_noise_heatmap_charts", "UL Noise Heat Map");
		mMap.put("alte_rssi_delta_charts", "RSSI_Delta");
		mHistScanForm.setCellAlarmType(mMap);
		return mHistScanForm;
	}

	@Cacheable(value = "getAllEnodeBsRssiDeltaALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	@GetMapping(path = "/alte_rssi_delta_charts/{marketId}/{daysOfTrend}", produces = MediaType.APPLICATION_JSON_VALUE)
	public HistScanForm getAllEnodeBsRssiDeltaALPT(@PathVariable String marketId, @PathVariable String daysOfTrend,
			@RequestParam(value = "selAlteULNoiseDbRange", required = true) String selAlteULNoiseDbRange,
			@RequestParam(value = "selAlteULNoiseAlarm", required = true) String selAlteULNoiseAlarm,
			@RequestParam(value = "chkRssiOnlyAlarmCells", required = true) String chkRssiOnlyAlarmCells,
			@RequestParam(value = "txtRxAvgDeltaAlarm", required = true) String txtRxAvgDeltaAlarm) {
		HistScanForm mHistScanForm = new HistScanForm();
		mHistScanForm.setDaysOfTrend(daysOfTrend);
		mHistScanForm.setTypeOfChart(CHART_TYPE_ALTE_RSSI_DELTA);
		mHistScanForm.setSelAlteULNoiseDbRange(selAlteULNoiseDbRange);
		mHistScanForm.setSelAlteULNoiseAlarm(selAlteULNoiseAlarm);
		mHistScanForm.setChkRssiOnlyAlarmCells(chkRssiOnlyAlarmCells);
		mHistScanForm.setRxavgDelAlarm(txtRxAvgDeltaAlarm);
		mHistScanForm.setListOfMarketsAndEnodeBGroups(loadMarketsAndEnodeBGroups(iUser.getUserName()));
		populateEnodeBsByEnodeBOrMarketGroupId(marketId, mHistScanForm);
		createListOfEnodeBs(mHistScanForm);
		mHistScanForm = loadListOfModelsForChart(mHistScanForm);
		mHistScanForm = setTypeOfChartsToDisplay(mHistScanForm);
		mHistScanForm = setAddAttrForCharts(mHistScanForm);
		// logger.info("getAllEnodeBsRssiDelta->getListOfCreateRssiDeltaModels->"+mHistScanForm.getListOfCreateRssiDeltaModels()!=null?mHistScanForm.getListOfCreateRssiDeltaModels().size():null);
		return mHistScanForm;// new ResponseEntity<HistScanForm>(mHistScanForm, HttpStatus.OK);
	}

	@Cacheable(value = "getAllEnodeBsNoiseHeatMapALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	@GetMapping(path = "/alte_ul_noise_heatmap_charts/{marketIid}/{daysOfTrend}", produces = MediaType.APPLICATION_JSON_VALUE)
	public HistScanForm getAllEnodeBsNoiseHeatMapALPT(@PathVariable String marketIid, @PathVariable String daysOfTrend,
			@RequestParam(value = "selAlteULNoiseDbRange", required = true) String selAlteULNoiseDbRange,
			@RequestParam(value = "selAlteULNoiseAlarm", required = true) String selAlteULNoiseAlarm) {
		HistScanForm mHistScanForm = new HistScanForm();
		mHistScanForm.setDaysOfTrend(daysOfTrend);
		mHistScanForm.setTypeOfChart(CHART_TYPE_ALTE_HEATMAP_UL_NOISE);
		mHistScanForm.setSelAlteULNoiseDbRange(selAlteULNoiseDbRange);
		mHistScanForm.setSelAlteULNoiseAlarm(selAlteULNoiseAlarm);
		mHistScanForm.setListOfMarketsAndEnodeBGroups(loadMarketsAndEnodeBGroups(iUser.getUserName()));
		populateEnodeBsByEnodeBOrMarketGroupId(marketIid, mHistScanForm);
		createListOfEnodeBs(mHistScanForm);
		mHistScanForm = loadListOfModelsForChart(mHistScanForm);
		mHistScanForm = setTypeOfChartsToDisplay(mHistScanForm);
		mHistScanForm = setAddAttrForCharts(mHistScanForm);
		// logger.info("getAllEnodeBsNoiseHeatMap->getListOfCreateULNoiseModels->"+mHistScanForm.getListOfCreateULNoiseModels()!=null?mHistScanForm.getListOfCreateULNoiseModels().size():null);

		return mHistScanForm;// new ResponseEntity<HistScanForm>(mHistScanForm, HttpStatus.OK);
	}

	@Cacheable(value = "getAllEnodeBsPerfALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	@GetMapping(path = "/enodebperf_charts/{marketIid}/{daysOfTrend}", produces = MediaType.APPLICATION_JSON_VALUE)
	public HistScanForm getAllEnodeBsPerfALPT(@PathVariable String marketIid, @PathVariable String daysOfTrend,
			@RequestParam(value = "typeOfEnodeBCells", required = true) String typeOfEnodeBCells) {
		HistScanForm mHistScanForm = new HistScanForm();
		mHistScanForm.setDaysOfTrend(daysOfTrend);
		mHistScanForm.setTypeOfChart(CHART_TYPE_ENODEBPERF);
		mHistScanForm.setTypeOfEnodeBCells(typeOfEnodeBCells);
		mHistScanForm.setListOfMarketsAndEnodeBGroups(loadMarketsAndEnodeBGroups(iUser.getUserName()));
		populateEnodeBsByEnodeBOrMarketGroupId(marketIid, mHistScanForm);
		createListOfEnodeBs(mHistScanForm);
		mHistScanForm = loadListOfModelsForChart(mHistScanForm);
		mHistScanForm = setTypeOfChartsToDisplay(mHistScanForm);
		mHistScanForm = setAddAttrForCharts(mHistScanForm);
		// logger.info("getAllEnodeBsenodebperf_charts->getListofCreateEnodebPerfCharts->"+mHistScanForm.getListofCreateEnodebPerfCharts()!=null?mHistScanForm.getListofCreateEnodebPerfCharts().size():null);

		return mHistScanForm;// new ResponseEntity<HistScanForm>(mHistScanForm, HttpStatus.OK);
	}

	@Cacheable(value = "populateEnodeBsByEnodeBOrMarketGroupId", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private void populateEnodeBsByEnodeBOrMarketGroupId(String marketId, HistScanForm mHistScanForm) {
		List<EnodeB> mListEnobs;
		if (marketId.startsWith("C")) {
			String temp = marketId;
			temp = temp.replace("C", "");
			mListEnobs = JdbcEnodeBDao.populateEnodeBsByEnodeBGroupId(jdbcDao, temp, JdbcEnodeBDao.ORD_BY_ENODEB_ID);
			mHistScanForm.setCg(true);
		} else {
			mListEnobs = JdbcEnodeBDao.populateEnodeBsByMarket(jdbcDao, marketId, JdbcEnodeBDao.ORD_BY_ENODEB_ID);
			mHistScanForm.setCg(false);
		}
		mHistScanForm.setListOfEnodeBModels(mListEnobs);
		if (mListEnobs != null && mListEnobs.size() > 0) {
			mHistScanForm.setDbId(mListEnobs.get(0).getSchemaIid() + "");// db id
		}
	}
	
	    @Cacheable(value = "getAllEnodeBsELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
		@GetMapping(path = "/enodebperf_charts/{marketId}/{daysOfTrend}/{typeOfEnodeBCells}", produces = MediaType.APPLICATION_JSON_VALUE)
		public HistScanForm getAllEnodeBsELPT(@PathVariable String marketId, @PathVariable String daysOfTrend,
				@PathVariable String typeOfEnodeBCells) {
			HistScanForm mHistScanForm = new HistScanForm();
			mHistScanForm.setDaysOfTrend(daysOfTrend);
			mHistScanForm.setTypeOfChart(CHART_TYPE_ENODEBPERF);
			mHistScanForm.setTypeOfEnodeBCells(typeOfEnodeBCells);
			mHistScanForm.setListOfMarketsAndEnodeBGroups(loadMarketsAndEnodeBGroups(iUser.getUserName()));
			populateEnodeBsByEnodeBOrMarketGroupId(marketId, mHistScanForm);
			createListOfEnodeBs(mHistScanForm);
			mHistScanForm = loadListOfModelsForChart(mHistScanForm);
			mHistScanForm = setTypeOfChartsToDisplay(mHistScanForm);
			mHistScanForm = setAddAttrForCharts(mHistScanForm);
			// mHistScanForm.setzScoreList(null);
			return mHistScanForm;// new ResponseEntity<HistScanForm>(mHistScanForm, HttpStatus.OK);
		}
		
		@Cacheable(value = "getAllEnodeBsThruchartsELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
		@GetMapping(path = "/thru_charts/{marketId}/{daysOfTrend}", produces = MediaType.APPLICATION_JSON_VALUE)
		public HistScanForm getAllEnodeBsThruchartsELPT(@PathVariable String marketId, @PathVariable String daysOfTrend) {
			List<EnodeB> mListEnobs = null;
			HistScanForm mHistScanForm = new HistScanForm();
			mHistScanForm.setDaysOfTrend(daysOfTrend);
			mHistScanForm.setTypeOfChart(CHART_TYPE_THRU);
			mHistScanForm.setListOfMarketsAndEnodeBGroups(loadMarketsAndEnodeBGroups(iUser.getUserName()));
			populateEnodeBsByEnodeBOrMarketGroupId(marketId, mHistScanForm);
			createListOfEnodeBs(mHistScanForm);
			mHistScanForm = loadListOfModelsForChart(mHistScanForm);
			mHistScanForm = setTypeOfChartsToDisplay(mHistScanForm);
			mHistScanForm = setAddAttrForCharts(mHistScanForm);
			return mHistScanForm;// new ResponseEntity<HistScanForm>(mHistScanForm, HttpStatus.OK);
		}
		
		@Cacheable(value = "getAllEnodeBsRadiochartsELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
		@GetMapping(path = "/radio_charts/{marketId}/{daysOfTrend}/{selRadioIntSecAbvNegAlarm}/{selRadioIntAlarm}", produces = MediaType.APPLICATION_JSON_VALUE)
		public HistScanForm getAllEnodeBsRadiochartsELPT(@PathVariable String marketId, @PathVariable String daysOfTrend,
				@PathVariable String selRadioIntSecAbvNegAlarm, @PathVariable String selRadioIntAlarm) {
			HistScanForm mHistScanForm = new HistScanForm();
			mHistScanForm.setDaysOfTrend(daysOfTrend);
			mHistScanForm.setTypeOfChart(CHART_TYPE_ELTE_RADIO_INTERFERENCE);
			mHistScanForm.setSelRadioIntSecAbvNegAlarm(selRadioIntSecAbvNegAlarm);
			mHistScanForm.setSelRadioIntAlarm(selRadioIntAlarm);
			mHistScanForm.setListOfMarketsAndEnodeBGroups(loadMarketsAndEnodeBGroups(iUser.getUserName()));
			populateEnodeBsByEnodeBOrMarketGroupId(marketId, mHistScanForm);
			createListOfEnodeBs(mHistScanForm);
			mHistScanForm = loadListOfModelsForChart(mHistScanForm);
			mHistScanForm = setTypeOfChartsToDisplay(mHistScanForm);
			mHistScanForm = setAddAttrForCharts(mHistScanForm);
			return mHistScanForm;// new ResponseEntity<HistScanForm>(mHistScanForm, HttpStatus.OK);
		}

		@Cacheable(value = "getAllEnodeBsRadioHeatmapChartsELPT",keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
		@GetMapping(path = "/radio_heatmap_charts/{marketId}/{daysOfTrend}/{selRadioIntSecAbvNegAlarm}/{selRadioIntAlarm}", produces = MediaType.APPLICATION_JSON_VALUE)
		public HistScanForm getAllEnodeBsRadioHeatmapChartsELPT(@PathVariable String marketId,
				@PathVariable String daysOfTrend, @PathVariable String selRadioIntSecAbvNegAlarm,
				@PathVariable String selRadioIntAlarm) {
			HistScanForm mHistScanForm = new HistScanForm();
			mHistScanForm.setDaysOfTrend(daysOfTrend);
			mHistScanForm.setTypeOfChart(CHART_TYPE_ELTE_HEATMAP_RADIO_INT);
			mHistScanForm.setSelRadioIntSecAbvNegAlarm(selRadioIntSecAbvNegAlarm);
			mHistScanForm.setSelRadioIntAlarm(selRadioIntAlarm);
			mHistScanForm.setListOfMarketsAndEnodeBGroups(loadMarketsAndEnodeBGroups(iUser.getUserName()));
			populateEnodeBsByEnodeBOrMarketGroupId(marketId, mHistScanForm);
			createListOfEnodeBs(mHistScanForm);
			mHistScanForm = loadListOfModelsForChart(mHistScanForm);
			mHistScanForm = setTypeOfChartsToDisplay(mHistScanForm);
			mHistScanForm = setAddAttrForCharts(mHistScanForm);
			return mHistScanForm;// new ResponseEntity<HistScanForm>(mHistScanForm, HttpStatus.OK);
		}

	@GetMapping(path = "/charts/{typeOfChart}/{enodeB}/{marketId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<HistScanForm> getAllNextEnodeBs(@PathVariable String typeOfChart,
			@PathVariable String marketId, @PathVariable String enodeB,
			@RequestParam(value = "dbId", required = true) String dbId,
			@RequestParam(value = "daysOfTrend", required = true) String daysOfTrend,
			@RequestParam(value = "eutrancell", required = true) String eutrancell,
			@RequestParam(value = "selAlteULNoiseDbRange", required = false) String selAlteULNoiseDbRange,
			@RequestParam(value = "selAlteULNoiseAlarm", required = false) String selAlteULNoiseAlarm,
			@RequestParam(value = "txtRxAvgDeltaAlarm", required = false) String txtRxAvgDeltaAlarm) {
		ArrayList<HistScanAlteEnodebPerfModel> listOfHistScanTrendModelsForSwitch = new ArrayList<HistScanAlteEnodebPerfModel>();
		ArrayList<String> listOfMarketIds = new ArrayList<>();// mapOfMarketsWithDbIdAsKey.get(mHistScanForm.getDbId());
		ArrayList<String> listOfBTSVals = new ArrayList<>();
		ArrayList<HistScanAlteRssiDeltaModel> listOfHistScanAlteRssiDeltaModels = new ArrayList<>();
		ArrayList<HistScanAlteULNoiseModel> listOfHistScanULNoiseModels = new ArrayList<>();
		ArrayList<HistScanTrendDataModel> listOfHistScanTrendModelsForSwitchELPT = new ArrayList<HistScanTrendDataModel>();
		ArrayList<HistScanThruModel> listOfHistScanThruModels = new ArrayList<>();
		ArrayList<HistScanRadioIntfModel> listOfHistScanRadioIntfModels = new ArrayList<>();
		logger.info("getAllNextEnodeBs->" + enodeB);
		HistScanForm mHistScanForm = new HistScanForm();
		mHistScanForm.setTypeOfChart(typeOfChart);
		mHistScanForm.setDbId(dbId);
		mHistScanForm.setDaysOfTrend(daysOfTrend);
		listOfMarketIds.add(marketId);
		listOfBTSVals.add(enodeB);
		mHistScanForm.setSelAlteULNoiseAlarm(selAlteULNoiseAlarm);
		mHistScanForm.setSelAlteULNoiseDbRange(selAlteULNoiseDbRange);

		switch (mHistScanForm.getTypeOfChart()) {
		case CHART_TYPE_ENODEBPERF:
			if(EnvironmentUtil.isAppIdAlte()) {
				ArrayList<HistScanAlteEnodebPerfModel> mlistOfHistScanTrendModelsForSwitch = cachingListOfHistScanTrendModelsForSwitchALPT(
						mHistScanForm.getDbId(), daysOfTrend);
				if (mlistOfHistScanTrendModelsForSwitch != null)
					listOfHistScanTrendModelsForSwitch.addAll(mlistOfHistScanTrendModelsForSwitch.stream()
							.filter(e -> e.getEnodeb().equals(enodeB) && e.getEutrancell().equals(eutrancell))
							.collect(Collectors.toList()));
				mHistScanForm.setListofCreateEnodebPerfCharts(listOfHistScanTrendModelsForSwitch);
			}else if(EnvironmentUtil.isAppIdElte()) {
				
				ArrayList<HistScanTrendDataModel> mHistScanAlteEnodebPerfModellist = cachingListOfHistScanTrendModelsForSwitchELPT(
						mHistScanForm.getDbId(), daysOfTrend);
				if (mHistScanAlteEnodebPerfModellist != null) {
					listOfHistScanTrendModelsForSwitchELPT.addAll(mHistScanAlteEnodebPerfModellist.stream()
							.filter(e -> e.getEnodeb().equals(enodeB) && e.getEutrancell().equals(eutrancell))
							.collect(Collectors.toList()));
				}
				mHistScanForm.setListofCreateEnodebPerfCharts(listOfHistScanTrendModelsForSwitchELPT);
			}
			
			break;

		case CHART_TYPE_ALTE_HEATMAP_UL_NOISE:
			ArrayList<HistScanAlteULNoiseModel> mlistOfHistScanULNoiseModels = cachinglistOfHistScanRadioIntfModelsALPT(
					dbId, daysOfTrend);
			if (mlistOfHistScanULNoiseModels != null)
				listOfHistScanULNoiseModels.addAll(mlistOfHistScanULNoiseModels.stream()
						.filter(e -> e.getEnodeb().equals(enodeB) && e.getEutrancell().equals(eutrancell))
						.collect(Collectors.toList()));

			setListOfModelsForCell(listOfHistScanULNoiseModels, listOfBTSVals, mHistScanForm);
			break;

		case CHART_TYPE_ALTE_RSSI_DELTA:
			double mRxAvgDeltaAlarm = GeneralUtility.getDoubleValue((String) txtRxAvgDeltaAlarm);
			ArrayList<HistScanAlteRssiDeltaModel> mHistScanAlteRssiDeltaModel = cachingListOfHistScanAlteRssiDeltaModelsALPT(
					dbId, daysOfTrend, mRxAvgDeltaAlarm + "");
			if (mHistScanAlteRssiDeltaModel != null)
				listOfHistScanAlteRssiDeltaModels.addAll(mHistScanAlteRssiDeltaModel.stream()
						.filter(e -> e.getEnodeb().equals(enodeB) && e.getEutrancell().equals(eutrancell))
						.collect(Collectors.toList()));

			mHistScanForm.setListOfCreateRssiDeltaModels(listOfHistScanAlteRssiDeltaModels);
			break;

		case CHART_TYPE_THRU:
			ArrayList<HistScanThruModel> mlistOfHistScanThruModels = cachingListOfHistScanThruModelsELPT(dbId,
					daysOfTrend);
			if (mlistOfHistScanThruModels != null)
				listOfHistScanThruModels.addAll(mlistOfHistScanThruModels.stream()
						.filter(e -> e.getEnodeb().equals(enodeB) && e.getEutrancell().equals(eutrancell))
						.collect(Collectors.toList()));
			mHistScanForm.setListOfHistScanThruModels(listOfHistScanThruModels);
			break;

		case CHART_TYPE_ELTE_RADIO_INTERFERENCE:

			// cachingListOfHistScanRadioIntfModelsELPT
			ArrayList<HistScanRadioIntfModel> mlistOfHistScanRadioIntfModels = cachingListOfHistScanRadioIntfModelsELPT(
					dbId, daysOfTrend);
			if (mlistOfHistScanRadioIntfModels != null)
				listOfHistScanRadioIntfModels.addAll(mlistOfHistScanRadioIntfModels.stream()
						.filter(e -> e.getEnodeb().equals(enodeB) && e.getEutrancell().equals(eutrancell))
						.collect(Collectors.toList()));
			mHistScanForm.setListOfHistScanRadioIntfModels(listOfHistScanRadioIntfModels);
			break;

		case CHART_TYPE_ELTE_HEATMAP_RADIO_INT:
			ArrayList<HistScanRadioIntfModel> mlistOfHistScanRadioIntHeatMapfModels = cachingListOfHistScanRadioIntfModelsHMELPT(
					dbId, daysOfTrend);
			if (mlistOfHistScanRadioIntHeatMapfModels != null)
				listOfHistScanRadioIntfModels.addAll(mlistOfHistScanRadioIntHeatMapfModels.stream()
						.filter(e -> e.getEnodeb().equals(enodeB) && e.getEutrancell().equals(eutrancell))
						.collect(Collectors.toList()));
			mHistScanForm.setListOfHistScanRadioIntfModels(listOfHistScanRadioIntfModels);
			break;

		default:
			break;
		}

		return new ResponseEntity<HistScanForm>(mHistScanForm, HttpStatus.OK);
	}

	private void createListOfEnodeBs(HistScanForm mHistScanForm) {

		iListofEnodeBIds = mHistScanForm.getListOfEnodeBModels().stream().map(EnodeB::getEnodeBId).sorted()
				.collect(Collectors.toList());

	}

	private HistScanForm setAddAttrForCharts(HistScanForm mHistScanForm) {

		String typeOfChart = mHistScanForm.getTypeOfChart();
		
		if(EnvironmentUtil.isAppIdAlte()) {
			try {
				if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ENODEBPERF)) {
					setZscoreAlarmsForAlteENodeB(mHistScanForm);
				}
			} catch (Exception excep) {
				// should never happen
				logger.debug("exception happened in setAddAttrForCharts :" + excep.getMessage());
			}
		}else {
			setAddAttrForChartsELPT(mHistScanForm);
		}
		return mHistScanForm;

	}

	private HistScanForm setAddAttrForChartsELPT(HistScanForm mHistScanForm) {

		String typeOfChart = mHistScanForm.getTypeOfChart();
		// For radio charts we need to highlight cells for which dbm > -115.
		// we have already fetched this information and it is available in session
		// attibute.
		ArrayList<String> tmpListOfAlarmRRadioEnodebs = mHistScanForm.getListOfCellsWithAlarmRadioVal();
		// mHistScanForm.setListOfCellsWithAlarmRadioVal(null);

		// For RadioIntSecAbvNeg100dbm we need to highlight cells for which dbm > 100.
		// we have already fetched this information and it is available in session
		// attibute.
		ArrayList<String> tmpListOfSecAbvNegAlarm = mHistScanForm.getListOfCellsWithSecAbvNegAlarmVal();

		try {
			if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ELTE_RADIO_INTERFERENCE)) {

				// finding common elements of both list.
				if (tmpListOfSecAbvNegAlarm != null && tmpListOfAlarmRRadioEnodebs != null) {
					ArrayList<String> tmpListOfAlarm1 = new ArrayList(tmpListOfAlarmRRadioEnodebs.size());
					ArrayList<String> tmpListOfAlarm2 = new ArrayList(tmpListOfSecAbvNegAlarm.size());
					ArrayList<String> tmpListOfAlarm = new ArrayList(tmpListOfAlarmRRadioEnodebs.size());
					Iterator iterator = tmpListOfAlarmRRadioEnodebs.iterator();
					while (iterator.hasNext()) {
						tmpListOfAlarm1.add(iterator.next().toString());
					}
					iterator = tmpListOfAlarmRRadioEnodebs.iterator();
					while (iterator.hasNext()) {
						tmpListOfAlarm.add(iterator.next().toString());
					}
					iterator = tmpListOfSecAbvNegAlarm.iterator();
					while (iterator.hasNext()) {
						tmpListOfAlarm2.add(iterator.next().toString());
					}
					tmpListOfAlarm.retainAll(tmpListOfAlarm2);
					tmpListOfAlarm1.removeAll(tmpListOfAlarm);
					tmpListOfAlarm2.removeAll(tmpListOfAlarm);
					mHistScanForm.setListOfCellsWithAlarmRadioVal(tmpListOfAlarm1);
					mHistScanForm.setListOfCellsWithSecAbvNegAlarmVal(tmpListOfAlarm2);
					mHistScanForm.setListOfRadioListOfAlarm(tmpListOfAlarm);
				}
			} else if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ENODEBPERF)) {
				setZscoreAlarmsForElteENodeB(mHistScanForm);
			} else if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ELTE_HEATMAP_RADIO_INT)) {
				if (tmpListOfSecAbvNegAlarm != null && tmpListOfAlarmRRadioEnodebs != null) {
					ArrayList<String> tmpListOfAlarm1 = new ArrayList(tmpListOfAlarmRRadioEnodebs.size());
					ArrayList<String> tmpListOfAlarm2 = new ArrayList(tmpListOfSecAbvNegAlarm.size());
					ArrayList<String> tmpListOfAlarm = new ArrayList(tmpListOfAlarmRRadioEnodebs.size());
					Iterator iterator = tmpListOfAlarmRRadioEnodebs.iterator();
					while (iterator.hasNext()) {
						tmpListOfAlarm1.add(iterator.next().toString());
					}
					iterator = tmpListOfAlarmRRadioEnodebs.iterator();
					while (iterator.hasNext()) {
						tmpListOfAlarm.add(iterator.next().toString());
					}
					iterator = tmpListOfSecAbvNegAlarm.iterator();
					while (iterator.hasNext()) {
						tmpListOfAlarm2.add(iterator.next().toString());
					}
					tmpListOfAlarm.retainAll(tmpListOfAlarm2);
					tmpListOfAlarm1.removeAll(tmpListOfAlarm);
					tmpListOfAlarm2.removeAll(tmpListOfAlarm);
					mHistScanForm.setListOfCellsWithAlarmRadioVal(tmpListOfAlarm1);// scan_radio_list_of__elte_heatmap
					mHistScanForm.setListOfCellsWithSecAbvNegAlarmVal(tmpListOfAlarm2);// scan_radio_list_of_elte_heatmap_sec_abv_neg
					mHistScanForm.setListOfRadioListOfAlarm(tmpListOfAlarm);// scan_radio_list_of_alarm
				}
			}
		} catch (Exception excep) {
			// should never happen
			logger.debug("exception happened in setAddAttrForCharts :" + excep.getMessage());
		}
		return mHistScanForm;

	}
	
	private void setZscoreAlarmsForElteENodeB(HistScanForm mHistScanForm) {
		ArrayList<String> listOfCellsWithZscore2_4 = new ArrayList<String>();// when Z Score is more than 2.
		ArrayList<String> listOfCellsWithZscore0_2 = new ArrayList<String>();// when Z Score between 0 and 2/

		try {
			if (mHistScanForm.getzScoreList() != null) {
				ArrayList<HistScanTrendDataModel> zScoreList = mHistScanForm.getzScoreListELPT();
				// Lets iterate through the list and build Z score alarms.
				Iterator<HistScanTrendDataModel> itr = zScoreList.iterator();
				while (itr.hasNext()) {
					HistScanTrendDataModel model = itr.next();
					if (model == null) {
						continue;
					}
					String market = model.getMarket();
					String eNodeB = model.getEnodeb();
					String dbId = model.getDbId();
					double zScoreRRCSetupFailPct = model.getZscore_rrc_setup_fail_pct();
					double zScoreContextDropPct = model.getZscore_context_drop_pct();
					double zScoreBearerDropPct = model.getZscore_bearer_drop_pct();
					boolean addTo2_4List = false;
					boolean addTo0_2List = false;

					if (zScoreRRCSetupFailPct >= 2 || zScoreContextDropPct >= 2 || zScoreBearerDropPct >= 2) {
						addTo2_4List = true;
					} else if ((zScoreRRCSetupFailPct > 1 && zScoreRRCSetupFailPct < 2)
							|| (zScoreContextDropPct > 1 && zScoreContextDropPct < 2)
							|| (zScoreBearerDropPct > 1 && zScoreBearerDropPct < 2)) {
						addTo0_2List = true;
					}
					if (GeneralUtility.isNonEmpty(dbId) && GeneralUtility.isNonEmpty(market)
							&& GeneralUtility.isNonEmpty(eNodeB)) {
						String key = dbId + GlobalConstants.HIST_SCAN_FREQ_MAP_KEY_DELIM + market
								+ GlobalConstants.HIST_SCAN_FREQ_MAP_KEY_DELIM + eNodeB;
//						logger.debug("key " + key +  " *** RRCSetupFailPct *** " +zScoreRRCSetupFailPct+ " *** ContextDropPct*** " +zScoreContextDropPct+ " *** BearerDropPct*** " +zScoreBearerDropPct);
						if (addTo2_4List) {
							if (!listOfCellsWithZscore2_4.contains(key)) {
								listOfCellsWithZscore2_4.add(key);
								if (listOfCellsWithZscore0_2.contains(key)) {
									listOfCellsWithZscore0_2.remove(key);
								}
							}
						} else if (addTo0_2List) {
							if (!listOfCellsWithZscore0_2.contains(key) && !listOfCellsWithZscore2_4.contains(key)) {
								listOfCellsWithZscore0_2.add(key);
							}
						}
					}
				}
			}
		} catch (Exception excep) {
			logger.error(excep.getMessage());
			excep.printStackTrace();
		}

		String cellTypes = mHistScanForm.getTypeOfEnodeBCells();
		List<EnodeB> itrForListOfSites = mHistScanForm.getListOfEnodeBModels();
		for (EnodeB li : itrForListOfSites) {

			if (li == null) {
				continue;
			}
			String siteIdentifier = li.getSchemaIid() + GlobalConstants.HIST_SCAN_FREQ_MAP_KEY_DELIM + li.getMarketId()
					+ GlobalConstants.HIST_SCAN_FREQ_MAP_KEY_DELIM + li.getEnodeBId();

			if (cellTypes.equalsIgnoreCase("scan_eNodeB_zscore_0_2")) {
				if (!listOfCellsWithZscore0_2.contains(siteIdentifier)) {
					itrForListOfSites.remove(siteIdentifier);
				}
			} else if (cellTypes.equalsIgnoreCase("scan_eNodeB_zscore_2_4")) {
				if (!listOfCellsWithZscore2_4.contains(siteIdentifier)) {
					itrForListOfSites.remove(siteIdentifier);
				}
			}
		}

		Map<String, List<String>> scanMap = new HashMap<>();
		scanMap.put("scan_eNodeB_zscore_2_4", listOfCellsWithZscore2_4);
		mHistScanForm.setScan_eNodeB_zscore_2_4(scanMap);

		scanMap = new HashMap<>();
		scanMap.put("scan_eNodeB_zscore_0_2", listOfCellsWithZscore0_2);
		mHistScanForm.setScan_eNodeB_zscore_0_2(scanMap);
	}

	
	private void setZscoreAlarmsForAlteENodeB(HistScanForm mHistScanForm) {
		ArrayList<String> listOfCellsWithZscore2_4 = new ArrayList<String>();// when Z Score is more than 2.
		ArrayList<String> listOfCellsWithZscore0_2 = new ArrayList<String>();// when Z Score between 0 and 2/

		try {
			if (mHistScanForm.getzScoreList() != null) {
				ArrayList<HistScanAlteEnodebPerfModel> zScoreList = mHistScanForm.getzScoreList();
				// Lets iterate through the list and build Z score alarms.
				Iterator<HistScanAlteEnodebPerfModel> itr = zScoreList.iterator();
				while (itr.hasNext()) {
					HistScanAlteEnodebPerfModel model = itr.next();
					if (model == null) {
						continue;
					}
					String market = model.getMarket();
					String eNodeB = model.getEnodeb();
					String dbId = model.getDbId();
					double zScoreRRCDropPct = model.getZscore_rrc_drop_pct();
					double zScoreRRCConnFailPct = model.getZscore_rrc_conn_fail_pct();
					boolean addTo2_4List = false;
					boolean addTo0_2List = false;

					if (zScoreRRCDropPct >= 2 || zScoreRRCConnFailPct >= 2) {
						addTo2_4List = true;
					} else if ((zScoreRRCDropPct > 1 && zScoreRRCDropPct < 2)
							|| (zScoreRRCConnFailPct > 1 && zScoreRRCConnFailPct < 2)) {
						addTo0_2List = true;
					}
					if (GeneralUtility.isNonEmpty(dbId) && GeneralUtility.isNonEmpty(market)
							&& GeneralUtility.isNonEmpty(eNodeB)) {
						String key = dbId + GlobalConstants.HIST_SCAN_FREQ_MAP_KEY_DELIM + market
								+ GlobalConstants.HIST_SCAN_FREQ_MAP_KEY_DELIM + eNodeB;
//						logger.debug("key " + key + "*** RRCDropPct *** " +zScoreRRCDropPct+ " *** RRCConnFailPct *** " +zScoreRRCConnFailPct);
						if (addTo2_4List) {
							if (!listOfCellsWithZscore2_4.contains(key)) {
								listOfCellsWithZscore2_4.add(key);
								if (listOfCellsWithZscore0_2.contains(key)) {
									listOfCellsWithZscore0_2.remove(key);
								}
							}
						} else if (addTo0_2List) {
							if (!listOfCellsWithZscore0_2.contains(key) && !listOfCellsWithZscore2_4.contains(key)) {
								listOfCellsWithZscore0_2.add(key);
							}
						}
					}
				}
			}
		} catch (Exception excep) {
			logger.error(excep.getMessage());
			excep.printStackTrace();
		}

		String cellTypes = mHistScanForm.getTypeOfEnodeBCells();
		List<EnodeB> itrForListOfSites = mHistScanForm.getListOfEnodeBModels();
		for (EnodeB li : itrForListOfSites) {

			if (li == null) {
				continue;
			}
			String siteIdentifier = li.getSchemaIid() + GlobalConstants.HIST_SCAN_FREQ_MAP_KEY_DELIM + li.getMarketId()
					+ GlobalConstants.HIST_SCAN_FREQ_MAP_KEY_DELIM + li.getEnodeBId();

			if (cellTypes.equalsIgnoreCase("scan_eNodeB_zscore_0_2")) {
				if (!listOfCellsWithZscore0_2.contains(siteIdentifier)) {
					itrForListOfSites.remove(siteIdentifier);
				}
			} else if (cellTypes.equalsIgnoreCase("scan_eNodeB_zscore_2_4")) {
				if (!listOfCellsWithZscore2_4.contains(siteIdentifier)) {
					itrForListOfSites.remove(siteIdentifier);
				}
			}
		}

		Map<String, List<String>> scanMap = new HashMap<>();
		scanMap.put("scan_eNodeB_zscore_2_4", listOfCellsWithZscore2_4);
		mHistScanForm.setScan_eNodeB_zscore_2_4(scanMap);

		scanMap = new HashMap<>();
		scanMap.put("scan_eNodeB_zscore_0_2", listOfCellsWithZscore0_2);
		mHistScanForm.setScan_eNodeB_zscore_0_2(scanMap);
	}

	@Cacheable(value = "loadMarketsAndEnodeBGroups", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList loadMarketsAndEnodeBGroups(String userId) {
		ArrayList listOfMarketsAndEnodeBGroups = new ArrayList();

		try {
			listOfMarketsAndEnodeBGroups = (ArrayList) JdbcScanDAO.getMarketsAndEnodeBGroupsForUser(jdbcDao, userId);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return listOfMarketsAndEnodeBGroups;

	}

//	@Cacheable(value = "cacheLoadMarketsAndEnodeBGroupsALPT", key = "#userId.toString() +'_cacheLoadMarketsAndEnodeBGroupsALPT'")
//	private ArrayList cacheLoadMarketsAndEnodeBGroupsALPT(String userId) {
//		// TODO Auto-generated method stub
//		return iListOfMarketsAndEnodeBGroups;
//	}

	private HistScanForm loadListOfModelsForChart(HistScanForm aHistScanForm) {

		String typeOfChart = aHistScanForm.getTypeOfChart();
		ArrayList<String> listOfDbIds = getListOfDbIdsForMarket(aHistScanForm);
		LinkedHashMap<String, ArrayList<String>> mapOfMarketsWithDbIdAsKey = getMapOfMarketsWithDbIdAsKey(
				aHistScanForm);

		// getting data from db for selected drop down value
		// getting data from db for selected drop down value
		// getting data from db for selected drop down value
		List<String> listOfBTS = iListofEnodeBIds;
		ArrayList<String> listOfBTSVals = null;
		if (aHistScanForm.isCg()) {
			listOfBTSVals = new ArrayList<>(listOfBTS);
		}

		if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ENODEBPERF) && EnvironmentUtil.AppId.equalsIgnoreCase("alte")) {

			ArrayList<HistScanAlteEnodebPerfModel> listOfHistScanTrendModelsForSwitch = new ArrayList<HistScanAlteEnodebPerfModel>();
			ArrayList<HistScanAlteEnodebPerfModel> zScoreList = new ArrayList<HistScanAlteEnodebPerfModel>();

			for (String dbId : listOfDbIds) {
				ArrayList<String> listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				listOfHistScanTrendModelsForSwitch.addAll(
						getListOfHistScanAlteEnodebPerfModelsALPT(aHistScanForm, listOfBTSVals, dbId, listOfMarketIds));
				zScoreList.addAll(getAlteListOfZScoresForENodeBALPT(listOfBTSVals, dbId, listOfMarketIds));
				LinkedHashMap<String, String> mapEnodebsHigherEutrancells = getEnodebsWithHigherEutrancellsForHistScanTrendDataModel(
						listOfHistScanTrendModelsForSwitch);
				aHistScanForm.setMapEnodebsHigherEutrancells(mapEnodebsHigherEutrancells);
				iListOfHistScanTrendModelsForSwitch = listOfHistScanTrendModelsForSwitch;
				cachingListOfHistScanTrendModelsForSwitchALPT(dbId, aHistScanForm.getDaysOfTrend());
				aHistScanForm.setzScoreList(zScoreList);
			}
		} else if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ALTE_HEATMAP_UL_NOISE)) {
			ArrayList<HistScanAlteULNoiseModel> listOfHistScanRadioIntfModels = new ArrayList<HistScanAlteULNoiseModel>();
			ArrayList<String> listOfCellsWithAlarmRadioVal = new ArrayList<String>();

			double selAlteULNoiseAlarm = ScanConstants.ALTE_UL_NOISE_ALARM_DEF;
			if (aHistScanForm.getSelAlteULNoiseAlarm() != null) {
				selAlteULNoiseAlarm = GeneralUtility.getIntValue((String) aHistScanForm.getSelAlteULNoiseAlarm());
			}

			String selAlteULNoiseDbRange = ScanConstants.ALTE_UL_NOISE_DB_RANGE_DEF;
			if (aHistScanForm.getSelAlteULNoiseDbRange() != null) {
				selAlteULNoiseDbRange = aHistScanForm.getSelAlteULNoiseDbRange();
			}

			for (String dbId : listOfDbIds) {
				ArrayList<String> listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				if (mapOfMarketsWithDbIdAsKey != null && mapOfMarketsWithDbIdAsKey.containsKey(dbId)) {
					listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				}
				listOfHistScanRadioIntfModels.addAll(
						getListOfHistScanAlteULNoiseHeatMapALPT(aHistScanForm, listOfBTSVals, dbId, listOfMarketIds));
				listOfCellsWithAlarmRadioVal.addAll(getListOfHistScanAlteULNoiseAlarmsALPT(listOfBTSVals,
						selAlteULNoiseAlarm, selAlteULNoiseDbRange, dbId, listOfMarketIds));

				LinkedHashMap<String, String> mapEnodebsHigherEutrancells = getEnodebsWithHigherEutrancellsForHistScanAlteULNoiseModel(
						listOfHistScanRadioIntfModels);
				if (mapEnodebsHigherEutrancells != null) {
					aHistScanForm.setMapEnodebsHigherEutrancells(mapEnodebsHigherEutrancells);
				}
				aHistScanForm.setListOfCellsWithAlarmRadioVal(listOfCellsWithAlarmRadioVal);
				setListOfModelsForCell(listOfHistScanRadioIntfModels, listOfBTSVals, aHistScanForm);
				iListOfHistScanRadioIntfModels = listOfHistScanRadioIntfModels;
				cachinglistOfHistScanRadioIntfModelsALPT(dbId, aHistScanForm.getDaysOfTrend());
			}

		} else if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ALTE_RSSI_DELTA)) {
			ArrayList<HistScanAlteRssiDeltaModel> listOfHistScanAlteRssiDeltaModels = new ArrayList<HistScanAlteRssiDeltaModel>();
			ArrayList<String> listOfCellsWithAlarmRadioVal = new ArrayList<String>();
			// boolean bOnlyAlarmCells = shouldGetOnlyAlarmCells(aHistScanForm);
			double rxAvgDeltaAlarm = 1.0;// txtRxAvgDeltaAlarm
			if (aHistScanForm.getRxavgDelAlarm() != null) {
				rxAvgDeltaAlarm = GeneralUtility.getDoubleValue((String) aHistScanForm.getRxavgDelAlarm());
			}
			for (String dbId : listOfDbIds) {
				ArrayList<String> listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				if (mapOfMarketsWithDbIdAsKey != null && mapOfMarketsWithDbIdAsKey.containsKey(dbId)) {
					listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				}

				listOfCellsWithAlarmRadioVal.addAll(getListOfHistScanAlteRssiDeltaAlarmsALPT(listOfBTSVals,
						rxAvgDeltaAlarm, dbId, listOfMarketIds));
				listOfHistScanAlteRssiDeltaModels.addAll(JdbcScanDAO.getListOfHistScanAlteRssiDeltaModels(jdbcDao, dbId,
						listOfMarketIds, listOfBTSVals, aHistScanForm.getDaysOfTrend()));
				LinkedHashMap<String, String> mapEnodebsHigherEutrancells = getEnodebsWithHigherEutrancellsForHistScanAlteULRssiModel(
						listOfHistScanAlteRssiDeltaModels);
				if (mapEnodebsHigherEutrancells != null) {
					aHistScanForm.setMapEnodebsHigherEutrancells(mapEnodebsHigherEutrancells);

				}

				aHistScanForm.setListOfCellsWithAlarmRadioVal(listOfCellsWithAlarmRadioVal);
			}

			iListOfHistScanAlteRssiDeltaModels = listOfHistScanAlteRssiDeltaModels;// aHistScanForm.getListOfCreateRssiDeltaModels();
			cachingListOfHistScanAlteRssiDeltaModelsALPT(aHistScanForm.getDbId(), aHistScanForm.getDaysOfTrend(),
					rxAvgDeltaAlarm + "");

		}if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ENODEBPERF)&& EnvironmentUtil.AppId.equalsIgnoreCase("elte")) {
			ArrayList<HistScanTrendDataModel> listOfHistScanTrendModelsForSwitch = new ArrayList<HistScanTrendDataModel>();
			ArrayList<HistScanTrendDataModel> zScoreList = new ArrayList<HistScanTrendDataModel>();

			for (String dbId : listOfDbIds) {
				ArrayList<String> listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				listOfHistScanTrendModelsForSwitch.addAll(
						getListOfHistScanTrendModelsForSwitchELPT(aHistScanForm, listOfBTSVals, dbId, listOfMarketIds));
				zScoreList.addAll(getElteListOfZScoresForENodeBELPT(listOfBTSVals, dbId, listOfMarketIds));
				LinkedHashMap<String, String> mapEnodebsHigherEutrancells = getEnodebsWithHigherEutrancellsForHistScanTrendDataModelELPT(
						listOfHistScanTrendModelsForSwitch);
				ilistOfHistScanTrendModelsForSwitch = listOfHistScanTrendModelsForSwitch;
				cachingListOfHistScanTrendModelsForSwitchELPT(dbId, aHistScanForm.getDaysOfTrend());
				aHistScanForm.setMapEnodebsHigherEutrancells(mapEnodebsHigherEutrancells);
				aHistScanForm.setzScoreListELPT(zScoreList);
			}
		} else if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_THRU)) {
			ArrayList<HistScanThruModel> listOfHistScanThruModels = new ArrayList<HistScanThruModel>();
			for (String dbId : listOfDbIds) {
				ArrayList<String> listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				listOfHistScanThruModels.addAll(
						getListOfHistScanThruModelsForSwitchELPT(aHistScanForm, listOfBTSVals, dbId, listOfMarketIds));
				LinkedHashMap<String, String> mapEnodebsHigherEutrancells = getEnodebsWithHigherEutrancellsForHistScanThruModel(
						listOfHistScanThruModels);
				ilistOfHistScanThruModels = listOfHistScanThruModels;
				cachingListOfHistScanThruModelsELPT(dbId, aHistScanForm.getDaysOfTrend());
				aHistScanForm.setMapEnodebsHigherEutrancells(mapEnodebsHigherEutrancells);
			}
		} else if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ELTE_RADIO_INTERFERENCE)) {
			ArrayList<HistScanRadioIntfModel> listOfHistScanRadioIntfModels = new ArrayList<HistScanRadioIntfModel>();
			ArrayList<String> listOfCellsWithAlarmRadioVal = new ArrayList<String>();

			ArrayList<String> listOfCellsWithSecAbvNegAlarmVal = new ArrayList<String>();
			double selRadioIntSecAbvNegAlarm = ScanConstants.RADIO_INT_SEC_ABV_NEG_DEF;
			if (aHistScanForm.getSelRadioIntSecAbvNegAlarm() != null) {
				selRadioIntSecAbvNegAlarm = GeneralUtility
						.getIntValue((String) aHistScanForm.getSelRadioIntSecAbvNegAlarm());
			}
			double selRadioIntAlarm = ScanConstants.RADIO_INT_ALARM_DEF;

			if (aHistScanForm.getSelRadioIntAlarm() != null) {
				selRadioIntAlarm = GeneralUtility.getIntValue((String) aHistScanForm.getSelRadioIntAlarm());
			}

			for (String dbId : listOfDbIds) {
				ArrayList<String> listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				listOfHistScanRadioIntfModels.addAll(getListOfHistScanRadioModelsForSwitchELPT1(aHistScanForm,
						listOfBTSVals, dbId, listOfMarketIds));
				listOfCellsWithAlarmRadioVal.addAll(
						getListOfEnodebWithRadioAlarmsELPT1(listOfBTSVals, selRadioIntAlarm, dbId, listOfMarketIds));
				listOfCellsWithSecAbvNegAlarmVal.addAll(getLstOfEnodebSecAbvNegRadioAlarmsELPT1(listOfBTSVals,
						selRadioIntSecAbvNegAlarm, dbId, listOfMarketIds));

				LinkedHashMap<String, String> mapEnodebsHigherEutrancells = getEnodebsWithHigherEutrancellsForHistScanRadioIntfModel(
						listOfHistScanRadioIntfModels);
				aHistScanForm.setMapEnodebsHigherEutrancells(mapEnodebsHigherEutrancells);
				aHistScanForm.setListOfCellsWithSecAbvNegAlarmVal(listOfCellsWithSecAbvNegAlarmVal);
				// aHistScanForm.setListOfHistScanRadioIntfModels(listOfHistScanRadioIntfModels);
				ilistOfHistScanRadioIntfModels = listOfHistScanRadioIntfModels;
				aHistScanForm.setListOfCellsWithAlarmRadioVal(listOfCellsWithAlarmRadioVal);
				cachingListOfHistScanRadioIntfModelsELPT(dbId, aHistScanForm.getDaysOfTrend());
			}

		} else if (typeOfChart != null && typeOfChart.equalsIgnoreCase(CHART_TYPE_ELTE_HEATMAP_RADIO_INT)) {
			ArrayList<HistScanRadioIntfModel> listOfHistScanRadioIntfModels = new ArrayList<HistScanRadioIntfModel>();
			ArrayList<String> listOfCellsWithAlarmRadioVal = new ArrayList<String>();

			ArrayList<String> listOfCellsWithSecAbvNegAlarmVal = new ArrayList<String>();
			double selRadioIntSecAbvNegAlarm = ScanConstants.RADIO_INT_SEC_ABV_NEG_DEF;
			if (aHistScanForm.getSelRadioIntSecAbvNegAlarm() != null) {
				selRadioIntSecAbvNegAlarm = GeneralUtility
						.getIntValue((String) aHistScanForm.getSelRadioIntSecAbvNegAlarm());
			}
			double selRadioIntAlarm = ScanConstants.RADIO_INT_ALARM_DEF;

			if (aHistScanForm.getSelRadioIntAlarm() != null) {
				selRadioIntAlarm = GeneralUtility.getIntValue((String) aHistScanForm.getSelRadioIntAlarm());
			}

			for (String dbId : listOfDbIds) {
				ArrayList<String> listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				if (mapOfMarketsWithDbIdAsKey != null && mapOfMarketsWithDbIdAsKey.containsKey(dbId)) {
					listOfMarketIds = mapOfMarketsWithDbIdAsKey.get(dbId);
				}
				listOfHistScanRadioIntfModels.addAll(
						getListOfHistScanRadioModelsHeatMapELPT(aHistScanForm, listOfBTSVals, dbId, listOfMarketIds));
				listOfCellsWithAlarmRadioVal.addAll(
						getListOfEnodebWithRadioAlarmsELPT(listOfBTSVals, selRadioIntAlarm, dbId, listOfMarketIds));
				listOfCellsWithSecAbvNegAlarmVal.addAll(getLstOfEnodebSecAbvNegRadioAlarmsELPT(listOfBTSVals,
						selRadioIntSecAbvNegAlarm, dbId, listOfMarketIds));

				LinkedHashMap<String, String> mapEnodebsHigherEutrancells = getEnodebsWithHigherEutrancellsForHistScanRadioIntfModel(
						listOfHistScanRadioIntfModels);

				// aHistScanForm.setListOfHistScanRadioIntfModels(listOfHistScanRadioIntfModels);
				ilistOfHistScanRadioIntfHetMapModels = listOfHistScanRadioIntfModels;
				cachingListOfHistScanRadioIntfModelsHMELPT(dbId, aHistScanForm.getDaysOfTrend());
				aHistScanForm.setListOfCellsWithAlarmRadioVal(listOfCellsWithAlarmRadioVal);
				aHistScanForm.setListOfCellsWithSecAbvNegAlarmVal(listOfCellsWithSecAbvNegAlarmVal);
				aHistScanForm.setMapEnodebsHigherEutrancells(mapEnodebsHigherEutrancells);
			}

		}

		return aHistScanForm;
	}

	///***********************ELPT Method/ CODE Start******************************//
	
	@Cacheable(value = "cachingListOfHistScanRadioIntfModelsHMELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanRadioIntfModel> cachingListOfHistScanRadioIntfModelsHMELPT(String dbId,
			String daysOfTrend) {
		// TODO Auto-generated method stub
		return ilistOfHistScanRadioIntfHetMapModels;
	}

	
	@Cacheable(value = "getLstOfEnodebSecAbvNegRadioAlarmsELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<String> getLstOfEnodebSecAbvNegRadioAlarmsELPT(ArrayList<String> listOfBTSVals,
			double selRadioIntSecAbvNegAlarm, String dbId, ArrayList<String> listOfMarketIds) {

		return JdbcScanDAO.getLstOfEnodebSecAbvNegRadioAlarms(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
				selRadioIntSecAbvNegAlarm);
	}
	
	@Cacheable(value = "getListOfEnodebWithRadioAlarmsELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<String> getListOfEnodebWithRadioAlarmsELPT(ArrayList<String> listOfBTSVals,
			double selRadioIntAlarm, String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getListOfEnodebWithRadioAlarms(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
				selRadioIntAlarm);
	}
	
	@Cacheable(value = "getListOfHistScanRadioModelsHeatMapELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanRadioIntfModel> getListOfHistScanRadioModelsHeatMapELPT(HistScanForm aHistScanForm,
			ArrayList<String> listOfBTSVals, String dbId, ArrayList<String> listOfMarketIds) {

		return JdbcScanDAO.getListOfHistScanRadioModelsHeatMap(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
				aHistScanForm.getDaysOfTrend());// JdbcScanDAO.getListOfHistScanRadioModelsHeatMap(jdbcDao,
												// dbId,listOfMarketIds, listOfBTSVals, aHistScanForm.getDaysOfTrend());
	}
	@Cacheable(value = "cachingListOfHistScanRadioIntfModelsELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanRadioIntfModel> cachingListOfHistScanRadioIntfModelsELPT(String dbId,
			String daysOfTrend) {
		// TODO Auto-generated method stub
		return ilistOfHistScanRadioIntfModels;
	}

	@Cacheable(value = "getLstOfEnodebSecAbvNegRadioAlarmsELPT1", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<String> getLstOfEnodebSecAbvNegRadioAlarmsELPT1(ArrayList<String> listOfBTSVals,
			double selRadioIntSecAbvNegAlarm, String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getLstOfEnodebSecAbvNegRadioAlarms(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
				selRadioIntSecAbvNegAlarm);
	}

	
	@Cacheable(value = "getListOfEnodebWithRadioAlarmsELPT1", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<String> getListOfEnodebWithRadioAlarmsELPT1(ArrayList<String> listOfBTSVals,
			double selRadioIntAlarm, String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getListOfEnodebWithRadioAlarms(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
				selRadioIntAlarm);
	}

	
	@Cacheable(value = "getListOfHistScanRadioModelsForSwitchELPT1", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanRadioIntfModel> getListOfHistScanRadioModelsForSwitchELPT1(HistScanForm aHistScanForm,
			ArrayList<String> listOfBTSVals, String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getListOfHistScanRadioModelsForSwitch(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
				aHistScanForm.getDaysOfTrend());

	}
	
	
	@Cacheable(value = "cachingListOfHistScanThruModelsELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanThruModel> cachingListOfHistScanThruModelsELPT(String dbId, String daysOfTrend) {
		// TODO Auto-generated method stub
		return ilistOfHistScanThruModels;
	}

	
	@Cacheable(value = "getListOfHistScanTrendModelsForSwitchELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanTrendDataModel> getListOfHistScanTrendModelsForSwitchELPT(HistScanForm aHistScanForm,
			ArrayList<String> listOfBTSVals, String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getListOfHistScanTrendModelsForSwitch(jdbcDao, dbId, listOfMarketIds,listOfBTSVals, aHistScanForm.getDaysOfTrend());

	}

	@Cacheable(value = "getElteListOfZScoresForENodeBELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanTrendDataModel> getElteListOfZScoresForENodeBELPT(ArrayList<String> listOfBTSVals,
			String dbId, ArrayList<String> listOfMarketIds) {

		return JdbcScanDAO.getElteListOfZScoresForENodeB(jdbcDao, dbId, listOfMarketIds, listOfBTSVals);
	}
	
	private LinkedHashMap<String, String> getEnodebsWithHigherEutrancellsForHistScanTrendDataModelELPT(
			ArrayList<HistScanTrendDataModel> modelList) {
		LinkedHashMap<String, Set<String>> mapEnodebsHigherEutrancells = new LinkedHashMap<String, Set<String>>();

		Iterator<HistScanTrendDataModel> itrModelList = modelList.iterator();
		while (itrModelList.hasNext()) {
			HistScanTrendDataModel model = itrModelList.next();
			if ((model.getEutrancell() != null) && (!model.getEutrancell().equals(""))
					&& isValidEutrancell(model.getEutrancell(), model.getEnodeb())
					&& (Integer.valueOf(model.getEutrancell()) > 3)) {
				Set listHigherEutrans = mapEnodebsHigherEutrancells.get(model.getEnodeb());
				if (listHigherEutrans == null) {
					listHigherEutrans = new LinkedHashSet<String>();
					mapEnodebsHigherEutrancells.put(model.getEnodeb(), listHigherEutrans);
				}
				listHigherEutrans.add(model.getEutrancell());
			}
		}

		return convertHigherEutrancellMap(mapEnodebsHigherEutrancells);
	}

	
	@Cacheable(value = "cachingListOfHistScanTrendModelsForSwitchELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanTrendDataModel> cachingListOfHistScanTrendModelsForSwitchELPT(String dbId,
			String daysOfTrend) {
		// TODO Auto-generated method stub
		return ilistOfHistScanTrendModelsForSwitch;
	}
	
	@Cacheable(value = "getListOfHistScanThruModelsForSwitchELPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanThruModel> getListOfHistScanThruModelsForSwitchELPT(HistScanForm aHistScanForm,
			ArrayList<String> listOfBTSVals, String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getListOfHistScanThruModelsForSwitch(jdbcDao, dbId, listOfMarketIds,listOfBTSVals, aHistScanForm.getDaysOfTrend());
	}

	
	///***********************ELPT Method/ CODE END******************************//
	
	
	
	@Cacheable(value = "cachingListOfHistScanAlteRssiDeltaModelsALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanAlteRssiDeltaModel> cachingListOfHistScanAlteRssiDeltaModelsALPT(String dbId,
			String daysOfTrend, String rxAvgDeltaAlarm) {
		// TODO Auto-generated method stub
		return iListOfHistScanAlteRssiDeltaModels;
	}
	
	

//	private ArrayList<HistScanAlteRssiDeltaModel> getListOfHistScanAlteRssiDeltaModelsALPT(HistScanForm aHistScanForm,
//			String dbId, ArrayList<String> listOfMarketIds, ArrayList<String> listOfBTSVals) {
//
//		return JdbcScanDAO.getListOfHistScanAlteRssiDeltaModels(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
//				aHistScanForm.getDaysOfTrend());
//	}

	@Cacheable(value = "getListOfHistScanAlteRssiDeltaAlarmsALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<String> getListOfHistScanAlteRssiDeltaAlarmsALPT(ArrayList<String> listOfBTSVals,
			double rxAvgDeltaAlarm, String dbId, ArrayList<String> listOfMarketIds) {
		iListOfHistScanAlteRssiDeltaAlarmsALPT = JdbcScanDAO.getListOfHistScanAlteRssiDeltaAlarms(jdbcDao, dbId,
				listOfMarketIds, listOfBTSVals, rxAvgDeltaAlarm);
		return iListOfHistScanAlteRssiDeltaAlarmsALPT;
	}

	@Cacheable(value = "cachedListOfHistScanAlteRssiDeltaAlarmsALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<String> cachedListOfHistScanAlteRssiDeltaAlarmsALPT(String dbId, String rxAvgDeltaAlarm) {
		// TODO Auto-generated method stub
		return iListOfHistScanAlteRssiDeltaAlarmsALPT;

	}

	@Cacheable(value = "cachinglistOfHistScanRadioIntfModelsALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanAlteULNoiseModel> cachinglistOfHistScanRadioIntfModelsALPT(String dbId,
			String daysOfTrend) {
		// TODO Auto-generated method stub
		return iListOfHistScanRadioIntfModels;

	}

	@Cacheable(value = "cachingGetListOfHistScanAlteULNoiseAlarmsALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<String> getListOfHistScanAlteULNoiseAlarmsALPT(ArrayList<String> listOfBTSVals,
			double selAlteULNoiseAlarm, String selAlteULNoiseDbRange, String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getListOfHistScanAlteULNoiseAlarms(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
				selAlteULNoiseAlarm, selAlteULNoiseDbRange);
	}

	@Cacheable(value = "getListOfHistScanAlteULNoiseHeatMapALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanAlteULNoiseModel> getListOfHistScanAlteULNoiseHeatMapALPT(HistScanForm aHistScanForm,
			ArrayList<String> listOfBTSVals, String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getListOfHistScanAlteULNoiseHeatMap(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
				aHistScanForm.getDaysOfTrend());
	}

	@Cacheable(value = "cachingListOfHistScanTrendModelsForSwitchALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanAlteEnodebPerfModel> cachingListOfHistScanTrendModelsForSwitchALPT(String dbId,
			String daysOfTrend) {
		// TODO Auto-generated method stub
		return iListOfHistScanTrendModelsForSwitch;
	}

	@Cacheable(value = "cachGetAlteListOfZScoresForENodeBALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanAlteEnodebPerfModel> getAlteListOfZScoresForENodeBALPT(ArrayList<String> listOfBTSVals,
			String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getAlteListOfZScoresForENodeB(jdbcDao, dbId, listOfMarketIds, listOfBTSVals);
	}

	@Cacheable(value = "getListOfHistScanTrendModelsForSwitchALPT", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList<HistScanAlteEnodebPerfModel> getListOfHistScanAlteEnodebPerfModelsALPT(HistScanForm aHistScanForm,
			ArrayList<String> listOfBTSVals, String dbId, ArrayList<String> listOfMarketIds) {
		return JdbcScanDAO.getListOfHistScanAlteEnodebPerfModels(jdbcDao, dbId, listOfMarketIds, listOfBTSVals,
				aHistScanForm.getDaysOfTrend());
	}

	private void setListOfModelsForCell(ArrayList<HistScanAlteULNoiseModel> listOfHistScanRadioIntfModels,
			ArrayList<String> listOfBTSVals, HistScanForm aHistScanForm) {
		ArrayList<HistScanAlteULNoiseModel> list = new ArrayList<HistScanAlteULNoiseModel>();
		if (listOfBTSVals == null) {
			aHistScanForm.setListOfCreateULNoiseModels(list);
		} else {
			for (String enodebs : listOfBTSVals) {

				list.addAll(listOfHistScanRadioIntfModels.stream().filter(a -> a.getEnodeb().equals(enodebs))
						.collect(Collectors.toList()));
			}
			aHistScanForm.setListOfCreateULNoiseModels(list);
		}
	}

	private void setListOfModelsForCellRss(ArrayList<HistScanAlteRssiDeltaModel> models,
			ArrayList<String> listOfBTSVals, HistScanForm aHistScanForm) {
		ArrayList<HistScanAlteRssiDeltaModel> list = new ArrayList<HistScanAlteRssiDeltaModel>();

		if (listOfBTSVals == null) {
			aHistScanForm.setListOfCreateRssiDeltaModels(list);
		} else {

			for (String enodebs : listOfBTSVals) {

				list.addAll(models.stream().filter(a -> a.getEnodeb().equals(enodebs)).collect(Collectors.toList()));
			}

			aHistScanForm.setListOfCreateRssiDeltaModels(list);
		}
	}

	private void removeNonAlarmSites(HistScanForm aHistScanForm, ArrayList<String> alarmSites) {
		ArrayList<EnodeB> updatedListOfEnodeBs = new ArrayList<EnodeB>();
		if (alarmSites == null || alarmSites.isEmpty()) {
			// Maybe add a message
			return;
		}

		ArrayList<String> listOfSites = null;
		if (aHistScanForm != null && aHistScanForm.getListOfEnodeBModels() != null) {
			for (EnodeB model : aHistScanForm.getListOfEnodeBModels()) {
				String enodeb = model.getEnodeBId();
				enodeb = GeneralUtility.trim(enodeb);
				if (alarmSites.contains(enodeb))
					updatedListOfEnodeBs.add(model);
			}
			aHistScanForm.setListOfEnodeBModels(updatedListOfEnodeBs);
		}
	}

	private ArrayList<String> getEnodeBsOnlyForRssiDelta(ArrayList<String> in) {
		ArrayList<String> out = new ArrayList<String>();
		if (in != null) {
			Iterator<String> itrIn = in.iterator();
			while (itrIn.hasNext()) {
				String composite = itrIn.next();
				int n = composite.lastIndexOf(GlobalConstants.HIST_SCAN_FREQ_MAP_KEY_DELIM);
				String enodeb = composite.substring(n + 1, composite.length());
				enodeb = GeneralUtility.trim(enodeb);
				out.add(enodeb);
			}
		}

		return out;
	}

	private boolean shouldGetOnlyAlarmCells(HistScanForm aHistScanForm) {
		boolean bOnlyAlarmCells = false;
		if (aHistScanForm != null && aHistScanForm.getChkRssiOnlyAlarmCells() != null) {
			String val = (String) aHistScanForm.getChkRssiOnlyAlarmCells();
			if (val.equals("true"))
				bOnlyAlarmCells = true;
		}

		return bOnlyAlarmCells;
	}

	private LinkedHashMap<String, String> getEnodebsWithHigherEutrancellsForHistScanAlteULRssiModel(
			ArrayList<HistScanAlteRssiDeltaModel> modelList) {
		LinkedHashMap<String, Set<String>> mapEnodebsHigherEutrancells = new LinkedHashMap<String, Set<String>>();
		Iterator<HistScanAlteRssiDeltaModel> itrModelList = modelList.iterator();
		while (itrModelList.hasNext()) {
			HistScanAlteRssiDeltaModel model = itrModelList.next();
			if ((model.getEutrancell() != null) && (!model.getEutrancell().equals(""))
					&& isValidEutrancell(model.getEutrancell(), model.getEnodeb())
					&& (Integer.valueOf(model.getEutrancell()) > 3)) {
				Set listHigherEutrans = mapEnodebsHigherEutrancells.get(model.getEnodeb());
				if (listHigherEutrans == null) {
					listHigherEutrans = new LinkedHashSet<String>();
					mapEnodebsHigherEutrancells.put(model.getEnodeb(), listHigherEutrans);
				}
				listHigherEutrans.add(model.getEutrancell());
			}
		}

		return convertHigherEutrancellMap(mapEnodebsHigherEutrancells);
	}

	private LinkedHashMap<String, String> getEnodebsWithHigherEutrancellsForHistScanAlteULNoiseModel(
			ArrayList<HistScanAlteULNoiseModel> modelList) {
		LinkedHashMap<String, Set<String>> mapEnodebsHigherEutrancells = new LinkedHashMap<String, Set<String>>();
		Iterator<HistScanAlteULNoiseModel> itrModelList = modelList.iterator();
		while (itrModelList.hasNext()) {
			HistScanAlteULNoiseModel model = itrModelList.next();
			if ((model.getEutrancell() != null) && (!model.getEutrancell().equals(""))
					&& isValidEutrancell(model.getEutrancell(), model.getEnodeb())
					&& (Integer.valueOf(model.getEutrancell()) > 3)) {
				Set listHigherEutrans = mapEnodebsHigherEutrancells.get(model.getEnodeb());
				if (listHigherEutrans == null) {
					listHigherEutrans = new LinkedHashSet<String>();
					mapEnodebsHigherEutrancells.put(model.getEnodeb(), listHigherEutrans);
				}
				listHigherEutrans.add(model.getEutrancell());
			}
		}

		return convertHigherEutrancellMap(mapEnodebsHigherEutrancells);
	}

	private LinkedHashMap<String, String> getEnodebsWithHigherEutrancellsForHistScanThruModel(
			ArrayList<HistScanThruModel> modelList) {
		LinkedHashMap<String, Set<String>> mapEnodebsHigherEutrancells = new LinkedHashMap<String, Set<String>>();
		Iterator<HistScanThruModel> itrModelList = modelList.iterator();
		while (itrModelList.hasNext()) {
			HistScanThruModel model = itrModelList.next();
			if ((model.getEutrancell() != null) && (!model.getEutrancell().equals(""))
					&& isValidEutrancell(model.getEutrancell(), model.getEnodeb())
					&& (Integer.valueOf(model.getEutrancell()) > 3)) {
				Set listHigherEutrans = mapEnodebsHigherEutrancells.get(model.getEnodeb());
				if (listHigherEutrans == null) {
					listHigherEutrans = new LinkedHashSet<String>();
					mapEnodebsHigherEutrancells.put(model.getEnodeb(), listHigherEutrans);
				}
				listHigherEutrans.add(model.getEutrancell());
			}
		}

		return convertHigherEutrancellMap(mapEnodebsHigherEutrancells);
	}

	private ArrayList<String> getListOfDbIdsForMarket(HistScanForm aHistScanForm) {
		ArrayList<String> listOfDbIds = new ArrayList<String>();
		if (aHistScanForm.getListOfEnodeBModels() == null || aHistScanForm.getListOfEnodeBModels().size() < 0) {
			return listOfDbIds;
		}
		for (EnodeB model : aHistScanForm.getListOfEnodeBModels()) {
			if (model == null) {
				continue;
			}
			// scheema id has already been populate for each site. Just pull the value from
			// first good model.
			listOfDbIds.add(String.valueOf(model.getSchemaIid()));
			break;
		}
		return listOfDbIds;
	}

	private LinkedHashMap<String, String> getEnodebsWithHigherEutrancellsForHistScanTrendDataModel(
			ArrayList<HistScanAlteEnodebPerfModel> modelList) {
		LinkedHashMap<String, Set<String>> mapEnodebsHigherEutrancells = new LinkedHashMap<String, Set<String>>();
		Iterator<HistScanAlteEnodebPerfModel> itrModelList = modelList.iterator();
		while (itrModelList.hasNext()) {
			HistScanAlteEnodebPerfModel model = itrModelList.next();
			if ((model.getEutrancell() != null) && (!model.getEutrancell().equals(""))
					&& isValidEutrancell(model.getEutrancell(), model.getEnodeb())
					&& (Integer.valueOf(model.getEutrancell()) > 3)) {
				Set listHigherEutrans = mapEnodebsHigherEutrancells.get(model.getEnodeb());
				if (listHigherEutrans == null) {
					listHigherEutrans = new LinkedHashSet<String>();
					mapEnodebsHigherEutrancells.put(model.getEnodeb(), listHigherEutrans);
				}
				listHigherEutrans.add(model.getEutrancell());
			}
		}

		return convertHigherEutrancellMap(mapEnodebsHigherEutrancells);
	}

	private boolean isValidEutrancell(String eutrancell, String enodeb) {
		boolean isValidEutrancell = true;
		try {
			Integer euCell = Integer.valueOf(eutrancell);
		} catch (NumberFormatException e) {
			isValidEutrancell = false;
			logger.warn("Invalid eutrancell " + eutrancell + " found for enodeb " + enodeb);
		}
		return isValidEutrancell;
	}

	private LinkedHashMap<String, String> convertHigherEutrancellMap(LinkedHashMap<String, Set<String>> origMap) {
		LinkedHashMap<String, String> convertedMap = new LinkedHashMap<String, String>();
		if (origMap != null) {
			Iterator<String> itrEnodebs = origMap.keySet().iterator();
			while (itrEnodebs.hasNext()) {
				StringBuilder sb = new StringBuilder();
				String enodeb = itrEnodebs.next();
				Set<String> setHigherEutrans = origMap.get(enodeb);
				for (String higherEutrans : origMap.get(enodeb)) {
					if (sb.length() > 0)
						sb.append(",");
					sb.append(String.valueOf(higherEutrans));
				}

				convertedMap.put(enodeb, sb.toString());
			}
		}
		return convertedMap;
	}

	private LinkedHashMap<String, ArrayList<String>> getMapOfMarketsWithDbIdAsKey(HistScanForm aHistScanForm) {
		LinkedHashMap<String, ArrayList<String>> mapOfMarketsWithDbIdAsKey = new LinkedHashMap<String, ArrayList<String>>();
		if (aHistScanForm.getListOfEnodeBModels() == null) {
			return mapOfMarketsWithDbIdAsKey;
		}
		for (EnodeB model : aHistScanForm.getListOfEnodeBModels()) {
			if (model == null) {
				continue;
			}

			String schemaIid = String.valueOf(model.getSchemaIid());

			if (mapOfMarketsWithDbIdAsKey.containsKey(schemaIid)) {
				ArrayList<String> listOfMarkets = mapOfMarketsWithDbIdAsKey.get(schemaIid);
				String marketId = model.getMarketId();
				if (!listOfMarkets.contains(marketId)) {
					listOfMarkets.add(marketId);
				}
			} else {
				ArrayList<String> listOfMarkets = new ArrayList<String>();
				listOfMarkets.add(model.getMarketId());
				mapOfMarketsWithDbIdAsKey.put(schemaIid, listOfMarkets);
			}
		}
		return mapOfMarketsWithDbIdAsKey;
	}

	private LinkedHashMap<String, String> getEnodebsWithHigherEutrancellsForHistScanRadioIntfModel(
			ArrayList<HistScanRadioIntfModel> modelList) {
		LinkedHashMap<String, Set<String>> mapEnodebsHigherEutrancells = new LinkedHashMap<String, Set<String>>();
		Iterator<HistScanRadioIntfModel> itrModelList = modelList.iterator();
		while (itrModelList.hasNext()) {
			HistScanRadioIntfModel model = itrModelList.next();
			if ((model.getEutrancell() != null) && (!model.getEutrancell().equals(""))
					&& isValidEutrancell(model.getEutrancell(), model.getEnodeb())
					&& (Integer.valueOf(model.getEutrancell()) > 3)) {
				Set listHigherEutrans = mapEnodebsHigherEutrancells.get(model.getEnodeb());
				if (listHigherEutrans == null) {
					listHigherEutrans = new LinkedHashSet<String>();
					mapEnodebsHigherEutrancells.put(model.getEnodeb(), listHigherEutrans);
				}
				listHigherEutrans.add(model.getEutrancell());
			}
		}

		return convertHigherEutrancellMap(mapEnodebsHigherEutrancells);
	}

	private HistScanForm setTypeOfChartsToDisplay(HistScanForm aHistScanForm) {

		switch (aHistScanForm.getTypeOfChart()) {

		case CHART_TYPE_ENODEBPERF:
			aHistScanForm.setShowEnodebPerfCharts(true);
			break;

		case CHART_TYPE_ALTE_HEATMAP_UL_NOISE:
			aHistScanForm.setShowAlteULNoiseHeatMapCharts(true);
			break;

		case CHART_TYPE_ALTE_RSSI_DELTA:
			aHistScanForm.setShowAlteRssiDeltaCharts(true);
			break;

		default:
			aHistScanForm.setShowEnodebPerfCharts(true);
		}
		return aHistScanForm;
	}

}
