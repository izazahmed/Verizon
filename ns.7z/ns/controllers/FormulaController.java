package com.vzw.ns.controllers;

import bus.formula.Formula;
import bus.report.Report;
import bus.tree.Folder;
import db.JdbcDao;
import db.JdbcReportLevelDao;
import db.JdbcReportTypeDao;
import db.formula.JdbcFormulaDao;
import db.report.JdbcReportDao;
import db.user.JdbcUserListDao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.vzw.lte.dao.JdbcCauseCodeDao;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.FormulaUtility;
import org.vzw.lte.util.GeneralUtility;
import org.vzw.lte.util.GlobalConstants;

import com.vzw.ns.models.auth.User;
import com.vzw.ns.ui.models.FormulaEditorForm;
import com.vzw.ns.ui.models.ReportBuilderForm;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by gundaja on 12/9/16.
 */

@RequestMapping(value = "/pt/formulas")
@RestController
public class FormulaController {
    protected final Log logger = LogFactory.getLog(this.getClass());
    public static final String FORMULA = "formula";
    public static final String FORMULA_FOLDER_CACHE_KEY = "formula-folders";
    public static final String FORMULA_USER_CACHE_KEY = "formula-user";
    public static final String FOLDERS = "folders";

    @Autowired
    private JdbcDao jdbcDao;

    
    @Autowired
	User iUser;

    @Cacheable(value = "getFormulaEditorInfo", keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
	@GetMapping(path = "/{userType}", produces = MediaType.APPLICATION_JSON_VALUE)
	public FormulaEditorForm getFormulaEditorInfo(@PathVariable String userType) {
		FormulaEditorForm mFormulaEditorForm = new FormulaEditorForm();
		mFormulaEditorForm.setUsers(JdbcUserListDao.selectUsersByType(jdbcDao, "formula"));
		mFormulaEditorForm.setAggregationTypes(GeneralUtility.getAggregationTypes());
		return mFormulaEditorForm;//new ResponseEntity<FormulaEditorForm>(mFormulaEditorForm, HttpStatus.OK);
	}

	
	
    @Cacheable(value = FORMULA_FOLDER_CACHE_KEY, keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
    @RequestMapping(value = "/folders/{userName}", method = RequestMethod.GET)
    @ResponseBody
    public List<Folder> getFoldersByUser(@PathVariable String userName) {
        return JdbcFormulaDao.getFoldersByUser(jdbcDao, userName);
    }

    @Cacheable(value = FORMULA_USER_CACHE_KEY, keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
    @RequestMapping(value = "/users/{userName}", method = RequestMethod.GET)
    @ResponseBody
    public List<Formula> getFormulasByUser(@PathVariable String userName) {
        return JdbcFormulaDao.selectFormulasByUser(jdbcDao, userName);
    }

    @RequestMapping(value = "/details/{formulaId}", method = RequestMethod.GET)
    @ResponseBody
    public Formula getFormulaDetailById(@PathVariable String formulaId) {
        return JdbcFormulaDao.selectFormulaById(jdbcDao, formulaId);
    }

    @CacheEvict(value = {FORMULA_FOLDER_CACHE_KEY,FORMULA_USER_CACHE_KEY,TreeNodeController.TREE_NODE_CACHE_KEY }, allEntries = true)
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public List create(@RequestBody Formula formula) throws Exception {
        List errorList = FormulaUtility.validateFormula(formula, true, true, true, jdbcDao);
        errorList.addAll(FormulaUtility.validateFolder(formula, jdbcDao));

        if (errorList.isEmpty()) {
            JdbcFormulaDao.insertFormula(jdbcDao, formula);
        }

        return errorList;
    }

//   @Caching(evict = {
//            @CacheEvict(value=TreeNodeController.TREE_NODE_CACHE_KEY, key="#root.target.FORMULA.toString() + '_' + #formula.userName.toString() + '_' + #formula.folderId.toString()"),
//            @CacheEvict(value=TreeNodeController.TREE_NODE_CACHE_KEY, key="#root.target.FOLDERS.toString() + '_' + #formula.userName.toString()")
//          
//    })
    @CacheEvict(value = {FORMULA_FOLDER_CACHE_KEY,FORMULA_USER_CACHE_KEY,TreeNodeController.TREE_NODE_CACHE_KEY }, allEntries = true)
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public List update(@RequestBody Formula formula) throws Exception {
        Boolean checkName = false;
        if (!formula.getFormulaName().equals(formula.getNewFormulaName())) {
            formula.setFormulaName(formula.getNewFormulaName());
            checkName = true;
        }
        List errorList = FormulaUtility.validateFormula(formula, true, true, checkName, jdbcDao);
        errorList.addAll(FormulaUtility.validateFolder(formula, jdbcDao));

        if (errorList.isEmpty()) {
            JdbcFormulaDao.updateFormula(jdbcDao, formula);
        }

        return errorList;
    }

//    @Caching(evict = {
//            @CacheEvict(value=TreeNodeController.TREE_NODE_CACHE_KEY, key="#root.target.FORMULA.toString() + '_' + #formula.userName.toString() + '_' + #formula.folderId.toString()"),
//            @CacheEvict(value=TreeNodeController.TREE_NODE_CACHE_KEY, key="#root.target.FOLDERS.toString() + '_' + #formula.userName.toString()")
//    })
    @CacheEvict(value = {FORMULA_FOLDER_CACHE_KEY,FORMULA_USER_CACHE_KEY,TreeNodeController.TREE_NODE_CACHE_KEY }, allEntries = true)
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public List delete(@RequestBody Formula formula) throws SQLException {
        JdbcFormulaDao.deleteFormula(jdbcDao, formula.getFormulaId());

        return Collections.emptyList();
    }

    @RequestMapping(value = "/aggTypes", method = RequestMethod.GET)
    @ResponseBody
    public List getAggregationType() throws SQLException {
        return GeneralUtility.getAggregationTypes();
    }
}
