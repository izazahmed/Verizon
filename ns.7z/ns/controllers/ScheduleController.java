package com.vzw.ns.controllers;

import bus.preferences.UserPreferences;
import bus.scheduler.User;
import com.vzw.ns.report.domain.Subscription;
import com.vzw.ns.report.domain.SubscriptionStatus;
import com.vzw.ns.report.jdbc.JdbcSubscriptionDao;
import com.vzw.web.cellgroups.JSONResponse;

import db.JdbcDao;
import db.preferences.JdbcUserPreferencesDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.vzw.lte.util.GlobalConstants;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gundaja on 12/9/16.
 */
@RequestMapping(value = "/pt/schedulers")
@RestController
public class ScheduleController {
    protected final Log logger = LogFactory.getLog(this.getClass());
    public final static String NEW_SUBSCRIPTION = "new";
    public final static String EDIT_SUBSCRIPTION = "edit";
    @Autowired
    private JdbcDao jdbcDao;

    @RequestMapping(value = "/subscriptions/{id}/list", method = RequestMethod.GET)
    @ResponseBody
    public List<Subscription>  getSubscriptions(@PathVariable String id) {
        return JdbcSubscriptionDao.selectTraditionalSchedulesByUser(jdbcDao, id);
    }

    @RequestMapping(value = "/subscriptions/list_inactive_users", method = RequestMethod.GET)
    @ResponseBody
    public List<Subscription>  getSubscriptionsOfDisabledUsers() {
        return JdbcSubscriptionDao.getSubscriptionsOfDisabledUsers(jdbcDao, Subscription.TYPE_TRADITIONAL);
    }

    @RequestMapping(value = "/subscriptions/{id}/info", method = RequestMethod.GET)
    @ResponseBody
    public SubscriptionStatus getSubscriptionInfo(@PathVariable String id) {
        SubscriptionStatus sub = new SubscriptionStatus();
        int expiredSubscriptions = JdbcSubscriptionDao.getExpiredSubscriptionsCount(jdbcDao, id, Subscription.TYPE_TRADITIONAL);
        String maxReports = String.valueOf(GlobalConstants.DEFAULT_MAX_REPORTS);
        UserPreferences userPref = JdbcUserPreferencesDao.selectPreferencesByUser(jdbcDao, id);
        if (userPref != null)
            maxReports = userPref.getMax_reports();
        int maxReportsInt = maxReports==null?0:Integer.parseInt(maxReports);
        List<Subscription> subs = new ArrayList<Subscription>();
        List<Subscription> subscriptionList
                = JdbcSubscriptionDao.selectTraditionalSchedulesByUser(jdbcDao, id);
        for (Subscription subscription : subscriptionList)
        {
            if (subscription.getDisable().equals("0"))
            {
                subs.add(subscription);
            }
        }
        sub.setUser(id);
        sub.setMaxReports(maxReportsInt);
        sub.setSubscriptions(subs);
        sub.setActiveSubscriptions(subs.size() - expiredSubscriptions);

        return sub;
    }

    @RequestMapping(value = "/schedules/{id}/list", method = RequestMethod.GET)
    @ResponseBody
    public List<Subscription>  getTraditionalSchedulesByUser(@PathVariable String id) {
        return JdbcSubscriptionDao.selectTraditionalSchedulesByUser(jdbcDao, id);
    }

    @RequestMapping(value = "/schedules/list_users", method = RequestMethod.GET)
    @ResponseBody
    public List<Subscription>  getScheduleUserList() {
        return JdbcSubscriptionDao.getUserList(jdbcDao, Subscription.TYPE_TRADITIONAL);
    }


    @RequestMapping(value = "/schedules/{id}/{subId}/disable", method = RequestMethod.GET)
    @ResponseBody
    public JSONResponse disableSubscription(@PathVariable String id, @PathVariable String subId) {
        JSONResponse response = new JSONResponse();
        Subscription modify = new Subscription();
        modify.setSubId(subId);
        modify.setDisable("1");
        JdbcSubscriptionDao.disableSchedule(jdbcDao, modify);
        response.setSuccess(true);
        response.setMessages("Subscription has been disabled!");
        return response;
    }

    @RequestMapping(value = "/schedules/{id}/{subId}/enable", method = RequestMethod.GET)
    @ResponseBody
    public JSONResponse enableSubscription(@PathVariable String id, @PathVariable String subId) {
        JSONResponse response = new JSONResponse();
        JdbcSubscriptionDao.enableSchedule(jdbcDao, subId);
        response.setSuccess(true);
        response.setMessages("Subscription has been enabled!");
        return response;
    }

    // TODO: Enable HttpMethod.DELETE & follow best practices for end point naming conventions.

    @RequestMapping(value = "/schedules/{id}/{subId}/delete", method = RequestMethod.GET)
    @ResponseBody
    public JSONResponse deleteSubscription(@PathVariable String id, @PathVariable String subId) {
        logger.info("Deleting scheduled " + subId + " initiated by " + id);
        JSONResponse response = new JSONResponse();
        JdbcSubscriptionDao.deleteReportSchedule(jdbcDao, subId);
        response.setSuccess(true);
        response.setMessages("Subscription has been deleted!");
        return response;
    }


    @RequestMapping(value = "/schedules/list_user", method = RequestMethod.GET)
    @ResponseBody
    public List<User>  getUserList() {
        return JdbcSubscriptionDao.getUserList(jdbcDao, Subscription.TYPE_TRADITIONAL);
    }




    @RequestMapping(value="/schedules/{action}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public  @ResponseBody
    JSONResponse processReport(@PathVariable String action, @RequestBody Subscription form)  {
        JSONResponse response = new JSONResponse();
        response.setSuccess(true);
        if (action.equals(NEW_SUBSCRIPTION)) {
            boolean success = JdbcSubscriptionDao.insertReportSchedule(jdbcDao, form);
            if (success)
                response.setMessages("Scheduled report has been successfully created!");
            else {
                response.setSuccess(false);
                response.setMessages("Unable to create new job");
            }
        } else if (action.equals(EDIT_SUBSCRIPTION)) {
            // NTSCA-3698-scheduler-fixes
            // below is not enough. Need to follow pattern of legacy lte_v1-0
            // JdbcSubscriptionDao.updateReportSchedule(jdbcDao, form);

            //String subId = form.getParameter("_editSubId");
            //subscription.setSubId(subId);

            JdbcSubscriptionDao.updateSubscriptionStatusOnEdit(jdbcDao, form, null);
            JdbcSubscriptionDao.updateReportSchedule(jdbcDao, form);
            JdbcSubscriptionDao.deleteActionEntries(jdbcDao, form.getSubId(), true);
            JdbcSubscriptionDao.buildFirstAction(jdbcDao, form);

            response.setMessages("Scheduled report has been successfully updated!");
        }

        return response;
    }

}
