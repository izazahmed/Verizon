package com.vzw.ns.controllers;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vzw.ns.models.auth.User;
import com.vzw.web.cellgroups.JSONResponse;

import bus.admin.AdminTool;
import bus.preferences.UserPreferences;
import bus.report.Report;
import db.JdbcDao;
import db.admin.JdbcAdminToolDao;
import db.preferences.JdbcUserPreferencesDao;
import db.report.JdbcReportDao;

/**
 * Created by gundaja on 12/9/16.
 */
@RestController
@RequestMapping(value = "/pt/users")
public class UserController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private final static String KEY = "users";
	@Autowired
	private JdbcDao jdbcDao;

	@Autowired
		User iUser;

	@RequestMapping(value = "/jobs", method = RequestMethod.GET)
	@ResponseBody
	public ArrayList<Report> getLatestJobs(@RequestParam String id) throws SQLException {

		return JdbcReportDao.getLatestReportInstanceByUser(jdbcDao, id, 10);
	}

	@RequestMapping(value = "/{id}/update", method = RequestMethod.POST)
	@ResponseBody
	public UserPreferences updateUserPreferences(@PathVariable String id, @RequestBody UserPreferences userPreference)
			throws SQLException {

		if (iUser != null && iUser.getUserType() != null && iUser.getUserType().equals("1")) {
			JdbcAdminToolDao.updateUserProfile(jdbcDao, convertoAdminTool(userPreference));
		} else {
			JdbcUserPreferencesDao.updateUserPreferences(jdbcDao, userPreference);
		}
		return JdbcUserPreferencesDao.selectPreferencesByUser(jdbcDao, userPreference.getUser_name());
	}

	@RequestMapping(value = "/{id}/news", method = RequestMethod.POST)
	@ResponseBody
	public JSONResponse saveNews(@PathVariable String id, @RequestBody UserPreferences userPreference)
			throws SQLException {
		JSONResponse response = new JSONResponse();
		if (iUser != null && iUser.getUserType() != null && iUser.getUserType().equals("1")) {
			try {
				JdbcAdminToolDao.saveAreaNews(jdbcDao, convertoAdminTool(userPreference));
				response.setSuccess(true);
			} catch (Exception e) {
				response.setSuccess(false);
			}
		}
		return response;
	}

	private AdminTool convertoAdminTool(UserPreferences userPreference) {
		AdminTool adminTool = new AdminTool();
		if (userPreference != null) {
			adminTool.setUserId(userPreference.getUser_name());
			adminTool.setSelLoginsUserArea(userPreference.getArea());
			adminTool.setSelLoginsUserRegion(userPreference.getRegion());
			adminTool.setSelLoginsUserMarket(userPreference.getMarket());
			adminTool.setTxtLoginsSelectedMaxWSR(userPreference.getMax_rpts_per_hour());
			adminTool.setTxtLoginsSelectedMaxESR(userPreference.getMax_reports());
			adminTool.setSelLoginsSelectedAccessLevel(userPreference.getAccess_level());
			adminTool.setSelLoginsSelectedStatus(userPreference.getStatus());
			adminTool.setSelLoginsAuthAlerts(userPreference.getAuthorizedForAlerts());
			adminTool.setTxtLoginsSelectedMaxDisk(userPreference.getMax_disk_space());
			adminTool.setTxtLoginsSelectedPurgeLimit(userPreference.getPurge_limit());
			adminTool.setTxtLoginsPagerr(userPreference.getPager());
			adminTool.setTxtLoginsEmailAddr(userPreference.getEmail());
			adminTool.setNewsArea(userPreference.getNewsArea());
			adminTool.setTxtNewsAreaNews(userPreference.getTxtNewsAreaNews());
			adminTool.setSelHighlFlag(userPreference.getSelHighlFlag());
			adminTool.setTxtLoginsSelectedMaxWatcherSubscriptions(userPreference.getMax_watcher_subs() + "");
			adminTool.setTxtLoginsSelectedMaxWatcherSubscriptionRpts(userPreference.getMax_watcher_subs_rpt() + "");
			adminTool.setSelLoginsAuthWebSrv(userPreference.getAuthorizedForWebSvcReports());
		}
		return adminTool;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	@ResponseBody
	public ArrayList<UserPreferences> getAllUserPreferences() throws SQLException {
		return JdbcUserPreferencesDao.getListOfAllUsersPreferences(jdbcDao);
	}

//	@CacheEvict(value = KEY, key = "#userid")
//	@TokenRequired
//	@RequestMapping(value = "/users/{userid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//	public @ResponseBody String getUser(@PathVariable String userid) throws SQLException {
//		Gson gson = new GsonBuilder().create();
//		JsonObject userObject = new JsonObject();
//		userObject.addProperty("login_id", userid);
//		UserPreferences userPref = JdbcUserPreferencesDao.selectPreferencesByUser(jdbcDao, userid);
//		if (userPref == null) {
//			userPref = new UserPreferences();
//			userPref.setUser_name(userid);
//			userPref.setAccess_level("USER");
//			JdbcUserPreferencesDao.insertUserPreferences(jdbcDao, userPref);
//
//			Boolean isUserPresentInDB = JdbcUserLTEDAO.isUserPresentInDB(this.jdbcDao, userid);
//			if (!isUserPresentInDB) {
//				JdbcUserLTEDAO.addUserToNPTUserTable(this.jdbcDao, userid);
//			}
//		}
//		JsonElement pref = gson.toJsonTree(userPref);
//		userObject.add("preference", pref);
//		JsonObject jsonObject = new JsonObject();
//		jsonObject.add("user", userObject);
//		return jsonObject.toString();
//	}
//
//	@RequestMapping(value = "/tokens/{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//	public @ResponseBody String ldapLogin(@PathVariable String id) throws SQLException {
//		Gson gson = new GsonBuilder().create();
//		JsonObject userObject = new JsonObject();
//		userObject.addProperty("login_id", id);
//		String jwt = JWTUtility.createJWT(id);
//		userObject.addProperty("jwt", jwt);
//		userObject.addProperty("success", true);
//		return userObject.toString();
//	}
//
//	@RequestMapping(value = "/tokens/renew/{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//	public @ResponseBody String renewToken(@PathVariable String id) throws SQLException {
//		Gson gson = new GsonBuilder().create();
//		JsonObject userObject = new JsonObject();
//		userObject.addProperty("login_id", id);
//		String jwt = JWTUtility.createJWT(id);
//		userObject.addProperty("jwt", jwt);
//		userObject.addProperty("success", true);
//		return userObject.toString();
//	}

}
