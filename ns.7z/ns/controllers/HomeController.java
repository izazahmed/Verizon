package com.vzw.ns.controllers;

import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.util.EnvironmentUtil;

import com.vzw.ns.models.auth.User;
import com.vzw.ns.ui.models.HomeForm;

import bus.home.NewsModel;
import bus.location.Market;
import bus.scan.HistScanAlteEnodebPerfModel;
import db.JdbcDao;
import db.home.JdbcHomePageDao;
import db.preferences.JdbcUserPreferencesDao;
import db.scan.JdbcEnodebPerfDAO;

@RestController
@RequestMapping("/pt/home")
public class HomeController {

	@Autowired
	User iUser;

	@Autowired
	JdbcDao jdbcDao;

	protected final Log logger = LogFactory.getLog(getClass());

	@GetMapping(path = "/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<HomeForm> getAllEnodeBWithRepectToMarket() {
	
		ArrayList<NewsModel> mlistOfNews = null;;
		HomeForm mHomeForm = new HomeForm();
		mlistOfNews = JdbcHomePageDao.getListOfNews(this.jdbcDao);
	
		//filter news obj
		NewsModel mDispNews = mlistOfNews.stream().filter(n->n.getArea()==-9999).findAny().orElse(null);
		mHomeForm.setDisplistOfNews(mDispNews);
		
		mlistOfNews.removeIf(n->n.getArea()==-9999);
		mHomeForm.setListOfNews(mlistOfNews);
		mHomeForm.setListOfMyMarkets(new ArrayList<Market>());
		//mHomeForm.setListOfMyMarkets(JdbcUserPreferencesDao.populateMyMarketsForPerfCharts(this.jdbcDao, iUser.getUserName()));
		/*List<ArrayList<HistScanAlteEnodebPerfModel>> histScanTrendDataModelsChartDataList =  new ArrayList<ArrayList<HistScanAlteEnodebPerfModel>>();
		for(Market m : mHomeForm.getListOfMyMarkets()) {
			ArrayList<HistScanAlteEnodebPerfModel> mHistScanTrendDataModel = JdbcEnodebPerfDAO.getListOfAlteEnodebPerfModelsForMinuteMktLevel(jdbcDao, m.getSchemaIid()+"", m.getMarketId());
			histScanTrendDataModelsChartDataList.add(mHistScanTrendDataModel);
		}
		mHomeForm.setHistScanTrendDataModelsChartDataList(histScanTrendDataModelsChartDataList);
		*/
		return new ResponseEntity<HomeForm>(mHomeForm,HttpStatus.OK);
	}
	
	
	
	@GetMapping(path = "/{dbId}/{marketId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ArrayList getHistScanAlteEnodebPerfModelbyMarket(@PathVariable String dbId,@PathVariable String marketId) {
		if(EnvironmentUtil.isAppIdAlte()) {
			return JdbcEnodebPerfDAO.getListOfAlteEnodebPerfModelsForMinuteMktLevel(jdbcDao, dbId, marketId);
		}else {
			return JdbcEnodebPerfDAO.getListOfHistScanTrendModelsForMinuteMktLevel(jdbcDao, dbId, marketId);
		}
	}
}
