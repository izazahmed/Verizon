package com.vzw.ns.controllers;

import bus.ListItem;
import bus.location.EnodeB;
import bus.location.Market;
import com.vzw.ns.model.ReportContentForm;
import db.JdbcDao;
import db.JdbcReportLevelDao;
import db.JdbcReportTypeDao;
import db.location.JdbcEnodeBDao;
import db.location.JdbcMarketDao;
import db.location.JdbcRegionDao;
import db.sah.JdbcSahDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;
import org.vzw.lte.util.ClearCacheUtil;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by gundaja on 2/7/18.
 */
@RequestMapping(value = "/pt/ne", method = RequestMethod.GET)
@RestController
public class NetworkElementController {
    private final static String REGION_CACHE_KEY = "regions";
    private final static String MARKET_CACHE_KEY = "markets";
    private final static String MARKET_REGION_CACHE_KEY = "markets-key";
    private final static String REPORT_LEVELS_KEY = "report-levels";
    private final static String REPORT_CONTENT_LEVELS_KEY = "report-content-levels";
    private final static String REPORT_TYPES_KEY = "report-types";
    private final static String SAH_REPORT_LEVEL_REPORT_TYPES_KEY = "report-levels-types";

    @Autowired
    private JdbcDao jdbcDao;

    @Autowired
    private StringRedisTemplate template;

    @RequestMapping(value = "/eNodeBs", method = RequestMethod.GET)
    @ResponseBody
    public List<EnodeB> getEnodeBsByMarket(@RequestParam String market, @RequestParam String vendor) throws SQLException {
        return JdbcEnodeBDao.populateEnodeBsByMarket(jdbcDao, market, vendor);
    }


    @Cacheable(value = REGION_CACHE_KEY)
    @RequestMapping(value = "/regions", method = RequestMethod.GET)
    @ResponseBody
    public List<bus.location.Region> getRegions() throws SQLException {
        return JdbcRegionDao.populateRegions(jdbcDao);
    }

    @Cacheable(value = MARKET_CACHE_KEY)
    @RequestMapping(value = "/markets", method = RequestMethod.GET)
    @ResponseBody
    public List<Market> getMarkets() throws SQLException {
        return JdbcMarketDao.populateMarkets(jdbcDao);

    }

    @CachePut(value = MARKET_REGION_CACHE_KEY, key = "#region")
    @RequestMapping(value = "/market", method = RequestMethod.GET)
    @ResponseBody
    public List<Market> getMarketByRegion(@RequestParam String region) throws SQLException {
        return JdbcMarketDao.populateMarketsByRegion(jdbcDao, region);

    }

    @Cacheable(value = REPORT_LEVELS_KEY)
    @RequestMapping(value = "/reportLevels", method = RequestMethod.GET, produces = "application/json")
    public
    @ResponseBody
    List<ListItem> getReportLevels() throws SQLException {
        return JdbcReportLevelDao.getSahReportLevels(jdbcDao);
    }

    @Cacheable(value = REPORT_TYPES_KEY)
    @RequestMapping(value = "/reportTypes", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<ListItem> getReportTypes() throws SQLException {
        return JdbcReportTypeDao.getSahReportTypes(jdbcDao);
    }

    @Cacheable(value = REPORT_CONTENT_LEVELS_KEY)
    @RequestMapping(value = "/sahContentReportLevel", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<ListItem> getSahContentReportLevel() throws SQLException {
        return JdbcSahDao.getSahContentReportLevel(jdbcDao, null);
    }


    @RequestMapping(value = "/sahContentReportLevel/{contentId}", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<ListItem> getSahContentReportLevel(@PathVariable String contentId) throws SQLException {
        return JdbcSahDao.getSahContentReportLevel(jdbcDao, contentId);
    }

    @RequestMapping(value = "/sahContentReportLevel/{contentId}/create", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public boolean createContentLevelType(@PathVariable String contentId, @RequestBody ReportContentForm form) throws SQLException {

        Integer newContentId = JdbcSahDao.insertReportContent(jdbcDao, form);
        form.setContentId("" + newContentId);
        boolean result = JdbcSahDao.updateSahContentReportLevel(jdbcDao, form);
        ClearCacheUtil.clearAllCache();
        template.getConnectionFactory().getConnection().flushAll();
        return result;
    }

    @RequestMapping(value = "/sahContentReportLevel/{contentId}/update", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public boolean updateContentLevelType(@PathVariable String contentId, @RequestBody ReportContentForm form) throws SQLException {
        boolean result = JdbcSahDao.updateSahContentReportLevel(jdbcDao, form);
        ClearCacheUtil.clearAllCache();
        template.getConnectionFactory().getConnection().flushAll();
        return result;
    }


    @Cacheable(value = SAH_REPORT_LEVEL_REPORT_TYPES_KEY)
    @RequestMapping(value = "/sahReportLevelReportType", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<ListItem> getReportLevelReportType() throws SQLException {
        return JdbcReportLevelDao.getReportLevelReportType(jdbcDao);
    }

    @RequestMapping(value = "/sahContentReportType/{contentId}", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<ListItem> getReportLevelReportType(@PathVariable String contentId) throws SQLException {
        return JdbcSahDao.getSahContentReportType(jdbcDao, contentId);
    }


}
