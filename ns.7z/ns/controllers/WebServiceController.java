package com.vzw.ns.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.util.GeneralUtility;

import com.vzw.web.services.ReportWebServiceController;
import com.vzw.web.services.ReportWebServiceUtil;

import db.JdbcDao;
import web.services.LteWebserviceUtil;
import com.google.gson.*;
import db.cellgroups.JdbcCgaDao;
import java.sql.SQLException;
import org.springframework.web.bind.annotation.*;

/**
 * Created by gundaja on 2/7/18.
 */
@RestController
@RequestMapping(value={"/alte","/elte"})
public class WebServiceController {
	protected final Log logger = LogFactory.getLog(this.getClass());

	@Autowired
	private JdbcDao jdbcDao;
	
	@RequestMapping(value = "/cg/getAllEnodeBGroups.htm", method = RequestMethod.GET)
	public @ResponseBody String getAllEnodeBGroups() throws SQLException {
		Gson gson = new GsonBuilder().create();

		String json = gson.toJson(JdbcCgaDao.getAllEnodeBGroups(jdbcDao));
		return json;
	}

	@RequestMapping(value = "/cg/getEnodeBGroups.htm", method = RequestMethod.GET)
	public @ResponseBody String getEnodeBGroups(@RequestParam String user) throws SQLException {
		Gson gson = new GsonBuilder().create();

		String json = gson.toJson(JdbcCgaDao.getEnodeBGroupsForUser(jdbcDao, user));

		return json;
	}

	@RequestMapping(value = "/cg/getMyEnodeBGroupSubs.htm", method = RequestMethod.GET)
	public @ResponseBody String getMyEnodeBGroupSubs(@RequestParam String login) throws SQLException {
		Gson gson = new GsonBuilder().create();

		String json = gson.toJson(JdbcCgaDao.getMyEnodeBGroupSubs(jdbcDao, login));
		return json;
	}

	@RequestMapping(value = "/cg/unsubscribeToGroup.htm", method = RequestMethod.POST)
	public @ResponseBody String unsubscribeToGroup(@RequestParam String userId, String elementGroupId)
			throws SQLException {
		boolean retVal = JdbcCgaDao.delEnodeBGroupSubscription(jdbcDao, userId, elementGroupId);
		return String.valueOf(retVal);
	}

	@RequestMapping(value = "/cg/subscribeToGroup.htm", method = RequestMethod.POST)
	public @ResponseBody String subscribeToGroup(@RequestParam String userId, String elementGroupId)
			throws SQLException {
		boolean retVal = JdbcCgaDao.delEnodeBGroupSubscription(jdbcDao, userId, elementGroupId);

		retVal = JdbcCgaDao.addEnodeBGroupSubscription(jdbcDao, userId, elementGroupId);
		return String.valueOf(retVal);
	}

	@RequestMapping(value = "/cg/getAllEnodeBByGroup.htm", method = RequestMethod.GET)
	public @ResponseBody String getEnodebListItemsForCellGroup(@RequestParam String group) throws SQLException {
		Gson gson = new GsonBuilder().create();

		ArrayList<String> al = new ArrayList<String>();
		al.add(group);

		String json = gson.toJson(JdbcCgaDao.getEnodeBsForGroups(jdbcDao, al));

		return json;
	}

	@RequestMapping(value = "/cg/getMyCellgroup.htm", method = RequestMethod.GET)
	public @ResponseBody String getMyCellgroup(@RequestParam String group) throws SQLException {
		Gson gson = new GsonBuilder().create();

		ArrayList<String> al = new ArrayList<String>();
		al.add(group);

		String json = gson.toJson(JdbcCgaDao.getEnodeBsForGroups(jdbcDao, al));

		return json;
	}

	@RequestMapping(value = "/reportWebService.htm", method = RequestMethod.GET)
	@ResponseBody
	public void runClassicWebService(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String action = GeneralUtility.trim(request.getParameter(ReportWebServiceUtil.REQ_PARAM_ACTION));
		boolean isHtml = request.getParameter("content") != null&& request.getParameter("content").equalsIgnoreCase("html");
		String httpPathOfFile = null;
		ArrayList<String> errors = new ArrayList<String>();

		ReportWebServiceController ws = new ReportWebServiceController();
		ws.setJdbcDao(jdbcDao);
		if (action != null && action.equalsIgnoreCase(ReportWebServiceUtil.ACTION_PULL_EXISTING_RPT)) {
			// pull existing report
			httpPathOfFile = ws.handlePullRequest(request, response, errors);
		}
		else if (action != null && action.equalsIgnoreCase(ReportWebServiceUtil.ACTION_EXECUTE_RPT)) {
			// create new report and stream back data
			httpPathOfFile = ws.handleExecuteRequest(request, response, errors);
		}
		else if (action != null && action.equalsIgnoreCase(ReportWebServiceUtil.ACTION_EXECUTE_LAST_HR_RPT)) {
			// create new report and stream back data
			httpPathOfFile = ws.handleExecuteLastHrRequest(request, response, errors);
		}
		else if (action != null && action.equalsIgnoreCase(ReportWebServiceUtil.ACTION_EXECUTE_TEMPLATE_RPT)) {
			// create new report and stream back data
			httpPathOfFile = ws.handleExecuteTemplateRequest(request, response, errors);
		}
		
		//httpPathOfFile = ws.handleExecuteTemplateRequest(request, response, errors);

		if (isHtml) {
			ws.sendHTML(request, response, httpPathOfFile, errors);
		} else {
			ws.fetchFile(httpPathOfFile, "csv", response,errors);
			//ws.sendFile(request, response, httpPathOfFile, errors);
		}

		return;
	}

	@RequestMapping(value = "/getDataWebService.htm", method = RequestMethod.GET)
	@ResponseBody
	public void runDataWebService(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LteWebserviceController lte = new LteWebserviceController();
		lte.setJdbcDao(jdbcDao);
		String action = GeneralUtility.trim(request.getParameter(web.services.ReportWebServiceUtil.REQ_PARAM_ACTION));
		ArrayList<ArrayList<String>> data = null;

		if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORTTYPES_WS)) {
			data = lte.handleGetReportTypes(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORTLEVELS_WS)) {
			data = lte.handleGetReportLevels(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_MMEPOOLS_REGIONS_WS)) {
			data = lte.handleGetMMEPoolsAndRegions(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_MMES_WS)) {
			data = lte.handleGetMMEs(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_SGWs_WS)) {
			data = lte.handleGetSGWs(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_MARKETS)) {
			data = lte.handleGetMarketList(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_MARKETS_WS)) {
			data = lte.handleGetMarkets(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_ENODEB_GROUPS)) {
			data = lte.handleGetEnodebGroupList(request);
		}  else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_ENODEB_GROUPS_AND_SUBS)) {
			data = lte.handleGetEnodebGroupsAndSubsList(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_ENODEBS)) {
			data = lte.handleGetEnodebList(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORTS)) {
			data = lte.handleGetReportsList(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_PGWs_WS)) {
			data = lte.handleGetPGWs(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORTSINFO_FOR_UPLOADING)) {
			data = lte.handleGetReportInfoForUploading(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_REPORT_KPIS)) {
			data = lte.handleGetReportKPIsList(request);
		} else if (action != null && action.equalsIgnoreCase(LteWebserviceUtil.ACTION_GET_CONTENT_KPIS)) {
			data = lte.handleGetSahKPIsList(request);
		}

		lte.sendFile(request, response, data);
	}

}
