package com.vzw.ns.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.util.EnvironmentUtil;

import com.vzw.ns.models.auth.User;

import bus.report.Report;
import bus.tree.SetupTree;
import db.JdbcDao;
import db.report.JdbcReportBrowserDao;
import db.tree.JdbcSetupTreeDao;

@RestController
@RequestMapping("/pt/reportBrowser")
public class ReportBrowserController {

	@Autowired
	User iUser;

	@Autowired
	JdbcDao jdbcDao;

	List tree;

	@GetMapping(path = "/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Report>> getAllEnodeBWithRepectToMarket() {
		return new ResponseEntity<List<Report>>(JdbcReportBrowserDao.selectReportsByUser(jdbcDao, iUser.getUserName()),
				HttpStatus.OK);
	}

	@GetMapping(path = "/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Report>> getAllEnodeBWithRepectToMarket(@PathVariable String userId) {
		return new ResponseEntity<List<Report>>(JdbcReportBrowserDao.selectReportsByUser(jdbcDao, userId),
				HttpStatus.OK);
	}

	@Cacheable(value = "report_tree", keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
	@GetMapping(path = "/tree", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SetupTree> getSetupTreeByType() {
		return  JdbcSetupTreeDao.setupTreeByType(jdbcDao, "report");
		
	}

	

}
