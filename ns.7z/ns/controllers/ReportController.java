package com.vzw.ns.controllers;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.vzw.lte.action.ReportEngine;
import org.vzw.lte.dao.JdbcCauseCodeDao;
import org.vzw.lte.model.ElementListDetailsModel;
import org.vzw.lte.model.ReportEngineModel;
import org.vzw.lte.model.ReportInputParamsModel;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.GeneralUtility;
import org.vzw.lte.util.GlobalConstants;

import com.vzw.ns.model.EnodeB;
import com.vzw.ns.model.ReportDetailForm;
import com.vzw.ns.model.ReportLevel;
import com.vzw.ns.model.ReportType;
import com.vzw.ns.models.auth.User;
import com.vzw.ns.repo.IReportLevelRepositoryable;
import com.vzw.ns.repo.IReportTypeable;
import com.vzw.ns.repo.IeNodeBable;
import com.vzw.ns.service.interfaces.IAdHocServiceable;
import com.vzw.ns.ui.models.MmePgwSgwForm;
import com.vzw.ns.ui.models.ReportBuilderForm;
import com.vzw.web.cellgroups.JSONResponse;

import bus.report.Report;
import bus.report.Template;
import bus.report.TemplateFormula;
import db.JdbcDao;
import db.JdbcReportLevelDao;
import db.JdbcReportTypeDao;
import db.report.JdbcElementListDetailsDao;
import db.report.JdbcReportDao;
import db.report.JdbcSqlFilterCriteriaDao;
import db.report.JdbcTemplateDao;
import org.vzw.lte.util.HttpRequestUtil;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by gundaja on 12/9/16.
 */
@RequestMapping(value = "/pt/reports")
@RestController
public class ReportController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	@Autowired
	private JdbcDao jdbcDao;
	private static String CREATE = "CREATE";
	private static String COPY = "COPY";
	private static String RUN = "RUN";
	private static String EDIT = "EDIT";
	private static String DELETE = "DELETE";
	private static String SAVE_AS = "SAVE_AS";
	private static String SAVE = "SAVE";
	private static String EDIT_AND_RUN = "EDIT_AND_RUN";
	private static String CREATE_AND_RUN = "CREATE_AND_RUN";
	public static final String REPORT = "report";
	public static final String FORMULA = "formula";

	@Autowired
	User iUser;

	@Autowired
	IeNodeBable ieNodeBable;

	@Autowired
	IReportLevelRepositoryable iReportLevelRepositoryable;

	@Autowired
	IReportTypeable iReportTypeable;

	@Autowired
	IAdHocServiceable iAdHocServiceable;

	@GetMapping(path = "/{userType}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ReportBuilderForm getReportBuilerInfo(@PathVariable String userType) {
		ReportBuilderForm mReportBuilderForm = new ReportBuilderForm();
		// checkifadmin
		if (userType != null && userType.equals("0")) {
			mReportBuilderForm.setReports(JdbcReportDao.selectReportsByUserForDDL(jdbcDao, iUser.getUserName(),
					Report.USAGE_STANDARD, true, true));
		}
		mReportBuilderForm.setrBReportLevels(getReportBuilderReportLevels());
		mReportBuilderForm.setReportTypes(getReportTypes());
		mReportBuilderForm.setStrVendor(EnvironmentUtil.AppId);
		mReportBuilderForm.setCauseCodes(getCauseCodes());
		mReportBuilderForm.setEutrcells(Arrays.asList(EnvironmentUtil.getEutrancellsArray()));
		mReportBuilderForm.setAppcarriers(GlobalConstants.LIST_OF_CARRIERS);

		return mReportBuilderForm;// new ResponseEntity<ReportBuilderForm>(mReportBuilderForm, HttpStatus.OK);
	}

	@Cacheable(value = "getCauseCodes", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList getCauseCodes() {
		return JdbcCauseCodeDao.getCauseCodes(jdbcDao);
	}

	@Cacheable(value = "getReportTypes", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList getReportTypes() {
		return JdbcReportTypeDao.getReportTypes(jdbcDao);
	}

	@Cacheable(value = "getReportBuilderReportLevels", keyGenerator = "customAKeyGenerator", cacheManager = "myACacheManager")
	private ArrayList getReportBuilderReportLevels() {
		return JdbcReportLevelDao.getReportBuilderReportLevels(jdbcDao);
	}

	@GetMapping(path = "/sahTemplate/{reportId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<String>> getSahTemplateIdsUsedByReport(@PathVariable String reportId) {

		return new ResponseEntity<List<String>>(JdbcTemplateDao.getSahTemplateIdsUsedByReport(jdbcDao, reportId),
				HttpStatus.OK);
	}

	@GetMapping(path = "/reportLevel/{rLevel}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ReportLevel getAReportLevelIdbyName(@PathVariable String rLevel) {

		return iReportLevelRepositoryable.getAReportLevelIdbyName(rLevel);

	}

	@GetMapping(path = "/reportType/{rType}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ReportType getReportTypeIdbyName(@PathVariable String rType) {

		return iReportTypeable.getReportTypeIdbyName(rType);

	}

	@GetMapping(path = "/reportDetails/{reportId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Report getReport(@PathVariable String reportId) throws SQLException {
		return JdbcReportDao.selectReportById(jdbcDao, reportId);
	}

	@RequestMapping(value = "/filterCriteria/{reportId}", method = RequestMethod.GET)
	@ResponseBody
	public List<String> getSqlFilterCriteria(@PathVariable String reportId) throws SQLException {
		return JdbcSqlFilterCriteriaDao.getSqlFilterCriteriaByReportId(jdbcDao, reportId);
	}

	@GetMapping(path = "/enodeBs", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EnodeB> getAllEnodeBWithByMarkets(@RequestParam String mMarkets) {
		List<Integer> mlist = new ArrayList<Integer>();
		String m[] = mMarkets.split(",");
		for (int i = 0; i < m.length; i++) {
			mlist.add(Integer.parseInt(m[i]));
		}

		List<EnodeB> mEnodeBs = ieNodeBable.getAllEnodeBbyMarketAndRVendor(mlist);
		return mEnodeBs;
	}

	@GetMapping(path = "/mmespgws/{type}/{user}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<MmePgwSgwForm>> getPgwePdg(@PathVariable String type, @PathVariable String user) {
		return new ResponseEntity<List<MmePgwSgwForm>>(iAdHocServiceable.getAllMmeSgwPgw(user, type), HttpStatus.OK);
	}

	@RequestMapping(value = "/elementList/{reportId}", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> getELementList(@PathVariable String reportId) throws SQLException {
		List<ElementListDetailsModel> elm = JdbcElementListDetailsDao.getElementListDetailsByReportId(jdbcDao,
				reportId);
		List<String> sites = new ArrayList<String>();
		List<String> sitesWithNames = new ArrayList<String>();
		// List<String> markets = new ArrayList<String>();
		List<String> cellGroups = new ArrayList<String>();
		List<String> listElements = new ArrayList<String>();
		Map<String, Object> model = new HashMap<>();

		for (ElementListDetailsModel e : elm) {
			if ((e.getListElementType().equals("MMEPOOL")) || (e.getListElementType().equals("MME"))
					|| (e.getListElementType().equals("SGW")) || (e.getListElementType().equals("PGW"))
					|| (e.getListElementType().equals("REGION")) || (e.getListElementType().equals("MARKET"))
					|| (e.getListElementType().equals("CAUSE_CODE"))) {
				// regular list elements
				// Note the 2 part, ^ delimited string: we need to include element type so that
				// the
				// js cb routines know what type they are working with.
				listElements.add(e.getListElementId() + "^" + e.getListElementType());
			}
			// if
			// (e.getListElementType().equals(ElementListDetailsModel.LIST_ELEMENT_TYPE_MARKET))
			// {
			// markets.add("" + e.getListElementId());

			// }

			if (e.getListElementType().equals(ElementListDetailsModel.LIST_ELEMENT_TYPE_ENODEB)) {
				sites.add(e.getListElementId() + "");
			}

			if (e.getListElementType().equals(ElementListDetailsModel.LIST_ELEMENT_TYPE_CELL_GROUP)) {
				cellGroups.add(e.getListElementId() + "");
			}
		}
		// Get enodeb names for enodeb iids if we have any.
		sitesWithNames = JdbcElementListDetailsDao.getSiteDisplayNames(jdbcDao, sites);

		model.put("listElements", listElements);
		// model.put("markets", markets);
		model.put("enodeBs", sitesWithNames);
		model.put("celGroups", cellGroups);

		return model;
	}

	@CacheEvict(value = { TreeNodeController.TREE_NODE_CACHE_KEY,
			TreeNodeController.TREE_NODE_CACHE_KEY }, allEntries = true)
	@RequestMapping(value = "/rb/{action}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody JSONResponse processReport(@PathVariable String action, @RequestBody ReportDetailForm form, HttpServletRequest request) {
		Report report = null;
		ReportEngineModel reportEngineModel = null;
		String reportId = "";
		JSONResponse response = new JSONResponse();
		response.setSuccess(false);
		if (form != null && form.getUserName() == null) {
			form.setUserName(iUser.getUserName());
		}
		Boolean IS_EDIT_ACTION = action.equalsIgnoreCase(EDIT) && form.getReportId() != null && form.getReportId().trim().length()>0;
		Boolean IS_EDIT_AND_RUN_ACTION = action.equalsIgnoreCase(EDIT_AND_RUN) && form.getReportId() != null && form.getReportId().trim().length()>0;
		Boolean IS_CREATE_ACTION = action.equalsIgnoreCase(CREATE);
		Boolean IS_CREATE_AND_RUN_ACTION = action.equalsIgnoreCase(CREATE_AND_RUN);
		Boolean IS_RUN_ACTION = action.equalsIgnoreCase(RUN) && form.getReportId() != null && form.getReportId().trim().length()>0;
		// Boolean IS_SAVE_AS_ACTION = action.equals(SAVE_AS);
		Boolean IS_COPY_ACTION = action.equalsIgnoreCase(COPY);
		Boolean IS_DELETE_ACTION = action.equalsIgnoreCase(DELETE);

		try {
			reportId = form.getReportId();
			String templateId = null;

			if (IS_COPY_ACTION || IS_DELETE_ACTION) {
				report = JdbcReportDao.selectReportById(jdbcDao, reportId.toString());
				if (form.getReportId() == null) {
					response.setMessages("Please select a report to copy.");
					return response;
				}

				if (IS_DELETE_ACTION) {
					JdbcReportDao.deleteReport(jdbcDao, reportId.toString());
					response.setSuccess(true);
					response.setMessages("Template has been successfully deleted.");
					return response;
				}

				if (!JdbcReportDao.checkUserReportName(jdbcDao, form.getUserName(), form.getNewReportName())) {
					response.setMessages("A report with that name already exists for this user.");
					return response;
				}
				report.setUserName(form.getUserName());
				report.setReportName(form.getNewReportName());
				BigDecimal newRptId = JdbcReportDao.createReport(jdbcDao, report, true);
				response.setMessages("Report has been copied!");
				response.setSuccess(true);
				response.setId(newRptId + "");
				return response;
			}

			// Populate template
			Template template = new Template();
			if (!IS_RUN_ACTION) {
				template.setUserId(form.getUserName());
				template.setColIndex("0");
			}

			if (IS_CREATE_ACTION || IS_CREATE_AND_RUN_ACTION) {
				if (!JdbcReportDao.checkUserReportName(jdbcDao, form.getUserName(), form.getNewReportName())) {
					response.setMessages("A report with that name already exists for this user.");
					return response;
				}
				report = form.createReportModel(jdbcDao, "rb");
				report.setReportName(form.getNewReportName());
				report.setIsSAHRpt("N");
			}

			if (IS_EDIT_ACTION || IS_EDIT_AND_RUN_ACTION) {
				report = form.createReportModel(jdbcDao, "");
				Report tempReport = JdbcReportDao.selectReportById(jdbcDao, form.getReportId() + "");
				if (GeneralUtility.isEmpty(form.getNewReportName())) {
					form.setNewReportName(tempReport.getReportName());
				} else if (!form.getNewReportName().equals(tempReport.getReportName())) {
					if (!JdbcReportDao.checkUserReportName(jdbcDao, report.getUserName(), form.getNewReportName())) {
						response.setMessages(
								"A report named '" + form.getNewReportName() + "' already exists for this user.");
						return response;
					}
				}
				report.setReportName(form.getNewReportName());
				report.setDateCreated(tempReport.getDateCreated());
				template.setUserId(tempReport.getUserName());
				report.setReportId(tempReport.getReportId());
				report.setTemplates(tempReport.getTemplates());
				JdbcReportDao.updateReport(jdbcDao, report);
				reportId = form.getReportId();
				templateId = report.getTemplates().get(0);
			}

			int count = 0;
			List<TemplateFormula> templateFormulas = new ArrayList<TemplateFormula>();
			if (!IS_RUN_ACTION) {
				for (String f : form.getFormulas()) {
					TemplateFormula tf = new TemplateFormula();
					tf.setFormulaId(f);
					if (IS_EDIT_ACTION || IS_EDIT_AND_RUN_ACTION) {
						tf.setTemplateId(templateId);
					}
					tf.setColIndex(Integer.toString(count++));
					templateFormulas.add(tf);
				}
				template.setTemplateFormulas(templateFormulas);
			}

			if (IS_EDIT_ACTION || IS_EDIT_AND_RUN_ACTION) {
				template.setTemplateId(templateId);
				template.setReportId(form.getReportId() + "");
				if (!IS_RUN_ACTION)
					JdbcTemplateDao.updateTemplate(jdbcDao, template);
			}

			if (IS_CREATE_ACTION || IS_CREATE_AND_RUN_ACTION) {
				reportId = JdbcReportDao.createReport(jdbcDao, report, false).toString();
				template.setReportId(reportId + "");
				JdbcTemplateDao.createTemplate(jdbcDao, template);
			}

			response.setId(reportId + "");
			TreeNodeController.clearUserReportTree(form.getUserName());
			if (IS_CREATE_AND_RUN_ACTION || IS_EDIT_AND_RUN_ACTION || IS_RUN_ACTION) {
				// report.setTemplates(Arrays.asList(template.getTemplateId()));
				ReportEngine reportEngine = new ReportEngine();
				ReportInputParamsModel reportInputParamsModel = new ReportInputParamsModel();
				reportInputParamsModel.setReportId(reportId.toString());
				reportInputParamsModel.setUserId(form.getUserName());
				reportInputParamsModel.setCreateCSVFile(true);
				reportInputParamsModel.setCreatePDFFile(false);
				reportInputParamsModel.setRptMethod(GlobalConstants.RPTMETHOD_CUSTOMREPORT);
				// Added for RTT percent
				// reportInputParamsModel.setRttPercent(0L);
				if (form.getRegions() != null && form.getRegions().size() > 0) {
					String[] regionsSelected = new String[form.getRegions().size()];
					for (int i = 0; i < form.getRegions().size(); i++) {
						regionsSelected[i] = form.getRegions().get(i).toString();
					}
					reportInputParamsModel.setRegionsSelected(regionsSelected);
				}

				// NTSCA-1503
				reportInputParamsModel.setUserSourceIp(HttpRequestUtil.getClientIP(request));

				reportEngineModel = reportEngine.populateData(jdbcDao, reportInputParamsModel);
				response.setSuccess(true);
				response.setMessages(reportEngineModel.getHttpPath());
			} else {
				response.setMessages("Report has been created/updated!");
				response.setSuccess(true);
			}

		} catch (DataAccessException e) {
			response.setMessages(e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			response.setMessages(e.getMessage());
			e.printStackTrace();
		}

		return response;
	}
}
