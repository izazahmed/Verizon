package com.vzw.ns.controllers;

import bus.home.NewsModel;
import bus.location.Market;
import com.vzw.ns.model.AdHocForm;
import com.vzw.ns.model.ReportDetailForm;
import com.vzw.ns.models.auth.User;
import com.vzw.ns.ui.models.BannerForm;
import com.vzw.ns.ui.models.HomeForm;
import com.vzw.web.cellgroups.JSONResponse;
import db.JdbcDao;
import db.admin.JdbcAdminToolDao;
import db.home.JdbcHomePageDao;
import db.scan.JdbcEnodebPerfDAO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.vzw.lte.util.EnvironmentUtil;

import javax.validation.Valid;
import java.util.ArrayList;

@RestController
@RequestMapping("/pt/banner")
public class BannerController {
	@Autowired
	JdbcDao jdbcDao;

	protected final Log logger = LogFactory.getLog(getClass());

	@GetMapping(path = "/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BannerForm> getBanner() {
		// call displayBanner() : when cache is cleared this method must be called.
		EnvironmentUtil.displayBanner(jdbcDao);

		// get banner flag and message from DB when Admin -> Control Pannel loads
		BannerForm mBannerForm = new BannerForm();
		mBannerForm.setFlag(EnvironmentUtil.showBanner?"Y":"N");
		mBannerForm.setMessage(EnvironmentUtil.bannerMessage);

		return new ResponseEntity<BannerForm>(mBannerForm,HttpStatus.OK);
	}

	@PostMapping("/")
	JSONResponse processBanner(@Valid @RequestBody BannerForm form) {
		JSONResponse response = new JSONResponse();

		String bannerFlag = form.getFlag();
		String bannerMessage = form.getMessage();
		if(JdbcAdminToolDao.updateBannerMessage(jdbcDao, bannerFlag, bannerMessage)){
			response.setMessages("Banner message updated successfully.");
			response.setSuccess(true);
		}else {
			response.setMessages("Error! Not able to set Banner Message.");
			response.setSuccess(false);
		}

		return response;
	}

}
