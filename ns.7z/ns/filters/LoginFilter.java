package com.vzw.ns.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.nimbusds.jwt.SignedJWT;
import com.vzw.ns.models.auth.User;

@Component
@WebFilter(urlPatterns = { "/*" })
@Repository
public class LoginFilter implements Filter {// implements Filter {

	public static Logger logger = LoggerFactory.getLogger(LoginFilter.class);

	@Autowired
	User iUser;

//	@Autowired
//	@Qualifier("jdbcTemplateAlpt")
//	private JdbcTemplate jdbcTemplateAlpt;
//
//	@Autowired
//	@Qualifier("jdbcTemplateElpt")
//	private JdbcTemplate jdbcTemplateElpt;

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		String mPath = ((HttpServletRequest) request).getServletPath();
		System.out.println(mPath);
		String appName = ((HttpServletRequest) request).getHeader("appName");
		iUser.setCuurentApp(appName);
		
		String userType = ((HttpServletRequest) request).getHeader("userType");
		iUser.setUserType(userType);
//		logger.info("User Type: " + userType);
		if (!mPath.contains("alte") && !mPath.contains("elte") && !mPath.contains("download") && mPath.contains("pt")) {
			HttpServletRequest mHttpServletRequest = (HttpServletRequest) request;
			String mTokenAuth = mHttpServletRequest.getHeader("token");
//			logger.info("Token : " + mTokenAuth);
			if (mTokenAuth == null) {
				((HttpServletResponse) response).sendError(HttpServletResponse.SC_UNAUTHORIZED,
						"The token is not valid.");
				return;
			}
			SignedJWT signedJWT = null;
			try {
				signedJWT = SignedJWT.parse(mTokenAuth);
				String mUserName = signedJWT.getPayload().toString().replace("{", "").replaceAll("\"", "").split(":")[1]
						.split(",")[0];
				iUser.setUserName(mUserName);
//				logger.info("User  : " + mUserName);
			
			} catch (Exception e) {
				logger.error("Token not found or validation fails!" + e);
			}
		}
		chain.doFilter(request, response);
	}


//	public JdbcDao createJdbcDao(JdbcTemplate jdbcTemplate) {
//		JdbcDao jdbcDao = new JdbcDao();
//		jdbcDao.setDataSource(jdbcTemplate.getDataSource());
//		jdbcDao.setDataSourceBackup(jdbcTemplate.getDataSource());
//		return jdbcDao;
//	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}
}
