package com.vzw.ns.util;

import com.vzw.ns.security.SecurityConstants;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.xml.bind.DatatypeConverter;
import java.util.Date;

/**
 * Created by gundaja on 6/23/17.
 */
public class JWTUtility {

    public static final String SECRET_KEY = "V3r!z0n";
    public static final String APP_ISSUER = "xLPT";
    public static final String APP_SUBJECT = "auth";
    public static final int APP_EXPIRATION = 5;         // Expiration in years
    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final Log logger = LogFactory.getLog(JWTUtility.class);

    public static String createJWT(String id) {

        String token = Jwts.builder()
                .setSubject(id)
                .setExpiration(new Date(System.currentTimeMillis() + SecurityConstants.EXPIRATION_TIME))
                .signWith(SignatureAlgorithm.HS512, SecurityConstants.SECRET.getBytes())
                .compact();

        return token;
    }

    public static Boolean validateJWT(String jwt, String username) {
        logger.info("Validating user: " + username);

        Claims claims = Jwts.parser()
                .setSigningKey(DatatypeConverter.parseBase64Binary(SecurityConstants.SECRET))
                .parseClaimsJws(jwt).getBody();

        return claims.getId().equals(username);
    }

    public static Claims parseJWT(String jwt) {

        //This line will throw an exception if it is not a signed JWS (as expected)
        Claims claims = Jwts.parser()
                .setSigningKey(DatatypeConverter.parseBase64Binary(SecurityConstants.SECRET))
                .parseClaimsJws(jwt).getBody();

        return claims;
    }

    public static void main(String[] args) {

        String jwt = JWTUtility.createJWT("gundaja");

        JWTUtility.parseJWT(jwt);
        Boolean rv = false;
        try {
            // eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJndW5kYWphIiwiaWF0IjoxNTEwMDk1ODk1LCJleHAiOjE1MTAwMDk0OTUsInN1YiI6ImF1dGgiLCJpc3MiOiJ4TFBUIiwidXNlcm5hbWUiOiJndW5kYWphIn0.LcvABFrRwccnlb5or720tQgD2FX1Q_QYwG8hxlvmvYw

            rv = JWTUtility.validateJWT("eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJndW5kYWphIiwiaWF0IjoxNTEwMDk1ODQxLCJleHAiOjE2Njc3NzU4NDEsInN1YiI6ImF1dGgiLCJpc3MiOiJ4TFBUIiwidXNlcm5hbWUiOiJndW5kYWphIn0.6I4wfffsO4CsLjnm_7jutIvrxssbplmGNEhpsq5yGMg", "gundaja");

        } catch (Exception name) {
            System.out.println("Unable to authenticate: " + name.getMessage());

        } finally {

        }
        System.out.println(" rv: " + rv);
    }
}
