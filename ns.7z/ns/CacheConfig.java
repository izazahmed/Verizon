package com.vzw.ns;
//
//import java.lang.reflect.Method;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.Map;
//import java.util.Set;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cache.CacheManager;
//import org.springframework.cache.annotation.CachingConfigurerSupport;
//import org.springframework.cache.annotation.EnableCaching;
//import org.springframework.cache.interceptor.KeyGenerator;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.data.redis.cache.RedisCacheManager;
//import org.springframework.data.redis.connection.RedisConnectionFactory;
//import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
//import org.springframework.data.redis.serializer.StringRedisSerializer;
//
//@Configuration
//@EnableCaching
//public class CacheConfig extends CachingConfigurerSupport {
//
//	@Value("${spring.redis.host}")
//	private String redisHostName;
//
//	@Value("${spring.redis.port}")
//	private int redisPort;
//
//	@Value("${spring.cache.redis.time-to-live}")
//	private Long DEFAULT_TTL;
//	
//	@Value("${current.app.name}")
//	private String appname;
//
//	@Bean
//	public JedisConnectionFactory redisConnectionFactory() {
//		JedisConnectionFactory redisConnectionFactory = new JedisConnectionFactory();
//
//		// Defaults
//		redisConnectionFactory.setHostName(redisHostName);
//		redisConnectionFactory.setPort(redisPort);
//		return redisConnectionFactory;
//	}
//
//	@Bean
//	public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory cf) {
//		// RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String,
//		// Object>();
//		RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
//		template.setKeySerializer(new StringRedisSerializer());
//		template.setHashKeySerializer(new StringRedisSerializer());
//		template.setDefaultSerializer(new GenericJackson2JsonRedisSerializer());
//		template.setConnectionFactory(cf);
//		return template;
//	}
//	
//	
//	@Bean(name = "myACacheManager")
//	public CacheManager cacheManager(RedisTemplate<String, Object> redisTemplate) {
//		RedisCacheManager cacheManager = new RedisCacheManager(redisTemplate);
//
//		StringBuffer sb = new StringBuffer();
//
//		Map<String, Long> expires = new HashMap<String, Long>();
//		
//		Set<byte[]> keys = redisTemplate.getConnectionFactory().getConnection().keys(new String(appname+"_").getBytes());
//
//		Iterator<byte[]> it = keys.iterator();
//
//		while (it.hasNext()) {
//
//			byte[] data = (byte[]) it.next();
//			sb.append(new String(data, 0, data.length));
//			expires.put(sb.toString(), DEFAULT_TTL);
//			System.out.println("Keys-->"+sb);
//		}
//		// Number of seconds before expiration. Defaults to unlimited (0)z
//		
//		cacheManager.setDefaultExpiration(DEFAULT_TTL);
//		System.out.println("expries->"+expires);
//		cacheManager.setExpires(expires);
//		return cacheManager;
//	}
//
//	@Bean(name = "customAKeyGenerator")
//	public KeyGenerator keyGenerator() {
//	
//		return new KeyGenerator() {
//			@Override
//			public Object generate(Object o, Method method, Object... objects) {
//				// This will generate a unique key of the class name, the method name,
//				// and all method parameters appended.
//				
//				StringBuilder sb = new StringBuilder();
//				sb.append(appname);
//				sb.append(o.getClass().getName());
//				sb.append(method.getName());
//				for (Object obj : objects) {
//					sb.append(obj.toString());
//				}
//				return sb.toString();
//			}
//		};
//	}
//}