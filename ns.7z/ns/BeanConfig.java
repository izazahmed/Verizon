package com.vzw.ns;

import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
import org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;

import db.JdbcDao;

/**
 * Created by gundaja on 2/15/18.
 */
@Configuration
public class BeanConfig {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	

    @Bean
    public JdbcDao jdbcDao() {
        JdbcDao jdbcDao = new JdbcDao();
        jdbcDao.setDataSource(jdbcTemplate.getDataSource());
        jdbcDao.setDataSourceBackup(jdbcTemplate.getDataSource());
        return jdbcDao;
    }
    

    @Bean
    public MultipartResolver multipartResolver() {
        return new StandardServletMultipartResolver();
    }

    @Bean
    public PhysicalNamingStrategy physicalNamingStrategy() {
        return new PhysicalNamingStrategyStandardImpl();
    }
   
    
//    @Bean(name = "dataSource")
//    @ConfigurationProperties(prefix = "spring.datasource")
//    @Primary
//    public DataSource dataSource1() {
//     return DataSourceBuilder.create().build();
//    }
//
//    @Bean(name = "jdbcTemplateMain")
//    public JdbcTemplate jdbcTemplate1(@Qualifier("dataSource1") DataSource ds) {
//     return new JdbcTemplate(ds);
//    }
//    
//    @Bean(name = "dataSourceBackup")
//    @ConfigurationProperties(prefix = "spring.datasource1")
//    public DataSource dataSource2() {
//     return  DataSourceBuilder.create().build();
//    }
//
//    @Bean(name = "jdbcTemplateBackup")
//    public JdbcTemplate jdbcTemplate2(@Qualifier("dataSourceBackup1") DataSource ds) {
//     return new JdbcTemplate(ds);
//    }

}
