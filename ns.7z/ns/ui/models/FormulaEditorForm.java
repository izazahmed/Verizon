package com.vzw.ns.ui.models;

import java.io.Serializable;
import java.util.List;

import bus.ListItem;
import bus.tree.Folder;

public class FormulaEditorForm  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9097203366570714820L;

	private List users;

	private List formulas;

	private List<ListItem> aggregationTypes;

	private List<Folder> userFolders;

	
	public FormulaEditorForm() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the users
	 */
	public List getUsers() {
		return users;
	}

	/**
	 * @param users the users to set
	 */
	public void setUsers(List users) {
		this.users = users;
	}

	/**
	 * @return the formulas
	 */
	public List getFormulas() {
		return formulas;
	}

	/**
	 * @param formulas the formulas to set
	 */
	public void setFormulas(List formulas) {
		this.formulas = formulas;
	}

	/**
	 * @return the aggregationTypes
	 */
	public List<ListItem> getAggregationTypes() {
		return aggregationTypes;
	}

	/**
	 * @param aggregationTypes the aggregationTypes to set
	 */
	public void setAggregationTypes(List<ListItem> aggregationTypes) {
		this.aggregationTypes = aggregationTypes;
	}

	/**
	 * @return the userFolders
	 */
	public List<Folder> getUserFolders() {
		return userFolders;
	}

	/**
	 * @param userFolders the userFolders to set
	 */
	public void setUserFolders(List<Folder> userFolders) {
		this.userFolders = userFolders;
	}
	
	

}
