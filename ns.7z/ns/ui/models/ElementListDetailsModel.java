package com.vzw.ns.ui.models;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ElementListDetailsModel implements Cloneable {

	// These constants represent the valid contents of the list_element_type
	// member.
	public static final String LIST_ELEMENT_TYPE_MME_POOL = "MMEPOOL";
	public static final String LIST_ELEMENT_TYPE_SGW = "SGW";
	public static final String LIST_ELEMENT_TYPE_PGW = "PGW";
	public static final String LIST_ELEMENT_TYPE_MME = "MME";
	public static final String LIST_ELEMENT_TYPE_REGION = "REGION";
	public static final String LIST_ELEMENT_TYPE_MARKET = "MARKET";
	public static final String LIST_ELEMENT_TYPE_CELL_GROUP = "CELL_GROUP";
	public static final String LIST_ELEMENT_TYPE_ENODEB = "ENODEB";
	public static final String LIST_ELEMENT_TYPE_EUTRANCELL = "EUTRANCELL";
	public static final String LIST_ELEMENT_TYPE_RTT = "RTT";
	public static final String LIST_ELEMENT_TYPE_UAC = "UAC";
	public static final String LIST_ELEMENT_TYPE_CAUSE_CODE = "CAUSE_CODE";
	public static final String LIST_ELEMENT_TYPE_UNKNOWN = "(UNKNOWN)";

	// TODO Get rid of these arrays if not used for LTE
	public static final String[] arrayOfElementTypes = { LIST_ELEMENT_TYPE_MME_POOL, LIST_ELEMENT_TYPE_SGW,
			LIST_ELEMENT_TYPE_PGW, LIST_ELEMENT_TYPE_MME, LIST_ELEMENT_TYPE_REGION, LIST_ELEMENT_TYPE_MARKET,
			LIST_ELEMENT_TYPE_CELL_GROUP, LIST_ELEMENT_TYPE_ENODEB, LIST_ELEMENT_TYPE_UAC,
			LIST_ELEMENT_TYPE_EUTRANCELL };
	public static List<String> LIST_OF_ELEMENT_TYPES = null;
	static {
		LIST_OF_ELEMENT_TYPES = Arrays.asList(arrayOfElementTypes);
	}

	private BigDecimal iId;
	private BigDecimal reportId;
	// listElementId is the iid (primary key) of the instance of this
	// listElementType that is to be reported upon. For example, if this
	// element is of type MARKET, then listElementId will be the target
	// market's iid.
	private int listElementId = 0;
	// listElementType is one of the LIST_ELEMENT_TYPE* values defined herein.
	private String listElementType = LIST_ELEMENT_TYPE_UNKNOWN;

	public BigDecimal getIId() {
		return iId;
	}

	public void setIId(BigDecimal iId) {
		this.iId = iId;
	}

	private List<String> causeCodes;

	/**
	 * @return the reportId
	 */
	public BigDecimal getReportId() {
		return reportId;
	}

	/**
	 * @param reportId the reportId to set
	 */
	public void setReportId(BigDecimal reportId) {
		this.reportId = reportId;
	}

	public void setReportId(String reportId) {
		try {
			this.reportId = new BigDecimal(reportId);
		} catch (NumberFormatException nfe) {
		}
	}

	public int getListElementId() {
		return listElementId;
	}

	public void setListElementId(int listElementId) {
		this.listElementId = listElementId;
	}

	/**
	 * @return the listElementType
	 */
	public String getListElementType() {
		return listElementType;
	}

	/**
	 * @param listElementType the listElementType to set
	 */
	public void setListElementType(String listElementType) {
		this.listElementType = listElementType;
	}

	/**
	 * Create a new ElementListDetailsModel and data fill it from the contents of
	 * the given ResultSet. Only columns found in the ResultSet are loaded; others
	 * others contain harmless defaults.
	 *
	 * WARNING: the caller is responsibile for managing the ResultSet. This method
	 * reads only the single results row at the current ResultSet cursor location.
	 * The caller must therfore invoke rs.next() when appropriate, as that is NOT
	 * done here.
	 *
	 * @return a new, data-filled ElementListDetailsModel object, else null upon
	 *         error.
	 */
	public static ElementListDetailsModel loadResultSet(ResultSet rs) {
		if (rs == null) {
			return null;
		}

		ElementListDetailsModel eld = new ElementListDetailsModel();
		try {
			eld.setIId(rs.getBigDecimal("IID"));
		} catch (SQLException se) {
		}
		try {
			eld.setReportId(rs.getBigDecimal("REPORT_ID"));
		} catch (SQLException se) {
		}
		try {
			eld.setListElementId(rs.getInt("LIST_ELEMENT_ID"));
		} catch (SQLException se) {
		}
		try {
			eld.setListElementType(rs.getString("LIST_ELEMENT_TYPE"));
		} catch (SQLException se) {
		}

		return eld;
	}

	/*************************************************************************
	 * Factory Methods
	 ************************************************************************/
	/**
	 * Create an element_list_details instance for a given type.
	 *
	 * @param iid iid of target type. This must not be null or empty.
	 *
	 * @return a new ElementListDetailsMode, else null on error.
	 */
	public static ElementListDetailsModel CreateEldm(String iid, String type) {

		try {

			if (iid == null || iid.trim().length() == 0) {
				return null;
			}
			ElementListDetailsModel eld = new ElementListDetailsModel();
			eld.setListElementType(type);
			eld.setListElementId(Integer.parseInt(iid));
			return eld;

		} catch (Exception e) {
			return null; // iid string was probably not a number.
		}
	}

	public static ElementListDetailsModel CreateEldm(Integer iid, String type) {
		return CreateEldm(iid.toString(), type);
	}

	public String dumpRecord() {
		StringBuilder sb = new StringBuilder();
		sb.append("ElementListDetails, hashCode " + hashCode() + ":\n");
		sb.append("iId = " + getIId() + "\n");
		sb.append("reportId = " + getReportId() + "\n");
		sb.append("listElementId = " + getListElementId() + "\n");
		sb.append("listElementType = " + getListElementType() + "\n");
		return sb.toString();
	}

	public Object clone() throws CloneNotSupportedException {
		ElementListDetailsModel clone = (ElementListDetailsModel) super.clone();
		return clone;
	}
}
