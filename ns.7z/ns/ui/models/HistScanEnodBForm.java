package com.vzw.ns.ui.models;

public class HistScanEnodBForm {
	
	private String iid;
	private String name;
	private String type;
	/**
	 * @return the iid
	 */
	public String getIid() {
		return iid;
	}
	/**
	 * @param iid the iid to set
	 */
	public void setIid(String iid) {
		this.iid = iid;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	
	

}
