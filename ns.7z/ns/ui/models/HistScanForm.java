package com.vzw.ns.ui.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import bus.ListItem;
import bus.location.EnodeB;
import bus.scan.HistScanAlteEnodebPerfModel;
import bus.scan.HistScanAlteRssiDeltaModel;
import bus.scan.HistScanAlteULNoiseModel;
import bus.scan.HistScanRadioIntfModel;
import bus.scan.HistScanThruModel;
import bus.scan.HistScanTrendDataModel;



public class HistScanForm implements Serializable {
	

	private static final long serialVersionUID = 5765199197488470354L;

	private List<HistScanEnodBForm> scanList;

	private Map<String, String> cellAlarmType;

	private Map<String, String> types;
	
	private String dbId;

	private String daysOfTrend;

	private String rxavgDelAlarm;

	private HistScanEnodBForm markets;

	private ArrayList<ListItem> listOfMarketsAndEnodeBGroups;

	private List<EnodeB> listOfEnodeBModels;

	private String action;

	private String typeOfEnodeBCells;

	private String marketId;

	private String typeOfChart;

	private List<String> marketsLists;

	LinkedHashMap<String, String> mapEnodebsHigherEutrancells;

	private String selRadioIntSecAbvNegAlarm;

	private String selRadioIntAlarm;

	private ArrayList<HistScanAlteEnodebPerfModel> zScoreList;
	
	private ArrayList<HistScanTrendDataModel> zScoreListELPT;

	private ArrayList<String> listOfCellsWithAlarmRadioVal;

	private ArrayList<String> listOfCellsWithSecAbvNegAlarmVal;

	private ArrayList<String> listOfRadioListOfAlarm;

	private Boolean showEnodebPerfCharts = false;

	private Boolean showRadioCharts = false;

	private Boolean showThruCharts = false;

	private Boolean showRadioHeatMapCharts = false;

	private Boolean showAlteULNoiseHeatMapCharts = false;

	private Boolean showAlteRssiDeltaCharts = false;

	private Map<String, List<String>> scan_eNodeB_zscore_2_4;

	private Map<String, List<String>> scan_eNodeB_zscore_0_2;

	private String selAlteULNoiseAlarm;

	private String selAlteULNoiseDbRange;

	private String chkRssiOnlyAlarmCells;
	
	private ArrayList listofCreateEnodebPerfCharts;
	
	//private ArrayList<HistScanTrendDataModel> listofCreateEnodebPerfChartsELPT;

	private ArrayList<HistScanAlteULNoiseModel> listOfCreateULNoiseModels;

	private ArrayList<HistScanAlteRssiDeltaModel> listOfCreateRssiDeltaModels;
	

	private ArrayList<HistScanThruModel> listOfHistScanThruModels;

	private ArrayList<HistScanRadioIntfModel> listOfHistScanRadioIntfModels;

	private ArrayList<String> listOfBTSVals;
	
	private String cachKey;

	private boolean isCg;
	
	
	
	/**
	 * @return the cachKey
	 */
	public String getCachKey() {
		return cachKey;
	}

	/**
	 * @param cachKey the cachKey to set
	 */
	public void setCachKey(String cachKey) {
		this.cachKey = cachKey;
	}

	/**
	 * @return the dbId
	 */
	public String getDbId() {
		return dbId;
	}

	/**
	 * @param dbId the dbId to set
	 */
	public void setDbId(String dbId) {
		this.dbId = dbId;
	}

	/**
	 * @return the chkRssiOnlyAlarmCells
	 */
	public String getChkRssiOnlyAlarmCells() {
		return chkRssiOnlyAlarmCells;
	}

	/**
	 * @param chkRssiOnlyAlarmCells the chkRssiOnlyAlarmCells to set
	 */
	public void setChkRssiOnlyAlarmCells(String chkRssiOnlyAlarmCells) {
		this.chkRssiOnlyAlarmCells = chkRssiOnlyAlarmCells;
	}

	/**
	 * @return the selAlteULNoiseAlarm
	 */
	public String getSelAlteULNoiseAlarm() {
		return selAlteULNoiseAlarm;
	}

	/**
	 * @param selAlteULNoiseAlarm the selAlteULNoiseAlarm to set
	 */
	public void setSelAlteULNoiseAlarm(String selAlteULNoiseAlarm) {
		this.selAlteULNoiseAlarm = selAlteULNoiseAlarm;
	}

	/**
	 * @return the selAlteULNoiseDbRange
	 */
	public String getSelAlteULNoiseDbRange() {
		return selAlteULNoiseDbRange;
	}

	/**
	 * @param selAlteULNoiseDbRange the selAlteULNoiseDbRange to set
	 */
	public void setSelAlteULNoiseDbRange(String selAlteULNoiseDbRange) {
		this.selAlteULNoiseDbRange = selAlteULNoiseDbRange;
	}

	/**
	 * @return the scanList
	 */
	public List<HistScanEnodBForm> getScanList() {
		return scanList;
	}

	/**
	 * @param scanList the scanList to set
	 */
	public void setScanList(List<HistScanEnodBForm> scanList) {
		this.scanList = scanList;
	}

	/**
	 * @return the types
	 */
	public Map<String, String> getTypes() {
		return types;
	}

	/**
	 * @param types the types to set
	 */
	public void setTypes(Map<String, String> types) {
		this.types = types;
	}

	/**
	 * @return the cellAlarmType
	 */
	public Map<String, String> getCellAlarmType() {
		return cellAlarmType;
	}

	/**
	 * @param cellAlarmType the cellAlarmType to set
	 */
	public void setCellAlarmType(Map<String, String> cellAlarmType) {
		this.cellAlarmType = cellAlarmType;
	}

	/**
	 * @return the daysOfTrend
	 */
	public String getDaysOfTrend() {
		return daysOfTrend;
	}

	/**
	 * @param daysOfTrend the daysOfTrend to set
	 */
	public void setDaysOfTrend(String daysOfTrend) {
		this.daysOfTrend = daysOfTrend;
	}

	

	/**
	 * @return the rxavgDelAlarm
	 */
	public String getRxavgDelAlarm() {
		return rxavgDelAlarm;
	}

	/**
	 * @param rxavgDelAlarm the rxavgDelAlarm to set
	 */
	public void setRxavgDelAlarm(String rxavgDelAlarm) {
		this.rxavgDelAlarm = rxavgDelAlarm;
	}

	/**
	 * @return the markets
	 */
	public HistScanEnodBForm getMarkets() {
		return markets;
	}

	/**
	 * @param markets the markets to set
	 */
	public void setMarkets(HistScanEnodBForm markets) {
		this.markets = markets;
	}

	public ArrayList<ListItem> getListOfMarketsAndEnodeBGroups() {
		return listOfMarketsAndEnodeBGroups;
	}

	public void setListOfMarketsAndEnodeBGroups(ArrayList<ListItem> listOfMarketsAndEnodeBGroups) {
		this.listOfMarketsAndEnodeBGroups = listOfMarketsAndEnodeBGroups;
	}

	public List<EnodeB> getListOfEnodeBModels() {
		return listOfEnodeBModels;
	}

	public void setListOfEnodeBModels(List<EnodeB> mListEnobs) {
		this.listOfEnodeBModels = mListEnobs;
	}



	/**
	 * @return the marketId
	 */
	public String getMarketId() {
		return marketId;
	}

	/**
	 * @param marketId the marketId to set
	 */
	public void setMarketId(String marketId) {
		this.marketId = marketId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getTypeOfEnodeBCells() {
		return typeOfEnodeBCells;
	}

	public void setTypeOfEnodeBCells(String typeOfEnodeBCells) {
		this.typeOfEnodeBCells = typeOfEnodeBCells;
	}

	public String getTypeOfChart() {
		return typeOfChart;
	}

	public void setTypeOfChart(String typeOfChart) {
		this.typeOfChart = typeOfChart;
	}

	public List<String> getMarketsLists() {
		return marketsLists;
	}

	public void setMarketsLists(List<String> marketsLists) {
		this.marketsLists = marketsLists;
	}

	public LinkedHashMap<String, String> getMapEnodebsHigherEutrancells() {
		return mapEnodebsHigherEutrancells;
	}

	public void setMapEnodebsHigherEutrancells(LinkedHashMap<String, String> mapEnodebsHigherEutrancells) {
		this.mapEnodebsHigherEutrancells = mapEnodebsHigherEutrancells;
	}

	public String getSelRadioIntSecAbvNegAlarm() {
		return selRadioIntSecAbvNegAlarm;
	}

	public void setSelRadioIntSecAbvNegAlarm(String selRadioIntSecAbvNegAlarm) {
		this.selRadioIntSecAbvNegAlarm = selRadioIntSecAbvNegAlarm;
	}

	public String getSelRadioIntAlarm() {
		return selRadioIntAlarm;
	}

	public void setSelRadioIntAlarm(String selRadioIntAlarm) {
		this.selRadioIntAlarm = selRadioIntAlarm;
	}

	public ArrayList<HistScanAlteEnodebPerfModel> getzScoreList() {
		return zScoreList;
	}

	public void setzScoreList(ArrayList<HistScanAlteEnodebPerfModel> zScoreList) {
		this.zScoreList = zScoreList;
	}

	public ArrayList<String> getListOfCellsWithAlarmRadioVal() {
		return listOfCellsWithAlarmRadioVal;
	}

	public void setListOfCellsWithAlarmRadioVal(ArrayList<String> listOfCellsWithAlarmRadioVal) {
		this.listOfCellsWithAlarmRadioVal = listOfCellsWithAlarmRadioVal;
	}

	public ArrayList<String> getListOfCellsWithSecAbvNegAlarmVal() {
		return listOfCellsWithSecAbvNegAlarmVal;
	}

	public void setListOfCellsWithSecAbvNegAlarmVal(ArrayList<String> listOfCellsWithSecAbvNegAlarmVal) {
		this.listOfCellsWithSecAbvNegAlarmVal = listOfCellsWithSecAbvNegAlarmVal;
	}

	public Boolean getShowEnodebPerfCharts() {
		return showEnodebPerfCharts;
	}

	public void setShowEnodebPerfCharts(Boolean showEnodebPerfCharts) {
		this.showEnodebPerfCharts = showEnodebPerfCharts;
	}

	public Boolean getShowRadioCharts() {
		return showRadioCharts;
	}

	public void setShowRadioCharts(Boolean showRadioCharts) {
		this.showRadioCharts = showRadioCharts;
	}

	public Boolean getShowThruCharts() {
		return showThruCharts;
	}

	public void setShowThruCharts(Boolean showThruCharts) {
		this.showThruCharts = showThruCharts;
	}

	public Boolean getShowRadioHeatMapCharts() {
		return showRadioHeatMapCharts;
	}

	public void setShowRadioHeatMapCharts(Boolean showRadioHeatMapCharts) {
		this.showRadioHeatMapCharts = showRadioHeatMapCharts;
	}

	public ArrayList<String> getListOfRadioListOfAlarm() {
		return listOfRadioListOfAlarm;
	}

	public void setListOfRadioListOfAlarm(ArrayList<String> listOfRadioListOfAlarm) {
		this.listOfRadioListOfAlarm = listOfRadioListOfAlarm;
	}

	public Map<String, List<String>> getScan_eNodeB_zscore_2_4() {
		return scan_eNodeB_zscore_2_4;
	}

	public void setScan_eNodeB_zscore_2_4(Map<String, List<String>> scan_eNodeB_zscore_2_4) {
		this.scan_eNodeB_zscore_2_4 = scan_eNodeB_zscore_2_4;
	}

	public Map<String, List<String>> getScan_eNodeB_zscore_0_2() {
		return scan_eNodeB_zscore_0_2;
	}

	public void setScan_eNodeB_zscore_0_2(Map<String, List<String>> scan_eNodeB_zscore_0_2) {
		this.scan_eNodeB_zscore_0_2 = scan_eNodeB_zscore_0_2;
	}

	/**
	 * @return the showAlteULNoiseHeatMapCharts
	 */
	public Boolean getShowAlteULNoiseHeatMapCharts() {
		return showAlteULNoiseHeatMapCharts;
	}

	/**
	 * @param showAlteULNoiseHeatMapCharts the showAlteULNoiseHeatMapCharts to set
	 */
	public void setShowAlteULNoiseHeatMapCharts(Boolean showAlteULNoiseHeatMapCharts) {
		this.showAlteULNoiseHeatMapCharts = showAlteULNoiseHeatMapCharts;
	}

	/**
	 * @return the showAlteRssiDeltaCharts
	 */
	public Boolean getShowAlteRssiDeltaCharts() {
		return showAlteRssiDeltaCharts;
	}

	/**
	 * @param showAlteRssiDeltaCharts the showAlteRssiDeltaCharts to set
	 */
	public void setShowAlteRssiDeltaCharts(Boolean showAlteRssiDeltaCharts) {
		this.showAlteRssiDeltaCharts = showAlteRssiDeltaCharts;
	}

	/**
	 * @return the listofCreateEnodebPerfCharts
	 */
	public ArrayList getListofCreateEnodebPerfCharts() {
		return listofCreateEnodebPerfCharts;
	}

	/**
	 * @param listofCreateEnodebPerfCharts the listofCreateEnodebPerfCharts to set
	 */
	public void setListofCreateEnodebPerfCharts(ArrayList listofCreateEnodebPerfCharts) {
		this.listofCreateEnodebPerfCharts = listofCreateEnodebPerfCharts;
	}

	/**
	 * @return the listOfBTSVals
	 */
	public ArrayList<String> getListOfBTSVals() {
		return listOfBTSVals;
	}

	/**
	 * @param listOfBTSVals the listOfBTSVals to set
	 */
	public void setListOfBTSVals(ArrayList<String> listOfBTSVals) {
		this.listOfBTSVals = listOfBTSVals;
	}

	/**
	 * @return the listOfCreateULNoiseModels
	 */
	public ArrayList<HistScanAlteULNoiseModel> getListOfCreateULNoiseModels() {
		return listOfCreateULNoiseModels;
	}

	/**
	 * @param listOfCreateULNoiseModels the listOfCreateULNoiseModels to set
	 */
	public void setListOfCreateULNoiseModels(ArrayList<HistScanAlteULNoiseModel> listOfCreateULNoiseModels) {
		this.listOfCreateULNoiseModels = listOfCreateULNoiseModels;
	}

	/**
	 * @return the listOfCreateRssiDeltaModels
	 */
	public ArrayList<HistScanAlteRssiDeltaModel> getListOfCreateRssiDeltaModels() {
		return listOfCreateRssiDeltaModels;
	}

	/**
	 * @param listOfCreateRssiDeltaModels the listOfCreateRssiDeltaModels to set
	 */
	public void setListOfCreateRssiDeltaModels(ArrayList<HistScanAlteRssiDeltaModel> listOfCreateRssiDeltaModels) {
		this.listOfCreateRssiDeltaModels = listOfCreateRssiDeltaModels;
	}
	
	public boolean isCg() {
		return isCg;
	}

	public void setCg(boolean isCg) {
		this.isCg = isCg;
	}

	/**
	 * @return the listOfHistScanThruModels
	 */
	public ArrayList<HistScanThruModel> getListOfHistScanThruModels() {
		return listOfHistScanThruModels;
	}

	/**
	 * @param listOfHistScanThruModels the listOfHistScanThruModels to set
	 */
	public void setListOfHistScanThruModels(ArrayList<HistScanThruModel> listOfHistScanThruModels) {
		this.listOfHistScanThruModels = listOfHistScanThruModels;
	}

	/**
	 * @return the listOfHistScanRadioIntfModels
	 */
	public ArrayList<HistScanRadioIntfModel> getListOfHistScanRadioIntfModels() {
		return listOfHistScanRadioIntfModels;
	}

	/**
	 * @param listOfHistScanRadioIntfModels the listOfHistScanRadioIntfModels to set
	 */
	public void setListOfHistScanRadioIntfModels(ArrayList<HistScanRadioIntfModel> listOfHistScanRadioIntfModels) {
		this.listOfHistScanRadioIntfModels = listOfHistScanRadioIntfModels;
	}

	/**
	 * @return the listofCreateEnodebPerfChartsELPT
	 */
	
	/**
	 * @return the zScoreListELPT
	 */
	public ArrayList<HistScanTrendDataModel> getzScoreListELPT() {
		return zScoreListELPT;
	}

	/**
	 * @param zScoreListELPT the zScoreListELPT to set
	 */
	public void setzScoreListELPT(ArrayList<HistScanTrendDataModel> zScoreListELPT) {
		this.zScoreListELPT = zScoreListELPT;
	}
	
	

}
