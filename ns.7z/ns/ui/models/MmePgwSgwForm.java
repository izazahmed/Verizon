package com.vzw.ns.ui.models;

public class MmePgwSgwForm implements java.io.Serializable { 

	private static final long serialVersionUID = 1L;
	private String type;
    private String id;    
    private String compositeId;
    private String name; 
    private String itemName;
    private String description;
    
    private String dbNode;
    private String dbUid;
    private String dbPassword;
    private String dbLocId;
    private String dbLocType;
    private String networkElementId;
    private String elementGroupId; 
    private String mmePoolIid;
    private String regionIid;
    private String subRegionIid;

    private String reportLevels;
    private String reportTypes;
    private String reportLevel;
    private String reportType;
    private String reportEngineValue;
    private String c2ddLevel;
    
    private String bsc; 
    private String bscDesc;
    private String parentRncClusterId;
    private String siteId;
    private String enodeBId;
    private Integer latitude;
    private Integer longitude;
    
    private String aggregationTypes;
    private String sftReleaseLevel; 
    private String templateId;
    private String displayId;
    private String dispOtherMisc;
    private String otherMisc;  
    private String pertainsTo;     // 11/4/2010 wwn.

	private boolean selected = false;
	private String eutrancellsCommaSeparatedList;
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the compositeId
	 */
	public String getCompositeId() {
		return compositeId;
	}
	/**
	 * @param compositeId the compositeId to set
	 */
	public void setCompositeId(String compositeId) {
		this.compositeId = compositeId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}
	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the dbNode
	 */
	public String getDbNode() {
		return dbNode;
	}
	/**
	 * @param dbNode the dbNode to set
	 */
	public void setDbNode(String dbNode) {
		this.dbNode = dbNode;
	}
	/**
	 * @return the dbUid
	 */
	public String getDbUid() {
		return dbUid;
	}
	/**
	 * @param dbUid the dbUid to set
	 */
	public void setDbUid(String dbUid) {
		this.dbUid = dbUid;
	}
	/**
	 * @return the dbPassword
	 */
	public String getDbPassword() {
		return dbPassword;
	}
	/**
	 * @param dbPassword the dbPassword to set
	 */
	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}
	/**
	 * @return the dbLocId
	 */
	public String getDbLocId() {
		return dbLocId;
	}
	/**
	 * @param dbLocId the dbLocId to set
	 */
	public void setDbLocId(String dbLocId) {
		this.dbLocId = dbLocId;
	}
	/**
	 * @return the dbLocType
	 */
	public String getDbLocType() {
		return dbLocType;
	}
	/**
	 * @param dbLocType the dbLocType to set
	 */
	public void setDbLocType(String dbLocType) {
		this.dbLocType = dbLocType;
	}
	/**
	 * @return the networkElementId
	 */
	public String getNetworkElementId() {
		return networkElementId;
	}
	/**
	 * @param networkElementId the networkElementId to set
	 */
	public void setNetworkElementId(String networkElementId) {
		this.networkElementId = networkElementId;
	}
	/**
	 * @return the elementGroupId
	 */
	public String getElementGroupId() {
		return elementGroupId;
	}
	/**
	 * @param elementGroupId the elementGroupId to set
	 */
	public void setElementGroupId(String elementGroupId) {
		this.elementGroupId = elementGroupId;
	}
	/**
	 * @return the mmePoolIid
	 */
	public String getMmePoolIid() {
		return mmePoolIid;
	}
	/**
	 * @param mmePoolIid the mmePoolIid to set
	 */
	public void setMmePoolIid(String mmePoolIid) {
		this.mmePoolIid = mmePoolIid;
	}
	/**
	 * @return the regionIid
	 */
	public String getRegionIid() {
		return regionIid;
	}
	/**
	 * @param regionIid the regionIid to set
	 */
	public void setRegionIid(String regionIid) {
		this.regionIid = regionIid;
	}
	/**
	 * @return the subRegionIid
	 */
	public String getSubRegionIid() {
		return subRegionIid;
	}
	/**
	 * @param subRegionIid the subRegionIid to set
	 */
	public void setSubRegionIid(String subRegionIid) {
		this.subRegionIid = subRegionIid;
	}
	/**
	 * @return the reportLevels
	 */
	public String getReportLevels() {
		return reportLevels;
	}
	/**
	 * @param reportLevels the reportLevels to set
	 */
	public void setReportLevels(String reportLevels) {
		this.reportLevels = reportLevels;
	}
	/**
	 * @return the reportTypes
	 */
	public String getReportTypes() {
		return reportTypes;
	}
	/**
	 * @param reportTypes the reportTypes to set
	 */
	public void setReportTypes(String reportTypes) {
		this.reportTypes = reportTypes;
	}
	/**
	 * @return the reportLevel
	 */
	public String getReportLevel() {
		return reportLevel;
	}
	/**
	 * @param reportLevel the reportLevel to set
	 */
	public void setReportLevel(String reportLevel) {
		this.reportLevel = reportLevel;
	}
	/**
	 * @return the reportType
	 */
	public String getReportType() {
		return reportType;
	}
	/**
	 * @param reportType the reportType to set
	 */
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	/**
	 * @return the reportEngineValue
	 */
	public String getReportEngineValue() {
		return reportEngineValue;
	}
	/**
	 * @param reportEngineValue the reportEngineValue to set
	 */
	public void setReportEngineValue(String reportEngineValue) {
		this.reportEngineValue = reportEngineValue;
	}
	/**
	 * @return the c2ddLevel
	 */
	public String getC2ddLevel() {
		return c2ddLevel;
	}
	/**
	 * @param c2ddLevel the c2ddLevel to set
	 */
	public void setC2ddLevel(String c2ddLevel) {
		this.c2ddLevel = c2ddLevel;
	}
	/**
	 * @return the bsc
	 */
	public String getBsc() {
		return bsc;
	}
	/**
	 * @param bsc the bsc to set
	 */
	public void setBsc(String bsc) {
		this.bsc = bsc;
	}
	/**
	 * @return the bscDesc
	 */
	public String getBscDesc() {
		return bscDesc;
	}
	/**
	 * @param bscDesc the bscDesc to set
	 */
	public void setBscDesc(String bscDesc) {
		this.bscDesc = bscDesc;
	}
	/**
	 * @return the parentRncClusterId
	 */
	public String getParentRncClusterId() {
		return parentRncClusterId;
	}
	/**
	 * @param parentRncClusterId the parentRncClusterId to set
	 */
	public void setParentRncClusterId(String parentRncClusterId) {
		this.parentRncClusterId = parentRncClusterId;
	}
	/**
	 * @return the siteId
	 */
	public String getSiteId() {
		return siteId;
	}
	/**
	 * @param siteId the siteId to set
	 */
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	/**
	 * @return the enodeBId
	 */
	public String getEnodeBId() {
		return enodeBId;
	}
	/**
	 * @param enodeBId the enodeBId to set
	 */
	public void setEnodeBId(String enodeBId) {
		this.enodeBId = enodeBId;
	}
	/**
	 * @return the latitude
	 */
	public Integer getLatitude() {
		return latitude;
	}
	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(Integer latitude) {
		this.latitude = latitude;
	}
	/**
	 * @return the longitude
	 */
	public Integer getLongitude() {
		return longitude;
	}
	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(Integer longitude) {
		this.longitude = longitude;
	}
	/**
	 * @return the aggregationTypes
	 */
	public String getAggregationTypes() {
		return aggregationTypes;
	}
	/**
	 * @param aggregationTypes the aggregationTypes to set
	 */
	public void setAggregationTypes(String aggregationTypes) {
		this.aggregationTypes = aggregationTypes;
	}
	/**
	 * @return the sftReleaseLevel
	 */
	public String getSftReleaseLevel() {
		return sftReleaseLevel;
	}
	/**
	 * @param sftReleaseLevel the sftReleaseLevel to set
	 */
	public void setSftReleaseLevel(String sftReleaseLevel) {
		this.sftReleaseLevel = sftReleaseLevel;
	}
	/**
	 * @return the templateId
	 */
	public String getTemplateId() {
		return templateId;
	}
	/**
	 * @param templateId the templateId to set
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	/**
	 * @return the displayId
	 */
	public String getDisplayId() {
		return displayId;
	}
	/**
	 * @param displayId the displayId to set
	 */
	public void setDisplayId(String displayId) {
		this.displayId = displayId;
	}
	/**
	 * @return the dispOtherMisc
	 */
	public String getDispOtherMisc() {
		return dispOtherMisc;
	}
	/**
	 * @param dispOtherMisc the dispOtherMisc to set
	 */
	public void setDispOtherMisc(String dispOtherMisc) {
		this.dispOtherMisc = dispOtherMisc;
	}
	/**
	 * @return the otherMisc
	 */
	public String getOtherMisc() {
		return otherMisc;
	}
	/**
	 * @param otherMisc the otherMisc to set
	 */
	public void setOtherMisc(String otherMisc) {
		this.otherMisc = otherMisc;
	}
	/**
	 * @return the pertainsTo
	 */
	public String getPertainsTo() {
		return pertainsTo;
	}
	/**
	 * @param pertainsTo the pertainsTo to set
	 */
	public void setPertainsTo(String pertainsTo) {
		this.pertainsTo = pertainsTo;
	}
	/**
	 * @return the selected
	 */
	public boolean isSelected() {
		return selected;
	}
	/**
	 * @param selected the selected to set
	 */
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	/**
	 * @return the eutrancellsCommaSeparatedList
	 */
	public String getEutrancellsCommaSeparatedList() {
		return eutrancellsCommaSeparatedList;
	}
	/**
	 * @param eutrancellsCommaSeparatedList the eutrancellsCommaSeparatedList to set
	 */
	public void setEutrancellsCommaSeparatedList(String eutrancellsCommaSeparatedList) {
		this.eutrancellsCommaSeparatedList = eutrancellsCommaSeparatedList;
	}
	
	
	
}
