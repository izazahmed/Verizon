package com.vzw.ns.ui.models;

import java.util.ArrayList;
import java.util.List;

import bus.ListItem;
import bus.report.Report;
import bus.report.ReportLevel;

public class ReportBuilderForm {
	
	private List users;
	
	private  List<Report> reports;

	private ReportLevel reportLevelClass;
	
	private List<ListItem> reportTypes;
	
	private List<ListItem> rBReportLevels;
	
	private String strVendor;
	
	private ArrayList<ListItem> causeCodes;
	 
	private	List<String> eutrcells;
	 
	private List<String> appcarriers;

	/**
	 * @return the users
	 */
	public List getUsers() {
		return users;
	}

	/**
	 * @param users the users to set
	 */
	public void setUsers(List users) {
		this.users = users;
	}

	/**
	 * @return the reports
	 */
	public List getReports() {
		return reports;
	}

	/**
	 * @param reports the reports to set
	 */
	public void setReports(List reports) {
		this.reports = reports;
	}

	/**
	 * @return the reportLevelClass
	 */
	public ReportLevel getReportLevelClass() {
		return reportLevelClass;
	}

	/**
	 * @param class1 the reportLevelClass to set
	 */
	public void setReportLevelClass(ReportLevel class1) {
		this.reportLevelClass = class1;
	}

	/**
	 * @return the reportTypes
	 */
	public List<ListItem> getReportTypes() {
		return reportTypes;
	}

	/**
	 * @param reportTypes the reportTypes to set
	 */
	public void setReportTypes(List<ListItem> reportTypes) {
		this.reportTypes = reportTypes;
	}

	/**
	 * @return the rBReportLevels
	 */
	public List<ListItem> getrBReportLevels() {
		return rBReportLevels;
	}

	/**
	 * @param rBReportLevels the rBReportLevels to set
	 */
	public void setrBReportLevels(List<ListItem> rBReportLevels) {
		this.rBReportLevels = rBReportLevels;
	}

	/**
	 * @return the strVendor
	 */
	public String getStrVendor() {
		return strVendor;
	}

	/**
	 * @param strVendor the strVendor to set
	 */
	public void setStrVendor(String strVendor) {
		this.strVendor = strVendor;
	}

	/**
	 * @return the causeCodes
	 */
	public ArrayList<ListItem> getCauseCodes() {
		return causeCodes;
	}

	/**
	 * @param causeCodes the causeCodes to set
	 */
	public void setCauseCodes(ArrayList<ListItem> causeCodes) {
		this.causeCodes = causeCodes;
	}

	/**
	 * @return the eutrcells
	 */
	public List<String> getEutrcells() {
		return eutrcells;
	}

	/**
	 * @param list the eutrcells to set
	 */
	public void setEutrcells(List<String> list) {
		this.eutrcells = list;
	}

	/**
	 * @return the appcarriers
	 */
	public List<String> getAppcarriers() {
		return appcarriers;
	}

	/**
	 * @param lIST_OF_CARRIERS the appcarriers to set
	 */
	public void setAppcarriers(List<String> lIST_OF_CARRIERS) {
		this.appcarriers = lIST_OF_CARRIERS;
	}
	
	
	
	
	
}
