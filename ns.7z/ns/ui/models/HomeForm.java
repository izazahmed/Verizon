package com.vzw.ns.ui.models;

import java.util.ArrayList;
import java.util.List;

import bus.home.NewsModel;
import bus.location.Market;
import bus.scan.HistScanAlteEnodebPerfModel;

public class HomeForm {
	
	private ArrayList<NewsModel> listOfNews;
	
	private ArrayList<Market> listOfMyMarkets;
	
	private NewsModel displistOfNews;
	
	private ArrayList<HistScanAlteEnodebPerfModel> histScanTrendDataModels;
	
	private List<ArrayList<HistScanAlteEnodebPerfModel>> histScanTrendDataModelsChartDataList;

	/**
	 * @return the listOfNews
	 */
	public ArrayList<NewsModel> getListOfNews() {
		return listOfNews;
	}

	/**
	 * @param listOfNews the listOfNews to set
	 */
	public void setListOfNews(ArrayList<NewsModel> listOfNews) {
		this.listOfNews = listOfNews;
	}

	/**
	 * @return the listOfMyMarkets
	 */
	public ArrayList<Market> getListOfMyMarkets() {
		return listOfMyMarkets;
	}

	/**
	 * @param listOfMyMarkets the listOfMyMarkets to set
	 */
	public void setListOfMyMarkets(ArrayList<Market> listOfMyMarkets) {
		this.listOfMyMarkets = listOfMyMarkets;
	}

	/**
	 * @return the histScanTrendDataModels
	 */
	public ArrayList<HistScanAlteEnodebPerfModel> getHistScanTrendDataModels() {
		return histScanTrendDataModels;
	}

	/**
	 * @param histScanTrendDataModels the histScanTrendDataModels to set
	 */
	public void setHistScanTrendDataModels(ArrayList<HistScanAlteEnodebPerfModel> histScanTrendDataModels) {
		this.histScanTrendDataModels = histScanTrendDataModels;
	}

	/**
	 * @return the histScanTrendDataModelsChartDataList
	 */
	public List<ArrayList<HistScanAlteEnodebPerfModel>> getHistScanTrendDataModelsChartDataList() {
		return histScanTrendDataModelsChartDataList;
	}

	/**
	 * @param histScanTrendDataModelsChartDataList the histScanTrendDataModelsChartDataList to set
	 */
	public void setHistScanTrendDataModelsChartDataList(
			List<ArrayList<HistScanAlteEnodebPerfModel>> histScanTrendDataModelsChartDataList) {
		this.histScanTrendDataModelsChartDataList = histScanTrendDataModelsChartDataList;
	}

	/**
	 * @return the displistOfNews
	 */
	public NewsModel getDisplistOfNews() {
		return displistOfNews;
	}

	/**
	 * @param displistOfNews the displistOfNews to set
	 */
	public void setDisplistOfNews(NewsModel displistOfNews) {
		this.displistOfNews = displistOfNews;
	}

	
	
}
