package com.vzw.ns.ui.models;

import java.util.List;

//not in use
public class MmeSpgwForm {

	List<MmePgwSgwForm> mmeList;
	List<MmePgwSgwForm> sgwList;
	List<MmePgwSgwForm> pgwList;
	/**
	 * @return the mmeList
	 */
	public List<MmePgwSgwForm> getMmeList() {
		return mmeList;
	}
	/**
	 * @param mmeList the mmeList to set
	 */
	public void setMmeList(List<MmePgwSgwForm> mmeList) {
		this.mmeList = mmeList;
	}
	/**
	 * @return the sgwList
	 */
	public List<MmePgwSgwForm> getSgwList() {
		return sgwList;
	}
	/**
	 * @param sgwList the sgwList to set
	 */
	public void setSgwList(List<MmePgwSgwForm> sgwList) {
		this.sgwList = sgwList;
	}
	/**
	 * @return the pgwList
	 */
	public List<MmePgwSgwForm> getPgwList() {
		return pgwList;
	}
	/**
	 * @param pgwList the pgwList to set
	 */
	public void setPgwList(List<MmePgwSgwForm> pgwList) {
		this.pgwList = pgwList;
	}
	
	
	
	
}
