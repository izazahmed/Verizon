package com.vzw.ns.ui.models;

import java.util.List;

import com.vzw.ns.model.MMEPool;
import com.vzw.ns.model.Market;
import com.vzw.ns.model.UserLTEInfo;
import com.vzw.ns.model.UserPreferencesProfile;

import bus.ListItem;




public class UserPreferencesForm {

	private String userName;
	private List<MMEPool> myMmePool;
	private List<Market>  myMarket;
	private List<Market>  myMarketForPerfCharts;
	private UserPreferencesProfile userProfile;
	private UserLTEInfo userLTEInfo;
	
	
	//clpt for ui
	private List<String>  myVolteCoreList;
	private List<String>  myMrfcClusterList;
	
	
	//clpt for db
	private List<ListItem>  myVolteCoresForDisplay;
	private List<ListItem>  myMrfcClustersForDisplay;
	
	
	public UserPreferencesForm() {
	}
	
	public UserPreferencesForm(List<MMEPool> myMmePool,List<Market>  myMarket,List<Market>  myMarketForPerfCharts,UserPreferencesProfile userProfile,UserLTEInfo userLTEInfo) {
		
		  this.myMmePool = myMmePool;
		  this.myMarket= myMarket;
		  this.myMarketForPerfCharts=myMarketForPerfCharts;
		  this.userProfile=userProfile;
		  this.userLTEInfo=userLTEInfo;
	}
	
	
	
	/**
	 * @return the myMmePool
	 */
	public List<MMEPool> getMyMmePool() {
		return myMmePool;
	}
	/**
	 * @param myMmePool the myMmePool to set
	 */
	public void setMyMmePool(List<MMEPool> myMmePool) {
		this.myMmePool = myMmePool;
	}
	/**
	 * @return the myMarket
	 */
	public List<Market> getMyMarket() {
		return myMarket;
	}
	/**
	 * @param myMarket the myMarket to set
	 */
	public void setMyMarket(List<Market> myMarket) {
		this.myMarket = myMarket;
	}
	/**
	 * @return the myMarketForPerfCharts
	 */
	public List<Market> getMyMarketForPerfCharts() {
		return myMarketForPerfCharts;
	}
	/**
	 * @param myMarketForPerfCharts the myMarketForPerfCharts to set
	 */
	public void setMyMarketForPerfCharts(List<Market> myMarketForPerfCharts) {
		this.myMarketForPerfCharts = myMarketForPerfCharts;
	}
	
	/**
	 * @return the userProfile
	 */
	public UserPreferencesProfile getUserProfile() {
		return userProfile;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @param userProfile the userProfile to set
	 */
	public void setUserProfile(UserPreferencesProfile userProfile) {
		this.userProfile = userProfile;
	}
	/**
	 * @return the userLTEInfo
	 */
	public UserLTEInfo getUserLTEInfo() {
		return userLTEInfo;
	}
	/**
	 * @param userLTEInfo the userLTEInfo to set
	 */
	public void setUserLTEInfo(UserLTEInfo userLTEInfo) {
		this.userLTEInfo = userLTEInfo;
	}

	/**
	 * @return the myVolteCoreList
	 */
	public List<String> getMyVolteCoreList() {
		return myVolteCoreList;
	}

	/**
	 * @param myVolteCoreList the myVolteCoreList to set
	 */
	public void setMyVolteCoreList(List<String> myVolteCoreList) {
		this.myVolteCoreList = myVolteCoreList;
	}

	/**
	 * @return the myMrfcClusterList
	 */
	public List<String> getMyMrfcClusterList() {
		return myMrfcClusterList;
	}

	/**
	 * @param myMrfcClusterList the myMrfcClusterList to set
	 */
	public void setMyMrfcClusterList(List<String> myMrfcClusterList) {
		this.myMrfcClusterList = myMrfcClusterList;
	}

	/**
	 * @return the myVolteCoresForDisplay
	 */
	public List<ListItem> getMyVolteCoresForDisplay() {
		return myVolteCoresForDisplay;
	}

	/**
	 * @param myVolteCoresForDisplay the myVolteCoresForDisplay to set
	 */
	public void setMyVolteCoresForDisplay(List<ListItem> myVolteCoresForDisplay) {
		this.myVolteCoresForDisplay = myVolteCoresForDisplay;
	}

	/**
	 * @return the myMrfcClustersForDisplay
	 */
	public List<ListItem> getMyMrfcClustersForDisplay() {
		return myMrfcClustersForDisplay;
	}

	/**
	 * @param myMrfcClustersForDisplay the myMrfcClustersForDisplay to set
	 */
	public void setMyMrfcClustersForDisplay(List<ListItem> myMrfcClustersForDisplay) {
		this.myMrfcClustersForDisplay = myMrfcClustersForDisplay;
	}
	
	
}
