package com.vzw.ns.models.auth;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import db.JdbcDao;



@Component
@Scope(value="application", proxyMode= ScopedProxyMode.TARGET_CLASS)

public class User {
	
	private String userName;
	private String password;
	private JdbcDao jdbcDao;
	private String cuurentApp;
	private String userType;

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the jdbcDao
	 */
	public JdbcDao getJdbcDao() {
		return jdbcDao;
	}
	/**
	 * @param jdbcDao the jdbcDao to set
	 */
	public void setJdbcDao(JdbcDao jdbcDao) {
		this.jdbcDao = jdbcDao;
	}
	/**
	 * @return the cuurentApp
	 */
	public String getCuurentApp() {
		return cuurentApp;
	}
	/**
	 * @param cuurentApp the cuurentApp to set
	 */
	public void setCuurentApp(String cuurentApp) {
		this.cuurentApp = cuurentApp;
	}
	/**
	 * @return the userType
	 */
	public String getUserType() {
		return userType;
	}
	/**
	 * @param userType the userType to set
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	
}
