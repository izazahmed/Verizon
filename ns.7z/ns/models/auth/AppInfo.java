package com.vzw.ns.models.auth;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import db.JdbcDao;


public class AppInfo {

	private JdbcDao jdbcDao;
	private String cuurentApp;
	
	
	
	/**
	 * @return the jdbcDao
	 */
	public JdbcDao getJdbcDao() {
		return jdbcDao;
	}
	/**
	 * @param jdbcDao the jdbcDao to set
	 */
	public void setJdbcDao(JdbcDao jdbcDao) {
		this.jdbcDao = jdbcDao;
	}
	/**
	 * @return the cuurentApp
	 */
	public String getCuurentApp() {
		return cuurentApp;
	}
	/**
	 * @param cuurentApp the cuurentApp to set
	 */
	public void setCuurentApp(String cuurentApp) {
		this.cuurentApp = cuurentApp;
	}
	
	
	
}
