package com.vzw.ns.security;

public class LoginResponse {

	boolean iLoginSucceeded = false;
	boolean iManagerApproval = false;
	String iMessage = null;
	String iName = null;

	public LoginResponse(boolean aLoginSucceeded, boolean aManagerApproval, String aMessage) {
		iLoginSucceeded = aLoginSucceeded;
		iManagerApproval = aManagerApproval;
		iMessage = aMessage;
	}

	public LoginResponse(boolean aLoginSucceeded, boolean aManagerApproval, String aMessage, String iName) {
		iLoginSucceeded = aLoginSucceeded;
		iManagerApproval = aManagerApproval;
		iMessage = aMessage;
	}

	public boolean loginSucceeded() {
		return iLoginSucceeded;
	}

	public boolean managerApproval() {
		return iManagerApproval;
	}

	public String getMessage() {
		return iMessage;
	}

	public String getiName() {
		return iName;
	}
}
