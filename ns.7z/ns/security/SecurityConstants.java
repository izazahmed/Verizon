package com.vzw.ns.security;

/**
 * Created by gundaja on 3/10/18.
 */
public class SecurityConstants {
    public static final String SECRET = "V3r!z0n"; // Fix for TMVF-88 switching from ALPT/ELPT to CLPT error. Vise versa.
    public static final long EXPIRATION_TIME = 86_400_000; // 1 day   864_000_000 = 10 days
    public static final String TOKEN_PREFIX = "";
    public static final String HEADER_STRING = "token";
}