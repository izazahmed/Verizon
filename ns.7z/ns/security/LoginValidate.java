package com.vzw.ns.security;

import bus.LDAPLogin;
import db.JdbcDao;
import db.login.JdbcUserLTEDAO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LoginValidate {
	Log logger = LogFactory.getLog(this.getClass());
	public static void main(String[] args) {

//		LoginResponse mResponse = LoginValidate.authenticate("xxxx", "gjgfgdf");
//		System.out.println("Login succeeded: " + mResponse.loginSucceeded());
//		System.out.println("Response Message: " + mResponse.getMessage());
	}

	// begin Added by JJ 7.17.2020 NTSCA-1022-power-user
	private static JdbcDao myjdbcDao;

	// jj would have liked to use this but static stuff messing with that. So I work around it
	// using direct call to JdbcUserLTEDAO.isValidPowerUser further below

//	private  boolean isValidPowerUser(String userId,String password){
//		boolean isValidPowerUser = false;
//		isValidPowerUser = JdbcUserLTEDAO.isValidPowerUser(myJJjdbcDao,userId,password);
//		return isValidPowerUser;
//	}

	// JJ 7.20.2020 Remming out this stuff and instead using Jayson's more powerful / expansive LDAPLogin.login method
	// static final String LDAP_HOST = System.getProperty("ldap.sped.host", "ldaps://kslxaddcp1.win.eng.vzwnet.com:636");
	// trying 5G's ldap server since SPFI can login there
	// private static final String DEFAULT_HOST_NAME = "win.eng.vzwnet.com"; // not work - probably might if use 5G looping
//	private static final String DEFAULT_HOST_NAME = "10.215.210.165"; // this is from 5G log file - says it uses this LDAP server when I login on pre-prod spedpd1
	// also 5G accesses this one to login me in: ldap://10.215.210.151
//	private static final String DEFAULT_HOST_NAME = "10.215.210.151"; // Googled - default port for LDAP is port 389, but LDAPS uses port 636
//	private static final String LDAP_PREFIX = "ldap://";
//	private static final String LDAP_PREFIX = "ldaps://";
//	private static final String LDAP_HOST =  LDAP_PREFIX+DEFAULT_HOST_NAME;
	// end

	// Returns null for completed login w/ manager approval. Otherwise, error
	// string is returned.
	// jj added passing the jdbcDao as 3rd arg. Needed for the power user test.
	public static LoginResponse authenticate(String aUserId, String aPasswd, JdbcDao myjdbcDao) {

		String username = aUserId;
		String password = aPasswd;

		// First check is LDAP - see if user valid that way.
		if (LDAPLogin.login(username, password)) {
			// Below is what Jayson way does it. Remmed out.
			// return new UsernamePasswordAuthenticationToken
			// (username, password, Collections.emptyList());

			// Returning what xLPT 1.5 Sateesh uses as a response.
			return new LoginResponse(true, true, "Successful LDAP user login");

		} else { // Second check is to see if valid Power User.

			boolean isValidPowerUser = false;
			isValidPowerUser = JdbcUserLTEDAO.isValidPowerUser(myjdbcDao,username,password);
			if (isValidPowerUser) {
				return new LoginResponse(true, true, "Successful Power user login");
			}
			else { // Since neither LDAP nor Power User checks were successful - fail the login attempt.
				return new LoginResponse(false, false, "Invalid username or password. Failed both LDAP and Power User checks");
				// below may have worked. But opted for Satish bit above.
				// throw new
				// 		BadCredentialsException("LDAP authentication failed : " + username);
			}
		}
		// End jj re-working of login
	}
}
