package com.vzw.ns.security;

import bus.LDAPLogin;
import db.JdbcDao;
import db.login.JdbcUserLTEDAO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by gundaja on 3/10/18.
 */
@Component
public class LDAPAuthenticationProvider implements AuthenticationProvider {
    protected final Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private JdbcDao jdbcDao;

    private  boolean isValidPowerUser(String userId,String password){
        boolean isValidPowerUser = false;
        isValidPowerUser = JdbcUserLTEDAO.isValidPowerUser(this.jdbcDao,userId,password);
        return isValidPowerUser;
    }

    @Override
    public Authentication authenticate(Authentication auth)
            throws AuthenticationException {

        String username = auth.getName();
        String password = auth.getCredentials()
                .toString();
        logger.info("Auth Provider attempting LDAP Login by " + username + " Details: " + auth.getDetails());


        // Implement ldap
        if (LDAPLogin.login(username, password)) {
            logger.info("Auth Provider LDAP Login succeeded for " + username);
            return new UsernamePasswordAuthenticationToken
                    (username, password, Collections.emptyList());
        } else {
            logger.info("Auth Provider LDAP Login failed for " + username);
            logger.info("Auth Provider attempting to log in as power user: " + username);
            if (isValidPowerUser(username, password)) {
                logger.info("Auth Provider Power Login succeeded for " + username);

                List<GrantedAuthority> roles = new ArrayList<>();
                roles.add(new SimpleGrantedAuthority("ACTUATOR"));

                return new UsernamePasswordAuthenticationToken
                        (username, password, roles);
            }
            else
                logger.info("Auth Provider Power Login failed for " + username);
                throw new
                        BadCredentialsException("Auth Provider LDAP and Power User authentication failed : " + username);
        }
    }

    @Override
    public boolean supports(Class<?> auth) {
        return auth.equals(UsernamePasswordAuthenticationToken.class);
    }
}
