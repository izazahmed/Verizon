package com.vzw.ns.service.interfaces;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.vzw.ns.model.AdHocForm;
import com.vzw.ns.model.Content;
import com.vzw.ns.model.ElementGroup;
import com.vzw.ns.model.EnodeB;
import com.vzw.ns.model.Formula;
import com.vzw.ns.model.MMEPool;
import com.vzw.ns.model.Market;
import com.vzw.ns.model.Region;
import com.vzw.ns.model.ReportLevel;
import com.vzw.ns.model.ReportType;
import com.vzw.ns.ui.models.MmePgwSgwForm;
import com.vzw.ns.ui.models.UACForm;

import bus.ListItem;
import db.JdbcDao;

@Service
public interface IAdHocServiceable {

	public List<ReportLevel> getAllReportLevel();

	public List<MMEPool> getAllMmePools(JdbcDao jdbcDao);

	public List<MmePgwSgwForm> getAllMmeSgwPgw(String userName, String type);

	public List<Region> getAllRegion();

	public List<Market> getAllMarketWithRepectToRegion(Integer regionId);
	
	public List<EnodeB> getAllEnodeBWithRepectToMarket(Integer marketId, String vendorName);
	
	public List<EnodeB> getAllEnodeBbyMarketAndRVendor(List<Integer> markets,String vendorName);
	
	public List<ReportType> getAllReportTypes();
	
	public List<ElementGroup> getAllCellGroup(String userName);
	
	public List<UACForm> getAllUAC();
	
	public List<Content> getAllContent();
	
	public List<Content> getAllContentByReportLevel(Integer reportLvlId);
	
	public List<Content> getAllContentByReportType(Integer reportLvlId);
	
	public AdHocForm saveReports(AdHocForm adHocForm) throws SQLException;
	
	public List<Formula> getAllThresholdByContentTemplateId(Long templateId);
	
	public String getPertainsTo(String rptLevel);
	
	public List<ListItem> getMyETAS(String userName, JdbcDao jdbcDao);

}
