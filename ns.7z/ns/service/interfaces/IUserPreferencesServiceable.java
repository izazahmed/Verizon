package com.vzw.ns.service.interfaces;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.vzw.ns.model.MMEPool;
import com.vzw.ns.model.Market;
import com.vzw.ns.model.MrfcCluster;
import com.vzw.ns.model.UserLTEInfo;
import com.vzw.ns.model.UserPreferencesProfile;
import com.vzw.ns.model.VolteCore;
import com.vzw.ns.ui.models.UserPreferencesForm;

import bus.ListItem;
import db.JdbcDao;

@Service
public interface IUserPreferencesServiceable {

	public List<Market> getAllMarkets();

	public List<Market> getAllMyMarkets(String userName);

	public List<Market> getAllMyMarketForPerfCharts(String userName); 
	
	public List<MMEPool> getAllMyMmePools(String userName);
	
	public UserPreferencesForm getUserPreferences(String userName);
	
	public ResponseEntity<UserPreferencesForm> updateUserPreferences(UserPreferencesForm userPreferences);
	
	public UserPreferencesProfile getUserPreferencesProfile(String userName);

	public UserLTEInfo getUserLTEInfo(String userName);

	public List<String> getUsersByRegion(Integer region);
	
	public List<VolteCore> getAllVolteCores(JdbcDao jdbcDao);
	
	public List<ListItem> getAllMyVolteCores(JdbcDao jdbcDao,String userName);

	public List<ListItem> getAllMyMRFCs(JdbcDao jdbcDao, String userName);

	public List<MrfcCluster> getAllMRFCs(JdbcDao jdbcDao);


	
}
