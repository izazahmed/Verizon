package com.vzw.ns.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.GeneralUtility;
import org.vzw.lte.util.GlobalConstants;

import com.vzw.ns.model.MMEPool;
import com.vzw.ns.model.Market;
import com.vzw.ns.model.MrfcCluster;
import com.vzw.ns.model.MyMMEPool;
import com.vzw.ns.model.MyMarket;
import com.vzw.ns.model.MyMarketPerfCharts;
import com.vzw.ns.model.UserLTEInfo;
import com.vzw.ns.model.UserPreferencesProfile;
import com.vzw.ns.model.VolteCore;
import com.vzw.ns.repo.IMMEPoolable;
import com.vzw.ns.repo.IMarketable;
import com.vzw.ns.repo.IMyMarketPerfChartsable;
import com.vzw.ns.repo.IMyMarketable;
import com.vzw.ns.repo.IMyMmePoolable;
import com.vzw.ns.repo.IUserLTE;
import com.vzw.ns.repo.IUserPreferencesable;
import com.vzw.ns.service.interfaces.IUserPreferencesServiceable;
import com.vzw.ns.ui.models.UserPreferencesForm;

import bus.ListItem;
import db.JdbcDao;
import db.JdbcMrfcClusterDao;
import db.JdbcMyNetElemDao;
import db.JdbcVolteCoreDao;
import db.login.JdbcUserLTEDAO;
import db.preferences.JdbcUserPreferencesDao;

@Service
public class UserPreferencesService implements IUserPreferencesServiceable {

	@Autowired
	IMarketable iMarketable;

	@Autowired
	IMMEPoolable iMMEPoolable;

	@Autowired
	IUserPreferencesable iUserPreferencesable;

	@Autowired
	IUserLTE iUserLTE;

	@Autowired
	IMyMarketable iMyMarketarketable;

	@Autowired
	IMyMarketPerfChartsable iMyMarketPerfChartsable;

	@Autowired
	IMyMmePoolable iMyMmePoolable;

	@Autowired
	JdbcDao jdbcDao;

	@Override
	public List<Market> getAllMarkets() {
		// TODO Auto-generated method stub
		if(GeneralUtility.getDbType()) {
			return iMarketable.getAllMarketsMemsql();// JdbcMarketDao.getAllMarket(jdbcDao);//
		}else {
			return iMarketable.getAllMarkets();// JdbcMarketDao.getAllMarket(jdbcDao);//
		}
		
	}

	@Override
	public List<Market> getAllMyMarkets(String userName) {
		// TODO Auto-generated method stub
		if(GeneralUtility.getDbType()) {
			return iMarketable.getAllMyMarketsMemsql(userName);// JdbcMarketDao.getAllMyMarket(jdbcDao,userName);//
		}else {
			return iMarketable.getAllMyMarkets(userName);// JdbcMarketDao.getAllMyMarket(jdbcDao,userName);//
		}
		
	}

	@Override
	public List<Market> getAllMyMarketForPerfCharts(String userName) {
		// TODO Auto-generated method stub
		return iMarketable.getAllMyMarketForPerfCharts(userName);// JdbcMarketDao.getAllMyMarketForPerfCharts(jdbcDao,userName);//
	}

	@Override
	public List<MMEPool> getAllMyMmePools(String userName) {
		// TODO Auto-generated method stub
		return iMMEPoolable.getAllMyMmePools(userName);// JdbcUserPreferencesDao.getAllMyMmePools(jdbcDao,userName);
	}

	@Override
	public UserPreferencesProfile getUserPreferencesProfile(String userName) {
		// TODO Auto-generated method stub
		return iUserPreferencesable.getUserPreferencesProfile(userName);
	}

	@Override
	public List<String> getUsersByRegion(Integer regionid) {
		// TODO Auto-generated method stub
		return iUserPreferencesable.getUsersByRegion(regionid);
	}

	@Override
	public UserLTEInfo getUserLTEInfo(String userName) {
		// TODO Auto-generated method stub
		return iUserLTE.getUserLTEInfo(userName);
	}

	@Override
	public UserPreferencesForm getUserPreferences(String userName) {
		// TODO Auto-generated method stub
		UserPreferencesForm mUserPreferences = new UserPreferencesForm();
		mUserPreferences.setMyMmePool(getAllMyMmePools(userName));
		mUserPreferences.setMyMarket(getAllMyMarkets(userName));
		mUserPreferences.setMyMarketForPerfCharts(getAllMyMarketForPerfCharts(userName));
		mUserPreferences.setUserProfile(getUserPreferencesProfile(userName));
		mUserPreferences.setUserLTEInfo(getUserLTEInfo(userName));
		//mUserPreferences.setMyVolteCoresForDisplay(getAllMyVolteCores(jdbcDao, userName));
		//mUserPreferences.setMyMrfcClustersForDisplay(getAllMyMRFCs(jdbcDao, userName));
		return mUserPreferences;
	}

	@Override
	public ResponseEntity<UserPreferencesForm> updateUserPreferences(UserPreferencesForm userPreferences) {
		List<MMEPool> myMmePool = userPreferences.getMyMmePool();
		List<Market> myMarket = userPreferences.getMyMarket();
		List<Market> myMarketForPerfCharts = userPreferences.getMyMarketForPerfCharts();
		UserPreferencesProfile mUserProfile = userPreferences.getUserProfile();
		UserLTEInfo mUserLTEInfo = userPreferences.getUserLTEInfo();

		//List<String> volteCoreList = userPreferences.getMyVolteCoreList();
		//List<String> mrfcClusterList = userPreferences.getMyMrfcClusterList();

		mUserProfile.setUserName(mUserLTEInfo.getUserName());
		// save in db
		mUserProfile.setAccessLevel(userPreferences.getUserProfile().getAccessLevel());
		mUserProfile.setCurrentDiskSpace(BigDecimal.valueOf(0));
		mUserProfile.setMaxDiskSpace(BigDecimal.valueOf(100));
		mUserProfile.setPurgeLimit(BigDecimal.valueOf(20));
		mUserProfile.setMaxReports(BigDecimal.valueOf(5));
		// save in db
		mUserProfile = iUserPreferencesable.save(mUserProfile);
		mUserLTEInfo.setUserName(mUserProfile.getUserName());
		mUserLTEInfo = iUserLTE.save(mUserLTEInfo);

		JdbcUserLTEDAO.updateNPTUserTable(this.jdbcDao, mUserProfile.getUserName());
		JdbcUserLTEDAO.addLoginHistoryInfo(this.jdbcDao, mUserProfile.getUserName());

		// first delete all record then insert with repoect to username
		// my market perf
		iMyMarketPerfChartsable.deleteByName(userPreferences.getUserName());
		List<MyMarketPerfCharts> mMyMaketPerfList = createMyMarketPerfChartsList(userPreferences);
		mMyMaketPerfList.forEach(m -> {
			iMyMarketPerfChartsable.insertByNameId(m.getUserName(), m.getMyMarketId());
		});

		// mymarket
		iMyMarketarketable.deleteUsingUserName(userPreferences.getUserName());
		List<MyMarket> mMyMaketList = createMyMarketList(userPreferences);
		mMyMaketList.forEach(m -> {
			iMyMarketarketable.insertByNameId(m.getUserName(), m.getMyMarketId());
		});

		// my mme pool
		iMyMmePoolable.deleteUsingUserName(userPreferences.getUserName());
		List<MyMMEPool> mMyMmePoolList = createMyMmePoolList(userPreferences);
		mMyMmePoolList.forEach(m -> {
			iMyMmePoolable.insertByNameId(m.getUserName(), m.getMyMMEId());
		});

		//JdbcUserPreferencesDao.updateVolteCoresForUser(jdbcDao, userPreferences.getUserName(), volteCoreList);
		//JdbcUserPreferencesDao.updateMrfcClustersForUser(jdbcDao, userPreferences.getUserName(), mrfcClusterList);
	
		return new ResponseEntity<UserPreferencesForm>(
				new UserPreferencesForm(myMmePool, myMarket, myMarketForPerfCharts, mUserProfile, mUserLTEInfo),
				HttpStatus.CREATED);
	}

	private List<MyMarket> createMyMarketList(UserPreferencesForm userPreferences) {
		List<Market> mUserMyMarketList = userPreferences.getMyMarket();
		List<MyMarket> mMyMarketList = mUserMyMarketList.stream()
				.map(m -> new MyMarket(userPreferences.getUserName(), (long) m.getmId(), null))
				.collect(Collectors.toList());
		return mMyMarketList;
	}

	private List<MyMarketPerfCharts> createMyMarketPerfChartsList(UserPreferencesForm userPreferences) {
		List<Market> mUserMyMarketList = userPreferences.getMyMarketForPerfCharts();
		List<MyMarketPerfCharts> mMyMarketList = mUserMyMarketList.stream()
				.map(m -> new MyMarketPerfCharts((long) m.getmId(), userPreferences.getUserName()))
				.collect(Collectors.toList());

		return mMyMarketList;
	}

	private List<MyMMEPool> createMyMmePoolList(UserPreferencesForm userPreferences) {

		List<MMEPool> mUserMyMmeList = userPreferences.getMyMmePool();
		List<MyMMEPool> mMyMarketList = mUserMyMmeList.stream()
				.map(m -> new MyMMEPool(userPreferences.getUserName(), (long) m.getMmePoolIid(), null))
				.collect(Collectors.toList());
		return mMyMarketList;
	}

	@Override
	public List<VolteCore> getAllVolteCores(JdbcDao jdbcDao) {
		// TODO Auto-generated method stub
		return JdbcVolteCoreDao.populateVolteCore(jdbcDao);
	}

	//for clpt
	@Override
	public List<ListItem> getAllMyVolteCores(JdbcDao jdbcDao, String userName) {
		// TODO Auto-generated method stub
		return null;// JdbcMyNetElemDao.getMyVolteCores(jdbcDao, userName);
	}

	@Override
	public List<ListItem> getAllMyMRFCs(JdbcDao jdbcDao, String userName) {
		// TODO Auto-generated method stub
		return null;//JdbcMyNetElemDao.getMyMrfcClusters(jdbcDao, userName);
	}

	@Override
	public List<MrfcCluster> getAllMRFCs(JdbcDao jdbcDao) {
		// TODO Auto-generated method stub
		return JdbcMrfcClusterDao.populateMrfcCluster(jdbcDao);
	}

}
