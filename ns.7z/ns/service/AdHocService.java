package com.vzw.ns.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.vzw.lte.util.EnvironmentUtil;
import org.vzw.lte.util.GeneralUtility;

import com.vzw.ns.model.AdHocForm;
import com.vzw.ns.model.Content;
import com.vzw.ns.model.ElementGroup;
import com.vzw.ns.model.EnodeB;
import com.vzw.ns.model.Formula;
import com.vzw.ns.model.MME;
import com.vzw.ns.model.MMEPool;
import com.vzw.ns.model.Market;
import com.vzw.ns.model.PGW;
import com.vzw.ns.model.Region;
import com.vzw.ns.model.ReportLevel;
import com.vzw.ns.model.ReportType;
import com.vzw.ns.model.SGW;
import com.vzw.ns.repo.ICellGroupable;
import com.vzw.ns.repo.IContentable;
import com.vzw.ns.repo.IElementListDetailsable;
import com.vzw.ns.repo.IFilterCriteriaDetailable;
import com.vzw.ns.repo.IFilterCriteriaDetailsNextValFromDualable;
import com.vzw.ns.repo.IMMEPoolable;
import com.vzw.ns.repo.IMMEable;
import com.vzw.ns.repo.IMarketable;
import com.vzw.ns.repo.IMmeSgwPgwSpgwable;
import com.vzw.ns.repo.IMyMmePoolable;
import com.vzw.ns.repo.IPGWable;
import com.vzw.ns.repo.IRegionable;
import com.vzw.ns.repo.IReportExcludeHolidayable;
import com.vzw.ns.repo.IReportLevelRepositoryable;
import com.vzw.ns.repo.IReportSeqFromDualable;
import com.vzw.ns.repo.IReportSqlFilterCriteriable;
import com.vzw.ns.repo.IReportSqlFilterNextValFromDualable;
import com.vzw.ns.repo.IReportTypeable;
import com.vzw.ns.repo.IReportable;
import com.vzw.ns.repo.ISGWable;
import com.vzw.ns.repo.ITemplateable;
import com.vzw.ns.repo.IThresholadable;
import com.vzw.ns.repo.IeNodeBable;
import com.vzw.ns.service.interfaces.IAdHocServiceable;
import com.vzw.ns.ui.models.MmePgwSgwForm;
import com.vzw.ns.ui.models.UACForm;

import bus.ListItem;
import db.JdbcDao;
import db.JdbcMyNetElemDao;

@Service
public class AdHocService implements IAdHocServiceable {

	@Autowired
	IReportLevelRepositoryable iReportLevelRepositoryable;

	@Autowired
	IMMEPoolable iMMEPoolable;

	@Autowired
	IMmeSgwPgwSpgwable iMmeSgwPgwSpgwable;

	@Autowired
	IRegionable iRegionable;

	@Autowired
	IMarketable iMarketable;

	@Autowired
	IeNodeBable ieNodeBable;

	@Autowired
	IReportTypeable iReportTypeable;

	@Autowired
	IMyMmePoolable iMyMmePoolable;

	@Autowired
	IPGWable IPGWable;

	@Autowired
	ISGWable iSGWable;

	@Autowired
	IMMEable iMMEable;

	@Autowired
	ICellGroupable iCellGroupable;

	@Autowired
	IContentable iContentable;

	@Autowired
	IReportable iReportable;

	@Autowired
	IReportSeqFromDualable iReportSeqFromDualable;

	@Autowired
	ITemplateable iTemplateable;

	@Autowired
	IReportExcludeHolidayable iReportExcludeHolidayable;

	@Autowired
	IReportSqlFilterNextValFromDualable iReportSqlFilterNextValFromDualable;

	@Autowired
	IReportSqlFilterCriteriable iReportSqlFilterCriteriable;

	@Autowired
	IElementListDetailsable iElementListDetailsable;

	@Autowired
	IThresholadable iThresholadable;

	@Autowired
	IFilterCriteriaDetailsNextValFromDualable iFilterCriteriaDetailsNextValFromDualable;

	@Autowired
	IFilterCriteriaDetailable iFilterCriteriaDetailable;

	

	
	@Override
	public List<ReportLevel> getAllReportLevel() {
		return iReportLevelRepositoryable.getAllReportLevel();
	}

	@Override
	public List<MMEPool> getAllMmePools(JdbcDao jdbcDao) {
		// TODO Auto-generated method stub
		return iMMEPoolable.getAllMmePools();//JdbcUserPreferencesDao.getAllMmePools(jdbcDao);
	}
	
	@Override
	public List<MmePgwSgwForm> getAllMmeSgwPgw(String userName, String type) {
		// TODO Auto-generated method stub
		List<MME> mMMEPool = null;
		List<SGW> mMySGWs = null;
		List<PGW> mMyPGWs = null;
		MmePgwSgwForm mmePgwSgwForm = new MmePgwSgwForm();
		List<MmePgwSgwForm> mmeSpgwList = new ArrayList<>();

		if(type.equals("mme")) {
			mMMEPool = iMMEable.populateMME(); //NTSCA-1750
			// Add the MMEs to the collection.
			for (int i = 0; i < mMMEPool.size(); i++) {
				MME mmePool = mMMEPool.get(i);
				mmePgwSgwForm = new MmePgwSgwForm();
				mmePgwSgwForm.setId("mme" + mmePool.getmIid() + "^" + mmePool.getMmePoolId());
				mmePgwSgwForm.setCompositeId(mmePool.getmIid()+"");
				mmePgwSgwForm.setName("MME " + mmePool.getMmeLocation());
				mmePgwSgwForm.setDescription("MME " + mmePool.getMmeLocation());
				mmePgwSgwForm.setMmePoolIid(mmePool.getMmePoolId().toString());
				mmeSpgwList.add(mmePgwSgwForm);
			}
		}
		if(type.equals("spgw")) {
			mMySGWs = iSGWable.populateSGW(); //NTSCA-1750
		// Add the SGWs to the collection.
		for (int i = 0; i < mMySGWs.size(); i++) {
			SGW sgw = mMySGWs.get(i);
			mmePgwSgwForm = new MmePgwSgwForm();
			if (sgw.getSgwLocation().contains("SPGW")) {
				mmePgwSgwForm.setId("spgw" + sgw.getsId() + "^" + sgw.getMmePoolId());
			} else {
				mmePgwSgwForm.setId("sgw" + sgw.getsId() + "^" + sgw.getMmePoolId());
			}
			mmePgwSgwForm.setCompositeId(sgw.getsId().toString());
			mmePgwSgwForm.setType("spgw");
			mmePgwSgwForm.setName(sgw.getSgwLocation());
			mmePgwSgwForm.setDescription(sgw.getSgwLocation());
			mmePgwSgwForm.setMmePoolIid(sgw.getMmePoolId().toString());
			mmeSpgwList.add(mmePgwSgwForm);
		}
		}
		
		if(type.equals("pgw")) {
			mMyPGWs = IPGWable.populatePGW(); //NTSCA-1750
		// Add the PGWs to the collection.
		for (int i = 0; i < mMyPGWs.size(); i++) {
			PGW pgw = mMyPGWs.get(i);
			mmePgwSgwForm = new MmePgwSgwForm();
			mmePgwSgwForm.setId("pgw" + pgw.getpId() + "^" + pgw.getMmePoolId());
			mmePgwSgwForm.setCompositeId(pgw.getpId().toString());
			mmePgwSgwForm.setType("mypgw");
			mmePgwSgwForm.setName("PGW " + pgw.getPgwLocation());
			mmePgwSgwForm.setDescription("PGW " + pgw.getPgwLocation());
			mmePgwSgwForm.setMmePoolIid(pgw.getMmePoolId().toString());
			mmeSpgwList.add(mmePgwSgwForm);
		}
		}
		return mmeSpgwList;
	}

	@Override
	public List<Region> getAllRegion() {
		// TODO Auto-generated method stub
		return iRegionable.getAllRegion();
	}

	@Override
	public List<Market> getAllMarketWithRepectToRegion(Integer regionId) {
		// TODO Auto-generated method stub
//		if(EnvironmentUtil.isAppIdAlte()) {
		if(GeneralUtility.getDbType()) {
			return iMarketable.getAllMarketWithRepectToRegionMemsql(regionId);
		}else {
			return iMarketable.getAllMarketWithRepectToRegion(regionId);
		}
		
	}


	@Cacheable(value = "getAllEnodeBWithRepectToMarket",keyGenerator = "customAKeyGenerator",cacheManager = "myACacheManager")
	@Override
	public List<EnodeB> getAllEnodeBWithRepectToMarket(Integer marketId, String vendorName) {
		// TODO Auto-generated method stub
		if(vendorName == null || vendorName.trim().length() <=0 || vendorName.trim().equalsIgnoreCase(""))
			return ieNodeBable.getAllEnodeBWithRepectToMarket(marketId);
		else
			return ieNodeBable.getAllEnodeBWithRepectToMarketVendor(marketId, vendorName);
	}

	@Override
	public List<EnodeB> getAllEnodeBbyMarketAndRVendor(List<Integer> markets, String vendorName) {
		// TODO Auto-generated method stub
		List<Integer> mMarkets = markets;//// createMarketListFromMarkets(markets);
		return (vendorName == null || vendorName.isEmpty()) ? ieNodeBable.getAllEnodeBbyMarketAndRVendor(mMarkets)
				: ieNodeBable.getAllEnodeBbyMarketAndRVendor(mMarkets, vendorName);
	}

	@Override
	public List<ReportType> getAllReportTypes() {
		// TODO Auto-generated method stub
		return iReportTypeable.getAllReportType();
	}

	@Override
	public List<ElementGroup> getAllCellGroup(String userName) {
		// TODO Auto-generated method stub
//		return iCellGroupable.getAllCellGroup(userName);
		List<ElementGroup> elementGroup = iCellGroupable.getAllCellGroup(userName);
		elementGroup.addAll(iCellGroupable.getAllSubscribedCellGroup(userName));
		return elementGroup;
	}

	@Override
	public List<UACForm> getAllUAC() {
		//
		return null;
	}

	@Override
	public List<Content> getAllContent() {
		// TODO Auto-generated method stub
		return iContentable.getAllContent();
	}

	@Override
	public List<Content> getAllContentByReportLevel(Integer aReportLvlId) {
		
		return iContentable.getAllContentByReportLevel(aReportLvlId);
	}
	
	@Override
	public List<Content> getAllContentByReportType(Integer aReportTypeId) {
		
		return iContentable.getAllContentByReportType(aReportTypeId);
	}
	
	
	@Override
	public List<Formula> getAllThresholdByContentTemplateId(Long templateId) {
		// TODO Auto-generated method stub
		return iThresholadable.getAllThresholdByContentTemplateId(templateId);
	}

	@Override
	public AdHocForm saveReports(AdHocForm adHocForm) throws SQLException {
		// TODO Auto-generated method stub
		//not in use
		return null;
	}

	@Override
	public String getPertainsTo(String rptLevel) {
		// TODO Auto-generated method stub
		//not in use
		return null;
	}

	@Override
	public List<ListItem> getMyETAS(String userName, JdbcDao jdbcDao) {
		// TODO Auto-generated method stub
		return null;//JdbcMyNetElemDao.getMyETAS(jdbcDao, userName);
	}
}
